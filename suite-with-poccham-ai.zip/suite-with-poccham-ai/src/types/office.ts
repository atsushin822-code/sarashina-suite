export type OfficeTab = 'doc' | 'sheet' | 'slide';

export interface ModelStatus {
  is_ready: boolean;
  is_downloading: boolean;
  file_size_bytes: number;
  model_path: string;
  engine_version: string;
}

export interface DownloadProgressPayload {
  downloaded_bytes: number;
  total_bytes: number;
  percentage: number;
  speed_mbps: number;
  status: string;
}

export interface TokenStreamPayload {
  token: string;
  is_done: boolean;
}

export interface SpreadsheetState {
  sheet_names: string[];
  active_sheet: string;
  rows: string[][];
}

export interface SlideData {
  id: string;
  title: string;
  bullets: string[];
  notes: string;
}
