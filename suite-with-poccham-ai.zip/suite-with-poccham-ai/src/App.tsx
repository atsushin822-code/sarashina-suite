import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { Header } from './components/Header';
import { DocumentEditor } from './components/DocumentEditor';
import { SpreadsheetEditor } from './components/SpreadsheetEditor';
import { SlideEditor } from './components/SlideEditor';
import { PocchamAIPanel } from './components/PocchamAIPanel';
import { ModelDownloadModal } from './components/ModelDownloadModal';
import {
  OfficeTab,
  ModelStatus,
  DownloadProgressPayload,
  TokenStreamPayload,
  SpreadsheetState,
  SlideData,
} from './types/office';
import pptxgen from 'pptxgenjs';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<OfficeTab>('doc');
  const [docTitle, setDocTitle] = useState('無題のプロジェクト');

  // AI & Model Management States
  const [modelStatus, setModelStatus] = useState<ModelStatus | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgressPayload | null>(null);

  // AI Copilot States
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedText, setGeneratedText] = useState('');

  // Office Workspaces States
  const [docContent, setDocContent] = useState(
    '# 次世代事業計画書\n\n## 1. 概要\nSuite with Poccham AI を活用した超高速・セキュアなオフィス業務の完全ローカル完結基盤。\n\n## 2. ターゲット課題\n- クラウド依存によるデータ漏洩リスクの排除\n- ネットワーク障害時でも100%動作するオフラインインテリジェンスの実現'
  );

  const [sheetData, setSheetData] = useState<SpreadsheetState>({
    sheet_names: ['Sheet1'],
    active_sheet: 'Sheet1',
    rows: [
      ['項目', '第1四半期', '第2四半期', '第3四半期', '年間合計'],
      ['売上高 (百万円)', '120', '145', '180', '=SUM(B2:D2)'],
      ['営業利益', '35', '42', '58', '=SUM(B3:D3)'],
      ['利益率 (%)', '29.1', '28.9', '32.2', '=E3/E2'],
    ],
  });

  const [slides, setSlides] = useState<SlideData[]>([
    {
      id: '1',
      title: 'Suite with Poccham AI',
      bullets: [
        'オンデバイスLLM統合型の次世代オフィススイート',
        '通信不要・完全オフラインでの知的ドキュメント生成',
        'Word / Excel / PowerPoint 互換フォーマット対応',
      ],
      notes: 'イントロダクション：製品の最大価値であるローカルファーストとAIの融合を強調する。',
    },
    {
      id: '2',
      title: 'Poccham AI Core の技術優位性',
      bullets: [
        'C++ / llama.cpp ネイティブ推論による爆速レスポンス',
        '外部サーバーへのデータ送信ゼロによる最高レベルの機密保持',
        '業務コンテキスト（文章/関数/プレゼン構成）に特化したプロンプト自動最適化',
      ],
      notes: 'セキュリティとスピードに焦点を当てて説明を行う。',
    },
  ]);

  // Check model status on mount
  useEffect(() => {
    checkModelStatus();

    // Listen to download progress emitted by Rust backend
    const unlistenProgress = listen<DownloadProgressPayload>(
      'poccham-download-progress',
      (event) => {
        setDownloadProgress(event.payload);
        if (event.payload.percentage >= 100) {
          checkModelStatus();
        }
      }
    );

    // Listen to streaming tokens emitted by Rust inference engine
    const unlistenTokens = listen<TokenStreamPayload>(
      'poccham-stream-token',
      (event) => {
        if (event.payload.is_done) {
          setIsGenerating(false);
        } else {
          setGeneratedText((prev) => prev + event.payload.token);
        }
      }
    );

    return () => {
      unlistenProgress.then((f) => f());
      unlistenTokens.then((f) => f());
    };
  }, []);

  const checkModelStatus = async () => {
    try {
      const status = await invoke<ModelStatus>('get_model_status');
      setModelStatus(status);
    } catch (e) {
      console.warn('Backend invoke error or running in pure browser preview:', e);
      // Fallback for UI design preview
      setModelStatus({
        is_ready: true,
        is_downloading: false,
        file_size_bytes: 2200000000,
        model_path: '/local/app/poccham-ai/models/poccham-ai-core.gguf',
        engine_version: 'Poccham-v2.1-Core',
      });
    }
  };

  const handleStartDownload = async () => {
    try {
      await invoke('start_download_poccham_engine');
      checkModelStatus();
    } catch (e) {
      console.error('Download start failed:', e);
    }
  };

  const handleCancelDownload = async () => {
    try {
      await invoke('cancel_download_poccham_engine');
      checkModelStatus();
    } catch (e) {
      console.error('Download cancel failed:', e);
    }
  };

  // AI Prompt Execution
  const handleAIGenerate = async (prompt: string) => {
    setIsGenerating(true);
    setGeneratedText('');

    let currentContext = '';
    if (activeTab === 'doc') currentContext = docContent;
    else if (activeTab === 'sheet') currentContext = JSON.stringify(sheetData.rows);
    else if (activeTab === 'slide') currentContext = JSON.stringify(slides);

    try {
      await invoke('generate_poccham_ai_completion', {
        prompt,
        contextType: activeTab === 'doc' ? 'document' : activeTab === 'sheet' ? 'spreadsheet' : 'slide',
        currentContent: currentContext,
      });
    } catch (e) {
      console.warn('Invoke AI fallback simulation:', e);
      // Fallback mock stream for browser dev environment
      setTimeout(() => {
        setGeneratedText(
          `【Poccham AI 解析・生成レポート】\n\nご指定の要求に基づき、以下の内容をまとめました：\n\n1. 核心ポイントの整理：現行のドキュメント構成は非常に論理的であり、データ保護とオフライン可用性が最大のアピールポイントとなります。\n2. 次のアクション：関係者レビュー用に要約サマリーを先頭に追加することを推奨します。`
        );
        setIsGenerating(false);
      }, 1200);
    }
  };

  const handleApplyToWorkspace = (text: string) => {
    if (activeTab === 'doc') {
      setDocContent((prev) => prev + '\n\n' + text);
    } else if (activeTab === 'slide') {
      const newSlide: SlideData = {
        id: Date.now().toString(),
        title: 'Poccham AI 生成スライド',
        bullets: text
          .split('\n')
          .filter((line) => line.trim().length > 0)
          .slice(0, 4),
        notes: 'Poccham AI により自動生成されたプレゼンテーション下書きです。',
      };
      setSlides([...slides, newSlide]);
    }
  };

  // Save to SQLite
  const handleSave = async () => {
    const payload = {
      id: 'current-workspace-doc',
      title: docTitle,
      doc_type: activeTab,
      content:
        activeTab === 'doc'
          ? docContent
          : activeTab === 'sheet'
          ? JSON.stringify(sheetData)
          : JSON.stringify(slides),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    try {
      await invoke('save_document', { doc: payload });
      alert('SQLiteローカルデータベースに正常に保存されました。');
    } catch (e) {
      console.log('Saved to local state:', payload);
      alert('現在のワークスペースがローカル保存されました。');
    }
  };

  // Export office files (docx, xlsx, csv, pptx)
  const handleExport = () => {
    if (activeTab === 'doc') {
      // Export as text or trigger docx export
      const blob = new Blob([docContent], { type: 'text/markdown;charset=utf-8' });
      saveAs(blob, `${docTitle}.md`);
    } else if (activeTab === 'sheet') {
      // Export xlsx
      const ws = XLSX.utils.aoa_to_sheet(sheetData.rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, sheetData.active_sheet);
      const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      saveAs(new Blob([wbout], { type: 'application/octet-stream' }), `${docTitle}.xlsx`);
    } else if (activeTab === 'slide') {
      // Export pptx using pptxgenjs
      const pres = new pptxgen();
      pres.layout = 'LAYOUT_16x9';

      slides.forEach((slide) => {
        const slideObj = pres.addSlide();
        slideObj.addText(slide.title, {
          x: 0.5,
          y: 0.5,
          w: '90%',
          h: 0.8,
          fontSize: 24,
          bold: true,
          color: '1E293B',
        });

        const bulletTexts = slide.bullets.map((b) => ({
          text: b,
          options: { fontSize: 14, bullet: true, color: '334155' },
        }));

        slideObj.addText(bulletTexts, {
          x: 0.8,
          y: 1.6,
          w: '85%',
          h: 3.5,
          lineSpacing: 28,
        });

        if (slide.notes) {
          slideObj.addNotes(slide.notes);
        }
      });

      pres.writeFile({ fileName: `${docTitle}.pptx` });
    }
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.docx,.xlsx,.csv,.txt,.md';
    input.onchange = async (e: any) => {
      const file = e.target.files[0];
      if (!file) return;

      const ext = file.name.split('.').pop()?.toLowerCase();
      if (ext === 'xlsx' || ext === 'csv') {
        const reader = new FileReader();
        reader.onload = (evt) => {
          const bstr = evt.target?.result;
          const wb = XLSX.read(bstr, { type: 'binary' });
          const firstSheet = wb.SheetNames[0];
          const rows: string[][] = XLSX.utils.sheet_to_json(wb.Sheets[firstSheet], { header: 1 });
          setSheetData({
            sheet_names: wb.SheetNames,
            active_sheet: firstSheet,
            rows,
          });
          setActiveTab('sheet');
        };
        reader.readAsBinaryString(file);
      } else {
        const reader = new FileReader();
        reader.onload = (evt) => {
          const text = evt.target?.result as string;
          setDocContent(text);
          setActiveTab('doc');
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-50 font-sans">
      {/* Top Application Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        docTitle={docTitle}
        setDocTitle={setDocTitle}
        modelStatus={modelStatus}
        onOpenModelModal={() => setIsModalOpen(true)}
        onSave={handleSave}
        onImport={handleImport}
        onExport={handleExport}
      />

      {/* Main Workspace Stage + Poccham AI Copilot Panel */}
      <div className="flex-1 flex overflow-hidden">
        {activeTab === 'doc' && (
          <DocumentEditor content={docContent} setContent={setDocContent} />
        )}
        {activeTab === 'sheet' && (
          <SpreadsheetEditor data={sheetData} setData={setSheetData} />
        )}
        {activeTab === 'slide' && (
          <SlideEditor slides={slides} setSlides={setSlides} />
        )}

        {/* Collapsible Poccham AI Panel */}
        <PocchamAIPanel
          activeTab={activeTab}
          modelStatus={modelStatus}
          onOpenModelModal={() => setIsModalOpen(true)}
          onGenerate={handleAIGenerate}
          isGenerating={isGenerating}
          generatedText={generatedText}
          onApplyToWorkspace={handleApplyToWorkspace}
          onStopGeneration={() => setIsGenerating(false)}
        />
      </div>

      {/* Poccham AI Engine Setup Modal */}
      <ModelDownloadModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        modelStatus={modelStatus}
        downloadProgress={downloadProgress}
        onStartDownload={handleStartDownload}
        onCancelDownload={handleCancelDownload}
      />
    </div>
  );
};

export default App;
