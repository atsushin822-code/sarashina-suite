import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

export const resources = {
  ja: {
    translation: {
      appName: "Suite with Poccham AI",
      nav: {
        doc: "ドキュメント",
        sheet: "スプレッドシート",
        slide: "スライド",
        settings: "設定",
      },
      common: {
        save: "保存",
        export: "エクスポート",
        import: "インポート",
        newFile: "新規作成",
        title: "無題のドキュメント",
        ready: "準備完了",
        offline: "完全ローカル・オフライン稼働中",
      },
      ai: {
        brand: "Poccham AI",
        tagline: "オンデバイス特化型 次世代Officeインテリジェンス",
        statusReady: "Poccham AI エンジン: 稼働中 (ローカル)",
        statusMissing: "Poccham AI エンジンが未設定です",
        downloadEngine: "Poccham AI エンジンを準備",
        askPlaceholder: "Poccham AI に指示を入力（例: このドキュメントの要約を作成して）...",
        generate: "生成",
        generating: "思考・生成中...",
        stop: "中断",
        quickActions: "クイック・アシスト",
        actions: {
          docSummary: "エグゼクティブ要約",
          docProofread: "プロフェッショナル校正",
          docContinue: "続きを執筆",
          sheetFormula: "関数・計算式の提案",
          sheetAnalyze: "データインサイト分析",
          slideOutline: "スライド構成案を自動生成",
          slideBullet: "箇条書きのキーメッセージ化",
        },
      },
      modal: {
        downloadTitle: "Poccham AI コアエンジンのセットアップ",
        downloadDesc: "高度な自然言語処理とデータ推論をすべてお使いのPC内で完結させるため、高精度ローカル推論エンジンを安全にダウンロード・配置します。完了後はネット接続不要で完全オフライン動作します。",
        fileSize: "推定サイズ: 約 2.1 GB",
        startDownload: "ダウンロードを開始",
        cancel: "キャンセル",
        downloading: "ダウンロード中...",
        speed: "転送速度",
        completed: "Poccham AI エンジンの配置が完了しました！",
      },
      doc: {
        placeholder: "ここに文章を入力するか、Poccham AI に執筆を依頼してください...",
      },
      sheet: {
        formulaPlaceholder: "計算式や値を入力 (例: =SUM(A1:B10))",
      },
      slide: {
        addSlide: "スライド追加",
        slideTitle: "スライドタイトル",
        bulletPlaceholder: "箇条書き内容を入力...",
        notesPlaceholder: "発表者スピーカーノート...",
      }
    },
  },
  en: {
    translation: {
      appName: "Suite with Poccham AI",
      nav: {
        doc: "Document",
        sheet: "Spreadsheet",
        slide: "Slide",
        settings: "Settings",
      },
      common: {
        save: "Save",
        export: "Export",
        import: "Import",
        newFile: "New File",
        title: "Untitled Document",
        ready: "Ready",
        offline: "100% Local & Offline Mode",
      },
      ai: {
        brand: "Poccham AI",
        tagline: "Next-Gen On-Device Office Intelligence",
        statusReady: "Poccham AI Engine: Active (Local)",
        statusMissing: "Poccham AI Engine is not configured",
        downloadEngine: "Setup Poccham AI Engine",
        askPlaceholder: "Instruct Poccham AI (e.g. Draft an executive summary)...",
        generate: "Generate",
        generating: "Processing & Generating...",
        stop: "Stop",
        quickActions: "Quick Assist",
        actions: {
          docSummary: "Executive Summary",
          docProofread: "Professional Polish",
          docContinue: "Continue Writing",
          sheetFormula: "Suggest Formula",
          sheetAnalyze: "Data Insights",
          slideOutline: "Generate Deck Outline",
          slideBullet: "Condense to Key Messages",
        },
      },
      modal: {
        downloadTitle: "Setup Poccham AI Core Engine",
        downloadDesc: "To process all intelligent document reasoning locally on your device, download and install the ultra-fast local inference engine. Once finished, it works entirely offline without internet access.",
        fileSize: "Estimated Size: ~2.1 GB",
        startDownload: "Start Download",
        cancel: "Cancel",
        downloading: "Downloading...",
        speed: "Speed",
        completed: "Poccham AI Engine setup complete!",
      },
      doc: {
        placeholder: "Start drafting here or request Poccham AI to generate text...",
      },
      sheet: {
        formulaPlaceholder: "Enter formula or value (e.g. =SUM(A1:B10))",
      },
      slide: {
        addSlide: "Add Slide",
        slideTitle: "Slide Title",
        bulletPlaceholder: "Enter bullet points...",
        notesPlaceholder: "Speaker presentation notes...",
      }
    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'ja',
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
