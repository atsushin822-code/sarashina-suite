import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { OfficeTab, ModelStatus } from '../types/office';
import { Send, Square, Check, RefreshCw, ChevronRight, ChevronLeft } from 'lucide-react';

interface PocchamAIPanelProps {
  activeTab: OfficeTab;
  modelStatus: ModelStatus | null;
  onOpenModelModal: () => void;
  onGenerate: (prompt: string) => void;
  isGenerating: boolean;
  generatedText: string;
  onApplyToWorkspace: (text: string) => void;
  onStopGeneration: () => void;
}

export const PocchamAIPanel: React.FC<PocchamAIPanelProps> = ({
  activeTab,
  modelStatus,
  onOpenModelModal,
  onGenerate,
  isGenerating,
  generatedText,
  onApplyToWorkspace,
  onStopGeneration,
}) => {
  const { t } = useTranslation();
  const [prompt, setPrompt] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(false);

  const getQuickActions = () => {
    switch (activeTab) {
      case 'doc':
        return [
          { label: t('ai.actions.docSummary'), prompt: 'このドキュメントの要約を箇条書き3点で作成してください。' },
          { label: t('ai.actions.docProofread'), prompt: 'この文章をビジネス文書として自然かつ論理的な表現に校正してください。' },
          { label: t('ai.actions.docContinue'), prompt: 'このドキュメントの文脈に沿って、次の展開となる段落を執筆してください。' },
        ];
      case 'sheet':
        return [
          { label: t('ai.actions.sheetFormula'), prompt: 'このデータ範囲に対して集計を行う最適な関数（SUMIF / XLOOKUPなど）の数式を提示してください。' },
          { label: t('ai.actions.sheetAnalyze'), prompt: 'この表データの傾向や外れ値、ビジネス上の示唆を分析してください。' },
        ];
      case 'slide':
        return [
          { label: t('ai.actions.slideOutline'), prompt: '与えられたトピックに基づき、5枚構成のプレゼンテーション骨子とタイトルを作成してください。' },
          { label: t('ai.actions.slideBullet'), prompt: 'この内容をスライド1枚向けに、視認性の高い短い箇条書き3点に要約してください。' },
        ];
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;
    onGenerate(prompt);
  };

  if (isCollapsed) {
    return (
      <div className="w-10 bg-white border-l border-slate-200 flex flex-col items-center py-4 space-y-4">
        <button
          onClick={() => setIsCollapsed(false)}
          className="p-1.5 text-slate-500 hover:text-sky-600 hover:bg-slate-100 rounded-lg transition"
          title="Open Poccham AI Panel"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="rotate-90 origin-left translate-x-4 text-xs font-bold text-slate-700 tracking-wider">
          POCCHAM
        </div>
      </div>
    );
  }

  return (
    <aside className="w-80 md:w-96 bg-white border-l border-slate-200 flex flex-col h-full shadow-lg z-10 transition-all select-none">
      {/* Panel Header */}
      <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 rounded-md bg-slate-800 flex items-center justify-center text-white text-xs font-bold">
            P
          </div>
          <div>
            <h3 className="text-xs font-bold text-slate-800">{t('ai.brand')}</h3>
            <span className="text-[10px] text-emerald-600 font-medium">● Local Active</span>
          </div>
        </div>
        <button
          onClick={() => setIsCollapsed(true)}
          className="p-1 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200/50 transition"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Model Readiness Check */}
      {!modelStatus?.is_ready && (
        <div className="m-3 p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
          <p className="text-xs text-amber-800 font-medium">{t('ai.statusMissing')}</p>
          <button
            onClick={onOpenModelModal}
            className="w-full py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-sm transition"
          >
            {t('ai.downloadEngine')}
          </button>
        </div>
      )}

      {/* Quick Assist Chips */}
      <div className="p-3 border-b border-slate-100">
        <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
          {t('ai.quickActions')}
        </span>
        <div className="flex flex-wrap gap-1.5">
          {getQuickActions().map((action, i) => (
            <button
              key={i}
              onClick={() => onGenerate(action.prompt)}
              disabled={isGenerating || !modelStatus?.is_ready}
              className="text-[11px] px-2.5 py-1 bg-slate-100 hover:bg-sky-50 hover:text-sky-700 hover:border-sky-200 border border-slate-200/70 text-slate-700 rounded-lg transition disabled:opacity-50 text-left"
            >
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Output / Reasoning Stream Area */}
      <div className="flex-1 p-3 overflow-y-auto space-y-3 font-sans text-xs">
        {generatedText ? (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3 select-text">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <span className="font-semibold text-slate-700 text-[11px]">
                Poccham Response
              </span>
              <button
                onClick={() => onApplyToWorkspace(generatedText)}
                className="flex items-center space-x-1 px-2 py-0.5 bg-sky-600 hover:bg-sky-700 text-white rounded text-[10px] font-medium transition"
              >
                <Check className="w-3 h-3" />
                <span>ワークスペースに適用</span>
              </button>
            </div>
            <div className="text-slate-800 whitespace-pre-wrap leading-relaxed">
              {generatedText}
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-4 text-slate-400 space-y-2">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-400 text-sm">
              P
            </div>
            <p className="text-xs font-medium text-slate-500">{t('ai.tagline')}</p>
            <p className="text-[11px] text-slate-400">
              オフライン完結・超高速推論で執筆やデータ分析をサポートします。
            </p>
          </div>
        )}
      </div>

      {/* Prompt Input Form */}
      <div className="p-3 border-t border-slate-200 bg-white">
        <form onSubmit={handleSubmit} className="space-y-2">
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={t('ai.askPlaceholder')}
              rows={3}
              disabled={!modelStatus?.is_ready}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 focus:outline-none resize-none transition pr-8 disabled:bg-slate-50 disabled:cursor-not-allowed"
            />
            {isGenerating ? (
              <button
                type="button"
                onClick={onStopGeneration}
                className="absolute right-2 bottom-3 p-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-lg transition"
                title={t('ai.stop')}
              >
                <Square className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={!prompt.trim() || !modelStatus?.is_ready}
                className="absolute right-2 bottom-3 p-1.5 bg-sky-600 hover:bg-sky-700 disabled:bg-slate-300 text-white rounded-lg transition shadow-sm"
                title={t('ai.generate')}
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          {isGenerating && (
            <div className="flex items-center space-x-1.5 text-[11px] text-sky-600 animate-pulse">
              <RefreshCw className="w-3 h-3 animate-spin" />
              <span>{t('ai.generating')}</span>
            </div>
          )}
        </form>
      </div>
    </aside>
  );
};
