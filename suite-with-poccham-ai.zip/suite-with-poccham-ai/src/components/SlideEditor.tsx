import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { SlideData } from '../types/office';
import { Plus, Trash2, MessageSquare } from 'lucide-react';

interface SlideEditorProps {
  slides: SlideData[];
  setSlides: (slides: SlideData[]) => void;
}

export const SlideEditor: React.FC<SlideEditorProps> = ({ slides, setSlides }) => {
  const { t } = useTranslation();
  const [currentIdx, setCurrentIdx] = useState(0);

  const activeSlide = slides[currentIdx] || {
    id: '1',
    title: '新規プレゼンテーション',
    bullets: ['最初のポイント'],
    notes: '',
  };

  const handleAddSlide = () => {
    const newSlide: SlideData = {
      id: Date.now().toString(),
      title: `${t('slide.slideTitle')} ${slides.length + 1}`,
      bullets: ['キーメッセージ 1', 'キーメッセージ 2'],
      notes: '',
    };
    setSlides([...slides, newSlide]);
    setCurrentIdx(slides.length);
  };

  const handleDeleteSlide = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (slides.length <= 1) return;
    const nextSlides = slides.filter((_, i) => i !== idx);
    setSlides(nextSlides);
    if (currentIdx >= nextSlides.length) {
      setCurrentIdx(nextSlides.length - 1);
    }
  };

  const updateActiveSlide = (updater: (slide: SlideData) => SlideData) => {
    const next = [...slides];
    next[currentIdx] = updater(activeSlide);
    setSlides(next);
  };

  return (
    <div className="flex-1 flex bg-slate-100 overflow-hidden select-none">
      {/* Slide Thumbnails Sidebar */}
      <div className="w-56 bg-slate-50 border-r border-slate-200 flex flex-col p-3 space-y-3 overflow-y-auto">
        <button
          onClick={handleAddSlide}
          className="flex items-center justify-center space-x-1.5 w-full py-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 shadow-sm transition"
        >
          <Plus className="w-3.5 h-3.5 text-amber-600" />
          <span>{t('slide.addSlide')}</span>
        </button>

        <div className="space-y-2.5">
          {slides.map((s, idx) => (
            <div
              key={s.id}
              onClick={() => setCurrentIdx(idx)}
              className={`p-2.5 rounded-lg border cursor-pointer relative group transition ${
                currentIdx === idx
                  ? 'bg-amber-50/70 border-amber-500 shadow-sm'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-mono text-slate-400 font-bold">#{idx + 1}</span>
                {slides.length > 1 && (
                  <button
                    onClick={(e) => handleDeleteSlide(idx, e)}
                    className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-400 hover:text-rose-600 rounded transition"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
              <div className="aspect-video bg-slate-100 rounded border border-slate-200/60 p-2 flex flex-col justify-center">
                <div className="text-[10px] font-bold text-slate-700 truncate">{s.title || 'Untitled'}</div>
                <div className="text-[8px] text-slate-400 line-clamp-2 mt-0.5">{s.bullets.join(' • ')}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Slide Stage */}
      <div className="flex-1 flex flex-col overflow-y-auto p-6 items-center">
        {/* 16:9 Presentation Canvas */}
        <div className="w-full max-w-3xl aspect-video bg-white shadow-md border border-slate-300/80 rounded-xl p-8 flex flex-col justify-between">
          <div>
            <input
              type="text"
              value={activeSlide.title}
              onChange={(e) => updateActiveSlide((s) => ({ ...s, title: e.target.value }))}
              placeholder={t('slide.slideTitle')}
              className="w-full text-2xl font-extrabold text-slate-800 border-b border-transparent hover:border-slate-200 focus:border-amber-500 focus:outline-none pb-1 transition"
            />

            <div className="mt-6 space-y-3">
              {activeSlide.bullets.map((b, bIdx) => (
                <div key={bIdx} className="flex items-start space-x-2">
                  <span className="text-amber-500 text-lg leading-none">•</span>
                  <input
                    type="text"
                    value={b}
                    onChange={(e) => {
                      const newBullets = [...activeSlide.bullets];
                      newBullets[bIdx] = e.target.value;
                      updateActiveSlide((s) => ({ ...s, bullets: newBullets }));
                    }}
                    placeholder={t('slide.bulletPlaceholder')}
                    className="flex-1 text-sm text-slate-700 bg-transparent border-b border-transparent hover:border-slate-200 focus:border-amber-400 focus:outline-none transition"
                  />
                </div>
              ))}
              <button
                onClick={() =>
                  updateActiveSlide((s) => ({
                    ...s,
                    bullets: [...s.bullets, `ポイント ${s.bullets.length + 1}`],
                  }))
                }
                className="text-xs text-amber-600 hover:text-amber-700 font-medium pt-1"
              >
                + 箇条書きを追加
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-100 pt-3">
            <span>Suite with Poccham AI</span>
            <span>{currentIdx + 1} / {slides.length}</span>
          </div>
        </div>

        {/* Presenter Notes */}
        <div className="w-full max-w-3xl mt-4 bg-white border border-slate-200 rounded-lg p-3 shadow-sm">
          <div className="flex items-center space-x-1.5 text-xs font-semibold text-slate-600 mb-1.5">
            <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
            <span>スピーカーノート（プレゼン用メモ）</span>
          </div>
          <textarea
            value={activeSlide.notes}
            onChange={(e) => updateActiveSlide((s) => ({ ...s, notes: e.target.value }))}
            placeholder={t('slide.notesPlaceholder')}
            rows={2}
            className="w-full text-xs text-slate-700 resize-none border-none focus:outline-none bg-slate-50/50 p-2 rounded"
          />
        </div>
      </div>
    </div>
  );
};
