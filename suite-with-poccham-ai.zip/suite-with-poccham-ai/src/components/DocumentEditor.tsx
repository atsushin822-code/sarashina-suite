import React from 'react';
import { useTranslation } from 'react-i18next';
import { Bold, Italic, List, Heading1, Heading2, Quote } from 'lucide-react';

interface DocumentEditorProps {
  content: string;
  setContent: (content: string) => void;
}

export const DocumentEditor: React.FC<DocumentEditorProps> = ({ content, setContent }) => {
  const { t } = useTranslation();

  const wordCount = content.trim().length;
  const lineCount = content.split('\n').filter(Boolean).length;

  return (
    <div className="flex-1 flex flex-col bg-slate-100 overflow-hidden">
      {/* Mini Document Toolbar */}
      <div className="h-10 bg-white border-b border-slate-200 px-4 flex items-center space-x-1 select-none">
        <button
          onClick={() => setContent(content + '\n# ')}
          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
          title="Heading 1"
        >
          <Heading1 className="w-4 h-4" />
        </button>
        <button
          onClick={() => setContent(content + '\n## ')}
          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
          title="Heading 2"
        >
          <Heading2 className="w-4 h-4" />
        </button>
        <div className="h-4 w-px bg-slate-200 mx-1" />
        <button
          onClick={() => setContent(content + '**太字**')}
          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
          title="Bold"
        >
          <Bold className="w-4 h-4" />
        </button>
        <button
          onClick={() => setContent(content + '*斜体*')}
          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
          title="Italic"
        >
          <Italic className="w-4 h-4" />
        </button>
        <button
          onClick={() => setContent(content + '\n- ')}
          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
          title="Bullet List"
        >
          <List className="w-4 h-4" />
        </button>
        <button
          onClick={() => setContent(content + '\n> ')}
          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded"
          title="Quote"
        >
          <Quote className="w-4 h-4" />
        </button>

        <div className="flex-1" />
        <div className="text-[11px] text-slate-400 font-mono space-x-3">
          <span>{lineCount} 行</span>
          <span>{wordCount} 文字</span>
        </div>
      </div>

      {/* Editor Canvas Container */}
      <div className="flex-1 overflow-y-auto p-6 flex justify-center">
        <div className="w-full max-w-4xl bg-white shadow-sm border border-slate-200/80 rounded-lg min-h-[800px] p-10 flex flex-col">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={t('doc.placeholder')}
            className="flex-1 w-full bg-transparent resize-none border-none focus:outline-none text-slate-800 text-sm leading-relaxed font-sans placeholder:text-slate-300"
          />
        </div>
      </div>
    </div>
  );
};
