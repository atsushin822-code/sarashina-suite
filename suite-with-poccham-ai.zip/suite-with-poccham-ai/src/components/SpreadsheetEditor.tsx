import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { SpreadsheetState } from '../types/office';
import { Calculator } from 'lucide-react';

interface SpreadsheetEditorProps {
  data: SpreadsheetState;
  setData: (data: SpreadsheetState) => void;
}

export const SpreadsheetEditor: React.FC<SpreadsheetEditorProps> = ({ data, setData }) => {
  const { t } = useTranslation();
  const [selectedCell, setSelectedCell] = useState<{ r: number; c: number }>({ r: 0, c: 0 });

  const numCols = 10;
  const numRows = 25;

  const getColLabel = (index: number) => String.fromCharCode(65 + index);

  const getCellValue = (r: number, c: number) => {
    if (data.rows[r] && data.rows[r][c] !== undefined) {
      return data.rows[r][c];
    }
    return '';
  };

  const handleCellChange = (r: number, c: number, val: string) => {
    const updatedRows = [...data.rows];
    while (updatedRows.length <= r) {
      updatedRows.push([]);
    }
    while (updatedRows[r].length <= c) {
      updatedRows[r].push('');
    }
    updatedRows[r][c] = val;
    setData({ ...data, rows: updatedRows });
  };

  const currentVal = getCellValue(selectedCell.r, selectedCell.c);

  return (
    <div className="flex-1 flex flex-col bg-slate-100 overflow-hidden select-none">
      {/* Formula Bar */}
      <div className="h-10 bg-white border-b border-slate-200 px-4 flex items-center space-x-2">
        <div className="flex items-center space-x-1 text-slate-400 font-mono text-xs w-16 bg-slate-50 py-1 px-2 rounded border border-slate-200">
          <Calculator className="w-3.5 h-3.5 text-emerald-600" />
          <span className="font-semibold text-slate-700">
            {getColLabel(selectedCell.c)}
            {selectedCell.r + 1}
          </span>
        </div>
        <div className="h-4 w-px bg-slate-200" />
        <input
          type="text"
          value={currentVal}
          onChange={(e) => handleCellChange(selectedCell.r, selectedCell.c, e.target.value)}
          placeholder={t('sheet.formulaPlaceholder')}
          className="flex-1 text-xs font-mono px-2 py-1 bg-transparent border-none focus:outline-none text-slate-800"
        />
      </div>

      {/* Grid Container */}
      <div className="flex-1 overflow-auto bg-white">
        <table className="border-collapse table-fixed w-full text-xs">
          <thead>
            <tr className="bg-slate-100/80 sticky top-0 z-10 border-b border-slate-300">
              <th className="w-12 bg-slate-200/60 border-r border-slate-300 font-normal text-slate-500 py-1"></th>
              {Array.from({ length: numCols }).map((_, c) => (
                <th
                  key={c}
                  className="w-28 border-r border-slate-300 font-medium text-slate-600 py-1 text-center"
                >
                  {getColLabel(c)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: numRows }).map((_, r) => (
              <tr key={r} className="border-b border-slate-200 hover:bg-slate-50/50">
                <td className="w-12 bg-slate-100/80 border-r border-slate-300 font-normal text-slate-500 text-center py-1 select-none">
                  {r + 1}
                </td>
                {Array.from({ length: numCols }).map((_, c) => {
                  const isSelected = selectedCell.r === r && selectedCell.c === c;
                  return (
                    <td
                      key={c}
                      onClick={() => setSelectedCell({ r, c })}
                      className={`border-r border-slate-200 p-0 relative ${
                        isSelected ? 'ring-2 ring-emerald-500 z-10' : ''
                      }`}
                    >
                      <input
                        type="text"
                        value={getCellValue(r, c)}
                        onChange={(e) => handleCellChange(r, c, e.target.value)}
                        className="w-full h-7 px-2 py-1 text-xs bg-transparent border-none focus:outline-none text-slate-800"
                      />
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
