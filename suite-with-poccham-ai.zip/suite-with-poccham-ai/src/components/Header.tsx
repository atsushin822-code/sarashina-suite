import React from 'react';
import { useTranslation } from 'react-i18next';
import { OfficeTab, ModelStatus } from '../types/office';
import { FileText, Table, Presentation, Globe, Save, FolderOpen, Share2 } from 'lucide-react';

interface HeaderProps {
  activeTab: OfficeTab;
  setActiveTab: (tab: OfficeTab) => void;
  docTitle: string;
  setDocTitle: (title: string) => void;
  modelStatus: ModelStatus | null;
  onOpenModelModal: () => void;
  onSave: () => void;
  onImport: () => void;
  onExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  docTitle,
  setDocTitle,
  modelStatus,
  onOpenModelModal,
  onSave,
  onImport,
  onExport,
}) => {
  const { t, i18n } = useTranslation();

  const toggleLanguage = () => {
    const nextLang = i18n.language === 'ja' ? 'en' : 'ja';
    i18n.changeLanguage(nextLang);
  };

  return (
    <header className="h-14 bg-white border-b border-slate-200 px-4 flex items-center justify-between select-none">
      {/* Brand & Tabs */}
      <div className="flex items-center space-x-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white shadow-sm font-bold text-lg">
            P
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-800 leading-tight">Suite</h1>
            <p className="text-[10px] text-sky-600 font-semibold tracking-wider">with Poccham AI</p>
          </div>
        </div>

        {/* Office Tab Switcher */}
        <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 space-x-1">
          <button
            onClick={() => setActiveTab('doc')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === 'doc'
                ? 'bg-white text-sky-700 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{t('nav.doc')}</span>
          </button>
          <button
            onClick={() => setActiveTab('sheet')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === 'sheet'
                ? 'bg-white text-emerald-700 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>{t('nav.sheet')}</span>
          </button>
          <button
            onClick={() => setActiveTab('slide')}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
              activeTab === 'slide'
                ? 'bg-white text-amber-700 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Presentation className="w-3.5 h-3.5" />
            <span>{t('nav.slide')}</span>
          </button>
        </div>

        {/* Title Editor */}
        <div className="flex items-center">
          <input
            type="text"
            value={docTitle}
            onChange={(e) => setDocTitle(e.target.value)}
            className="text-xs font-semibold px-2 py-1 text-slate-700 bg-transparent hover:bg-slate-100 focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500 rounded border border-transparent hover:border-slate-300 w-48 transition"
            placeholder={t('common.title')}
          />
        </div>
      </div>

      {/* Action Buttons & AI Status */}
      <div className="flex items-center space-x-3">
        {/* File Actions */}
        <div className="flex items-center space-x-1 border-r border-slate-200 pr-3">
          <button
            onClick={onSave}
            title={t('common.save')}
            className="p-1.5 text-slate-600 hover:text-sky-600 hover:bg-slate-100 rounded transition"
          >
            <Save className="w-4 h-4" />
          </button>
          <button
            onClick={onImport}
            title={t('common.import')}
            className="p-1.5 text-slate-600 hover:text-sky-600 hover:bg-slate-100 rounded transition"
          >
            <FolderOpen className="w-4 h-4" />
          </button>
          <button
            onClick={onExport}
            title={t('common.export')}
            className="p-1.5 text-slate-600 hover:text-sky-600 hover:bg-slate-100 rounded transition"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

        {/* Poccham AI Engine Status Button */}
        <button
          onClick={onOpenModelModal}
          className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition ${
            modelStatus?.is_ready
              ? 'bg-sky-50 border-sky-200 text-sky-700 hover:bg-sky-100'
              : 'bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100 animate-pulse'
          }`}
        >
          {modelStatus?.is_ready ? (
            <>
              <span className="w-2 h-2 rounded-full bg-sky-600 inline-block"></span>
              <span>Poccham AI Active</span>
            </>
          ) : (
            <>
              <span className="w-2 h-2 rounded-full bg-amber-600 inline-block animate-ping"></span>
              <span>{t('ai.downloadEngine')}</span>
            </>
          )}
        </button>

        {/* Language Switcher */}
        <button
          onClick={toggleLanguage}
          className="flex items-center space-x-1 px-2 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded border border-slate-200 transition"
        >
          <Globe className="w-3.5 h-3.5" />
          <span>{i18n.language.toUpperCase()}</span>
        </button>
      </div>
    </header>
  );
};
