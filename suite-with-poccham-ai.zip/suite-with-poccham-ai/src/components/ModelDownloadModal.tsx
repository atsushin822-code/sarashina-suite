import React from 'react';
import { useTranslation } from 'react-i18next';
import { DownloadProgressPayload, ModelStatus } from '../types/office';
import { X, HardDrive, CheckCircle2, ArrowDownCircle, ShieldCheck } from 'lucide-react';

interface ModelDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  modelStatus: ModelStatus | null;
  downloadProgress: DownloadProgressPayload | null;
  onStartDownload: () => void;
  onCancelDownload: () => void;
}

export const ModelDownloadModal: React.FC<ModelDownloadModalProps> = ({
  isOpen,
  onClose,
  modelStatus,
  downloadProgress,
  onStartDownload,
  onCancelDownload,
}) => {
  const { t } = useTranslation();

  if (!isOpen) return null;

  const isDownloading = modelStatus?.is_downloading;
  const isReady = modelStatus?.is_ready;

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden transition-all transform animate-in fade-in zoom-in duration-200">
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-sky-600 via-indigo-600 to-sky-700 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-white/20 rounded-xl backdrop-blur-md flex items-center justify-center font-bold text-white text-sm">
              P
            </div>
            <div>
              <h2 className="text-base font-bold">{t('modal.downloadTitle')}</h2>
              <p className="text-xs text-sky-100">{t('ai.tagline')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          <p className="text-xs text-slate-600 leading-relaxed">
            {t('modal.downloadDesc')}
          </p>

          {/* Status Box */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center space-x-1.5">
                <HardDrive className="w-4 h-4 text-sky-600" />
                <span>Engine Package: poccham-ai-core.gguf</span>
              </span>
              <span className="text-slate-500 font-mono text-[11px]">{t('modal.fileSize')}</span>
            </div>

            <div className="flex items-center space-x-2 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{t('common.offline')}</span>
            </div>

            {/* Progress or Ready Indicator */}
            {isReady && !isDownloading && (
              <div className="flex items-center space-x-2 p-3 bg-emerald-50 text-emerald-800 rounded-lg border border-emerald-200 text-xs">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <div className="font-medium">
                  {t('modal.completed')}
                  <div className="text-[11px] text-emerald-600 font-normal">
                    Location: {modelStatus?.model_path}
                  </div>
                </div>
              </div>
            )}

            {isDownloading && downloadProgress && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span>{downloadProgress.status}</span>
                  <span className="font-mono text-sky-600">{downloadProgress.percentage.toFixed(1)}%</span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-sky-500 to-indigo-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${downloadProgress.percentage}%` }}
                  />
                </div>

                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>
                    {formatBytes(downloadProgress.downloaded_bytes)} / {formatBytes(downloadProgress.total_bytes)}
                  </span>
                  <span>{downloadProgress.speed_mbps.toFixed(1)} MB/s</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-3">
          {isDownloading ? (
            <button
              onClick={onCancelDownload}
              className="px-4 py-2 text-xs font-medium text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg border border-rose-200 transition"
            >
              {t('modal.cancel')}
            </button>
          ) : isReady ? (
            <button
              onClick={onClose}
              className="px-5 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-sm transition"
            >
              閉じる
            </button>
          ) : (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-200/50 rounded-lg transition"
              >
                {t('modal.cancel')}
              </button>
              <button
                onClick={onStartDownload}
                className="flex items-center space-x-1.5 px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 rounded-lg shadow-sm shadow-sky-600/30 transition transform active:scale-95"
              >
                <ArrowDownCircle className="w-4 h-4" />
                <span>{t('modal.startDownload')}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
