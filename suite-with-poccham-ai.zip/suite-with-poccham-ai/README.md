# Suite with Poccham AI

次世代のローカル・オフライン完結型 超軽量・高速 統合Officeアプリケーション

## 🌟 特徴

- **3-in-1 統合Office**: ドキュメント (`.docx`)、スプレッドシート (`.xlsx` / `.csv`)、スライド (`.pptx`) の3つの機能を1つの高速アプリに統合。
- **Poccham AI 統合**: ドキュメント要約、校正、数式提案、プレゼン骨子生成をローカル推論エンジンで提供。
- **完全オフライン & ローカルファースト**: すべてのデータは SQLite にローカル保存され、外部クラウドへ一切送信されません。
- **超軽量・超高速**: Tauri (Rust) + Webview + C++推論コア (`llama.cpp`) により、リソース消費を最小化。
- **マルチプラットフォーム & ポータブル対応**:
  - Windows: インストーラー版 (`.msi` / `.exe`) & 単体実行ポータブル版 (`.exe`)
  - macOS: Apple Silicon / Intel (`.dmg`)
  - Linux: ポータブル (`.AppImage`) / Debian (`.deb`)

## 🚀 開発環境のセットアップ

### 必要要件
- Node.js 20+
- Rust 1.75+
- C/C++ コンパイラ (MSVC, Clang, GCC) & CMake

```bash
# 依存関係のインストール
npm install

# 開発サーバー起動
npm run tauri dev

# プロダクションビルド
npm run tauri build
```

## 📦 GitHub Actions による自動リリース

Git タグ (`v1.0.0` など) をプッシュするだけで、GitHub Actions が各OS向けにビルドし、GitHub Releases へ成果物を自動アップロードします。
