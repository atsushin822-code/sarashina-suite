use rusqlite::{params, Connection, Result};
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::Mutex;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct OfficeDocument {
    pub id: String,
    pub title: String,
    pub doc_type: String, // "doc", "sheet", "slide"
    pub content: String,  // JSON or text string
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct AIHistoryRecord {
    pub id: String,
    pub doc_id: Option<String>,
    pub role: String,    // "user", "assistant"
    pub message: String,
    pub timestamp: String,
}

pub struct DatabaseManager {
    conn: Mutex<Connection>,
}

impl DatabaseManager {
    pub fn new<P: AsRef<Path>>(db_path: P) -> Result<Self> {
        let conn = Connection::open(db_path)?;
        let manager = Self {
            conn: Mutex::new(conn),
        };
        manager.init_tables()?;
        Ok(manager)
    }

    fn init_tables(&self) -> Result<()> {
        let conn = self.conn.lock().unwrap();

        // 1. Core documents table
        conn.execute(
            "CREATE TABLE IF NOT EXISTS documents (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                doc_type TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );",
            [],
        )?;

        // 2. Poccham AI conversation and assist history
        conn.execute(
            "CREATE TABLE IF NOT EXISTS ai_history (
                id TEXT PRIMARY KEY,
                doc_id TEXT,
                role TEXT NOT NULL,
                message TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY(doc_id) REFERENCES documents(id) ON DELETE CASCADE
            );",
            [],
        )?;

        // 3. User settings & Poccham AI runtime configuration
        conn.execute(
            "CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );",
            [],
        )?;

        Ok(())
    }

    pub fn save_document(&self, doc: &OfficeDocument) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT INTO documents (id, title, doc_type, content, created_at, updated_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6)
             ON CONFLICT(id) DO UPDATE SET
                title = excluded.title,
                doc_type = excluded.doc_type,
                content = excluded.content,
                updated_at = excluded.updated_at;",
            params![
                doc.id,
                doc.title,
                doc.doc_type,
                doc.content,
                doc.created_at,
                doc.updated_at
            ],
        )?;
        Ok(())
    }

    pub fn get_document(&self, id: &str) -> Result<Option<OfficeDocument>> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn.prepare(
            "SELECT id, title, doc_type, content, created_at, updated_at FROM documents WHERE id = ?1",
        )?;
        let mut rows = stmt.query(params![id])?;

        if let Some(row) = rows.next()? {
            Ok(Some(OfficeDocument {
                id: row.get(0)?,
                title: row.get(1)?,
                doc_type: row.get(2)?,
                content: row.get(3)?,
                created_at: row.get(4)?,
                updated_at: row.get(5)?,
            }))
        } else {
            Ok(None)
        }
    }

    pub fn list_documents(&self, doc_type: Option<&str>) -> Result<Vec<OfficeDocument>> {
        let conn = self.conn.lock().unwrap();
        let mut docs = Vec::new();

        if let Some(dtype) = doc_type {
            let mut stmt = conn.prepare(
                "SELECT id, title, doc_type, content, created_at, updated_at FROM documents WHERE doc_type = ?1 ORDER BY updated_at DESC",
            )?;
            let rows = stmt.query_map(params![dtype], |row| {
                Ok(OfficeDocument {
                    id: row.get(0)?,
                    title: row.get(1)?,
                    doc_type: row.get(2)?,
                    content: row.get(3)?,
                    created_at: row.get(4)?,
                    updated_at: row.get(5)?,
                })
            })?;
            for r in rows {
                docs.push(r?);
            }
        } else {
            let mut stmt = conn.prepare(
                "SELECT id, title, doc_type, content, created_at, updated_at FROM documents ORDER BY updated_at DESC",
            )?;
            let rows = stmt.query_map([], |row| {
                Ok(OfficeDocument {
                    id: row.get(0)?,
                    title: row.get(1)?,
                    doc_type: row.get(2)?,
                    content: row.get(3)?,
                    created_at: row.get(4)?,
                    updated_at: row.get(5)?,
                })
            })?;
            for r in rows {
                docs.push(r?);
            }
        }

        Ok(docs)
    }

    pub fn delete_document(&self, id: &str) -> Result<bool> {
        let conn = self.conn.lock().unwrap();
        let count = conn.execute("DELETE FROM documents WHERE id = ?1", params![id])?;
        Ok(count > 0)
    }

    pub fn set_setting(&self, key: &str, value: &str) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT INTO app_settings (key, value) VALUES (?1, ?2)
             ON CONFLICT(key) DO UPDATE SET value = excluded.value;",
            params![key, value],
        )?;
        Ok(())
    }

    pub fn get_setting(&self, key: &str) -> Result<Option<String>> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn.prepare("SELECT value FROM app_settings WHERE key = ?1")?;
        let mut rows = stmt.query(params![key])?;
        if let Some(row) = rows.next()? {
            Ok(Some(row.get(0)?))
        } else {
            Ok(None)
        }
    }
}
