pub mod ai;
pub mod office;
pub mod storage;

use ai::{ModelStatus, OfficeContext, PocchamDownloader, PocchamInferenceEngine};
use office::converter::{OfficeFileManager, SpreadsheetData};
use storage::db::{DatabaseManager, OfficeDocument};

use std::sync::Arc;
use tauri::{AppHandle, Manager, State};

pub struct AppState {
    pub db: Arc<DatabaseManager>,
    pub downloader: Arc<PocchamDownloader>,
    pub inference: Arc<PocchamInferenceEngine>,
}

#[tauri::command]
pub fn get_model_status(state: State<'_, AppState>) -> Result<ModelStatus, String> {
    Ok(state.downloader.get_status())
}

#[tauri::command]
pub async fn start_download_poccham_engine(
    app_handle: AppHandle,
    state: State<'_, AppState>,
) -> Result<String, String> {
    let downloader = state.downloader.clone();
    tokio::spawn(async move {
        if let Err(e) = downloader.start_download(app_handle).await {
            eprintln!("[Poccham AI] Download task encountered an issue: {:?}", e);
        }
    });
    Ok("Poccham AI Core download initiated".to_string())
}

#[tauri::command]
pub fn cancel_download_poccham_engine(state: State<'_, AppState>) -> Result<String, String> {
    state.downloader.request_cancel();
    Ok("Cancellation requested".to_string())
}

#[tauri::command]
pub async fn generate_poccham_ai_completion(
    app_handle: AppHandle,
    state: State<'_, AppState>,
    prompt: String,
    context_type: OfficeContext,
    current_content: Option<String>,
) -> Result<String, String> {
    let req = ai::inference::InferenceRequest {
        prompt,
        context_type,
        current_content,
        max_tokens: Some(1024),
        temperature: Some(0.7),
    };
    state.inference.generate_stream(req, app_handle).await
}

#[tauri::command]
pub fn save_document(
    state: State<'_, AppState>,
    doc: OfficeDocument,
) -> Result<bool, String> {
    state.db.save_document(&doc).map_err(|e| e.to_string())?;
    Ok(true)
}

#[tauri::command]
pub fn load_document(
    state: State<'_, AppState>,
    id: String,
) -> Result<Option<OfficeDocument>, String> {
    state.db.get_document(&id).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn list_documents(
    state: State<'_, AppState>,
    doc_type: Option<String>,
) -> Result<Vec<OfficeDocument>, String> {
    state.db.list_documents(doc_type.as_deref()).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn delete_document(
    state: State<'_, AppState>,
    id: String,
) -> Result<bool, String> {
    state.db.delete_document(&id).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn import_office_document(path: String) -> Result<String, String> {
    OfficeFileManager::read_document_file(path)
}

#[tauri::command]
pub fn export_office_document(path: String, text: String) -> Result<bool, String> {
    OfficeFileManager::write_docx_file(path, &text)?;
    Ok(true)
}

#[tauri::command]
pub fn import_spreadsheet(path: String) -> Result<SpreadsheetData, String> {
    OfficeFileManager::read_spreadsheet_file(path)
}

#[tauri::command]
pub fn export_spreadsheet_csv(path: String, rows: Vec<Vec<String>>) -> Result<bool, String> {
    OfficeFileManager::write_csv_file(path, &rows)?;
    Ok(true)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .setup(|app| {
            let app_data_dir = app
                .path()
                .app_data_dir()
                .unwrap_or_else(|_| std::env::current_dir().unwrap().join(".poccham_suite_data"));

            if !app_data_dir.exists() {
                let _ = std::fs::create_dir_all(&app_data_dir);
            }

            let db_path = app_data_dir.join("suite_workspace.db");
            let db = DatabaseManager::new(db_path).expect("Failed to initialize SQLite storage for Suite");

            let downloader = PocchamDownloader::new(&app_data_dir);
            let model_path = downloader.get_model_path();
            let inference = PocchamInferenceEngine::new(model_path);

            app.manage(AppState {
                db: Arc::new(db),
                downloader: Arc::new(downloader),
                inference: Arc::new(inference),
            });

            println!("[Suite with Poccham AI] Core initialized successfully. Local-first storage ready.");
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_model_status,
            start_download_poccham_engine,
            cancel_download_poccham_engine,
            generate_poccham_ai_completion,
            save_document,
            load_document,
            list_documents,
            delete_document,
            import_office_document,
            export_office_document,
            import_spreadsheet,
            export_spreadsheet_csv
        ])
        .run(tauri::generate_context!())
        .expect("error while running Suite with Poccham AI");
}
