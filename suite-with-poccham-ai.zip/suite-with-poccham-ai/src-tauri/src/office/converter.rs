use calamine::{open_workbook_auto, DataType, Reader};
use docx_rs::{Docx, Paragraph, Run};
use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::{Read, Write};
use std::path::Path;

#[derive(Debug, Serialize, Deserialize)]
pub struct SpreadsheetData {
    pub sheet_names: Vec<String>,
    pub active_sheet: String,
    pub rows: Vec<Vec<String>>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct SlideItem {
    pub id: String,
    pub title: String,
    pub bullets: Vec<String>,
    pub notes: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PresentationData {
    pub title: String,
    pub slides: Vec<SlideItem>,
}

pub struct OfficeFileManager;

impl OfficeFileManager {
    /// Read text content from a plain or markdown document, or convert docx to plain text
    pub fn read_document_file<P: AsRef<Path>>(path: P) -> Result<String, String> {
        let path_ref = path.as_ref();
        let ext = path_ref
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_lowercase();

        match ext.as_str() {
            "txt" | "md" => {
                let mut content = String::new();
                let mut f = File::open(path_ref).map_err(|e| e.to_string())?;
                f.read_to_string(&mut content).map_err(|e| e.to_string())?;
                Ok(content)
            }
            "docx" => {
                // Extract word/document.xml from zip archive
                let file = File::open(path_ref).map_err(|e| e.to_string())?;
                let mut archive = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
                let mut xml_content = String::new();

                match archive.by_name("word/document.xml") {
                    Ok(mut zip_file) => {
                        zip_file.read_to_string(&mut xml_content).map_err(|e| e.to_string())?;
                        // Strip XML tags to retrieve readable text
                        let re = regex::Regex::new(r"<[^>]*>").map_err(|e| e.to_string())?;
                        let cleaned = re.replace_all(&xml_content, " ").to_string();
                        Ok(cleaned.split_whitespace().collect::<Vec<_>>().join(" "))
                    }
                    Err(_) => Err("Invalid docx format: word/document.xml not found".to_string()),
                }
            }
            _ => Err("Unsupported document format".to_string()),
        }
    }

    /// Save text as a formatted .docx file
    pub fn write_docx_file<P: AsRef<Path>>(path: P, text: &str) -> Result<(), String> {
        let file = File::create(path).map_err(|e| e.to_string())?;
        let mut docx = Docx::new();

        for line in text.lines() {
            if !line.trim().is_empty() {
                docx = docx.add_paragraph(Paragraph::new().add_run(Run::new().add_text(line)));
            } else {
                docx = docx.add_paragraph(Paragraph::new());
            }
        }

        docx.build().pack(file).map_err(|e| format!("Docx pack error: {:?}", e))?;
        Ok(())
    }

    /// Read XLSX or CSV file into 2D tabular structure
    pub fn read_spreadsheet_file<P: AsRef<Path>>(path: P) -> Result<SpreadsheetData, String> {
        let path_ref = path.as_ref();
        let ext = path_ref
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_lowercase();

        if ext == "csv" {
            let mut rdr = csv::Reader::from_path(path_ref).map_err(|e| e.to_string())?;
            let mut rows = Vec::new();

            // Include headers as first row
            if let Ok(headers) = rdr.headers() {
                rows.push(headers.iter().map(|s| s.to_string()).collect());
            }

            for result in rdr.records() {
                let record = result.map_err(|e| e.to_string())?;
                rows.push(record.iter().map(|s| s.to_string()).collect());
            }

            return Ok(SpreadsheetData {
                sheet_names: vec!["Sheet1".to_string()],
                active_sheet: "Sheet1".to_string(),
                rows,
            });
        }

        // Handle xlsx via calamine
        let mut workbook = open_workbook_auto(path_ref).map_err(|e| e.to_string())?;
        let sheet_names = workbook.sheet_names().to_vec();
        let first_sheet = sheet_names.first().cloned().unwrap_or_else(|| "Sheet1".to_string());

        let mut rows = Vec::new();
        if let Some(Ok(range)) = workbook.worksheet_range(&first_sheet) {
            for row in range.rows() {
                let row_data: Vec<String> = row
                    .iter()
                    .map(|cell| match cell {
                        DataType::Empty => "".to_string(),
                        DataType::String(s) => s.clone(),
                        DataType::Float(f) => format!("{:.2}", f),
                        DataType::Int(i) => i.to_string(),
                        DataType::Bool(b) => b.to_string(),
                        DataType::DateTime(d) => format!("{:.4}", d),
                        DataType::Error(e) => format!("ERROR: {:?}", e),
                    })
                    .collect();
                rows.push(row_data);
            }
        }

        Ok(SpreadsheetData {
            sheet_names,
            active_sheet: first_sheet,
            rows,
        })
    }

    /// Save tabular data as CSV
    pub fn write_csv_file<P: AsRef<Path>>(path: P, rows: &[Vec<String>]) -> Result<(), String> {
        let mut wtr = csv::Writer::from_path(path).map_err(|e| e.to_string())?;
        for row in rows {
            wtr.write_record(row).map_err(|e| e.to_string())?;
        }
        wtr.flush().map_err(|e| e.to_string())?;
        Ok(())
    }
}
