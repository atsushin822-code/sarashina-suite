use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use std::fs::{self, File};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;
use tauri::{AppHandle, Emitter};

pub const POCCHAM_CORE_MODEL_FILENAME: &str = "poccham-ai-core.gguf";

// Internal upstream endpoint for Poccham AI Core Intelligence.
// Note: Internal pointer references high-precision quantized Sarashina GGUF,
// completely encapsulated and rebranded as Poccham AI Core across the application.
pub const POCCHAM_ENGINE_SOURCE_URL: &str =
    "https://huggingface.co/mmnga/sarashina-2-3b-instruct-gguf/resolve/main/sarashina-2-3b-instruct-Q4_K_M.gguf";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelStatus {
    pub is_ready: bool,
    pub is_downloading: bool,
    pub file_size_bytes: u64,
    pub model_path: String,
    pub engine_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadProgressPayload {
    pub downloaded_bytes: u64,
    pub total_bytes: u64,
    pub percentage: f64,
    pub speed_mbps: f64,
    pub status: String,
}

pub struct PocchamDownloader {
    models_dir: PathBuf,
    is_downloading: Arc<AtomicBool>,
    cancel_requested: Arc<AtomicBool>,
}

impl PocchamDownloader {
    pub fn new(app_data_dir: &Path) -> Self {
        let models_dir = app_data_dir.join("poccham-ai").join("models");
        if !models_dir.exists() {
            let _ = fs::create_dir_all(&models_dir);
        }
        Self {
            models_dir,
            is_downloading: Arc::new(AtomicBool::new(false)),
            cancel_requested: Arc::new(AtomicBool::new(false)),
        }
    }

    pub fn get_model_path(&self) -> PathBuf {
        self.models_dir.join(POCCHAM_CORE_MODEL_FILENAME)
    }

    pub fn is_model_ready(&self) -> bool {
        let p = self.get_model_path();
        p.exists() && fs::metadata(&p).map(|m| m.len() > 100_000_000).unwrap_or(false)
    }

    pub fn get_status(&self) -> ModelStatus {
        let path = self.get_model_path();
        let is_ready = self.is_model_ready();
        let file_size_bytes = if is_ready {
            fs::metadata(&path).map(|m| m.len()).unwrap_or(0)
        } else {
            0
        };

        ModelStatus {
            is_ready,
            is_downloading: self.is_downloading.load(Ordering::SeqCst),
            file_size_bytes,
            model_path: path.to_string_lossy().to_string(),
            engine_version: "Poccham-v2.1-Core".to_string(),
        }
    }

    pub fn request_cancel(&self) {
        if self.is_downloading.load(Ordering::SeqCst) {
            self.cancel_requested.store(true, Ordering::SeqCst);
        }
    }

    pub async fn start_download(
        &self,
        app_handle: AppHandle,
    ) -> Result<PathBuf, Box<dyn std::error::Error + Send + Sync>> {
        if self.is_downloading.load(Ordering::SeqCst) {
            return Err("Poccham AI Engine download is already in progress.".into());
        }

        self.is_downloading.store(true, Ordering::SeqCst);
        self.cancel_requested.store(false, Ordering::SeqCst);

        let final_path = self.get_model_path();
        let temp_path = self.models_dir.join(format!("{}.part", POCCHAM_CORE_MODEL_FILENAME));

        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(3600))
            .build()?;

        let response = match client.get(POCCHAM_ENGINE_SOURCE_URL).send().await {
            Ok(res) => {
                if !res.status().is_success() {
                    self.is_downloading.store(false, Ordering::SeqCst);
                    return Err(format!("Server returned HTTP {}", res.status()).into());
                }
                res
            }
            Err(e) => {
                self.is_downloading.store(false, Ordering::SeqCst);
                return Err(format!("Connection error during Poccham AI engine retrieval: {}", e).into());
            }
        };

        let total_size = response.content_length().unwrap_or(0);
        let mut file = File::create(&temp_path)?;
        let mut downloaded: u64 = 0;
        let mut stream = response.bytes_stream();

        let start_time = Instant::now();
        let mut last_emit = Instant::now();

        println!("[Poccham AI] Initiating Core Engine installation (Target: {})...", final_path.display());

        while let Some(chunk_result) = stream.next().await {
            if self.cancel_requested.load(Ordering::SeqCst) {
                drop(file);
                let _ = fs::remove_file(&temp_path);
                self.is_downloading.store(false, Ordering::SeqCst);
                self.cancel_requested.store(false, Ordering::SeqCst);
                return Err("Poccham AI Engine download cancelled by user.".into());
            }

            let chunk = match chunk_result {
                Ok(c) => c,
                Err(e) => {
                    self.is_downloading.store(false, Ordering::SeqCst);
                    return Err(format!("Stream interruption: {}", e).into());
                }
            };

            file.write_all(&chunk)?;
            downloaded += chunk.len() as u64;

            // Emit progress at most every 150ms to keep UI fluid
            if last_emit.elapsed().as_millis() >= 150 || downloaded == total_size {
                let elapsed_secs = start_time.elapsed().as_secs_f64();
                let speed_mbps = if elapsed_secs > 0.0 {
                    (downloaded as f64 / 1_048_576.0) / elapsed_secs
                } else {
                    0.0
                };

                let percentage = if total_size > 0 {
                    (downloaded as f64 / total_size as f64) * 100.0
                } else {
                    0.0
                };

                let payload = DownloadProgressPayload {
                    downloaded_bytes: downloaded,
                    total_bytes: total_size,
                    percentage,
                    speed_mbps,
                    status: "Downloading Poccham AI Core Engine...".to_string(),
                };

                let _ = app_handle.emit("poccham-download-progress", payload);
                last_emit = Instant::now();
            }
        }

        file.flush()?;
        drop(file);

        // Atomic rename of the downloaded model
        fs::rename(&temp_path, &final_path)?;
        self.is_downloading.store(false, Ordering::SeqCst);

        println!("[Poccham AI] Core Engine setup completed successfully.");
        let _ = app_handle.emit(
            "poccham-download-progress",
            DownloadProgressPayload {
                downloaded_bytes: total_size,
                total_bytes: total_size,
                percentage: 100.0,
                speed_mbps: 0.0,
                status: "Poccham AI Engine Ready".to_string(),
            },
        );

        Ok(final_path)
    }
}
