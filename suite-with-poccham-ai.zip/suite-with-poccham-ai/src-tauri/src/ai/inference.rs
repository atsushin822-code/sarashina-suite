use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::{AppHandle, Emitter};

// llama-cpp-2 FFI bindings
use llama_cpp_2::context::params::LlamaContextParams;
use llama_cpp_2::llama_backend::LlamaBackend;
use llama_cpp_2::model::params::LlamaModelParams;
use llama_cpp_2::model::LlamaModel;
use llama_cpp_2::sampling::LlamaSampler;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum OfficeContext {
    Document,
    Spreadsheet,
    Slide,
    General,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceRequest {
    pub prompt: String,
    pub context_type: OfficeContext,
    pub current_content: Option<String>,
    pub max_tokens: Option<u32>,
    pub temperature: Option<f32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenStreamPayload {
    pub token: String,
    pub is_done: bool,
}

pub struct PocchamInferenceEngine {
    model_path: PathBuf,
    // Cached backend reference
    backend: Mutex<Option<LlamaBackend>>,
}

impl PocchamInferenceEngine {
    pub fn new(model_path: PathBuf) -> Self {
        Self {
            model_path,
            backend: Mutex::new(None),
        }
    }

    fn ensure_backend(&self) -> Result<(), String> {
        let mut guard = self.backend.lock().map_err(|e| e.to_string())?;
        if guard.is_none() {
            let backend = LlamaBackend::init().map_err(|e| format!("Failed to init Poccham AI backend: {:?}", e))?;
            *guard = Some(backend);
        }
        Ok(())
    }

    /// Construct specialized system prompt tailored for Office Suites without exposing upstream model names
    fn build_prompt(&self, req: &InferenceRequest) -> String {
        let system_role = match req.context_type {
            OfficeContext::Document => {
                "You are Poccham AI, an elite document intelligence co-pilot. Assist the user with executive drafting, proofreading, document restructuring, and professional tone polishing in Japanese or English as requested. Provide concise, clear, and ready-to-paste outputs."
            }
            OfficeContext::Spreadsheet => {
                "You are Poccham AI, an elite spreadsheet data intelligence assistant. Help formulate spreadsheet formulas (e.g. SUM, AVERAGE, XLOOKUP, INDEX/MATCH, IF), clean tabular data, and provide statistical insights. When suggesting formulas, output the exact formula clearly."
            }
            OfficeContext::Slide => {
                "You are Poccham AI, a high-impact presentation slide architect. Generate presentation slide structures, powerful headlines, and punchy bulleted takeaways (3-5 points per slide) optimized for visual executive decks."
            }
            OfficeContext::General => {
                "You are Poccham AI, the built-in intelligent engine for Suite with Poccham AI. Provide accurate, ultra-fast, and helpful assistance."
            }
        };

        let mut formatted = format!("<|im_start|>system\n{}<|im_end|>\n", system_role);

        if let Some(content) = &req.current_content {
            if !content.trim().is_empty() {
                formatted.push_str(&format!(
                    "<|im_start|>user\n[Current Workspace Context]:\n\"\"\"\n{}\n\"\"\"\n\nRequest: {}<|im_end|>\n<|im_start|>assistant\n",
                    content, req.prompt
                ));
                return formatted;
            }
        }

        formatted.push_str(&format!(
            "<|im_start|>user\n{}<|im_end|>\n<|im_start|>assistant\n",
            req.prompt
        ));
        formatted
    }

    /// Run streaming text generation directly with llama-cpp-2
    pub async fn generate_stream(
        &self,
        req: InferenceRequest,
        app_handle: AppHandle,
    ) -> Result<String, String> {
        if !self.model_path.exists() {
            return Err("Poccham AI Core Engine model file is not found. Please download it first.".to_string());
        }

        self.ensure_backend()?;

        let full_prompt = self.build_prompt(&req);
        let max_tokens = req.max_tokens.unwrap_or(1024) as usize;
        let model_path = self.model_path.clone();

        // Run inference in a blocking background thread to prevent blocking the async Tokio runtime
        tokio::task::spawn_blocking(move || {
            let backend = match LlamaBackend::init() {
                Ok(b) => b,
                Err(e) => return Err(format!("Poccham AI Engine initialization failed: {:?}", e)),
            };

            let model_params = LlamaModelParams::default();
            let model = match LlamaModel::load_from_file(&backend, &model_path, &model_params) {
                Ok(m) => m,
                Err(e) => return Err(format!("Failed to load Poccham AI Core: {:?}", e)),
            };

            let mut ctx_params = LlamaContextParams::default();
            ctx_params = ctx_params.with_n_ctx(Some(std::num::NonZeroU32::new(4096).unwrap()));

            let mut ctx = match model.new_context(&backend, ctx_params) {
                Ok(c) => c,
                Err(e) => return Err(format!("Context creation error: {:?}", e)),
            };

            let tokens = match model.str_to_token(&full_prompt, llama_cpp_2::model::AddBos::Always) {
                Ok(t) => t,
                Err(e) => return Err(format!("Tokenization error: {:?}", e)),
            };

            // Process prompt tokens in batch
            let mut batch = llama_cpp_2::llama_batch::LlamaBatch::new(2048, 1);
            let last_token_idx = tokens.len().saturating_sub(1);
            for (i, token) in tokens.iter().enumerate() {
                let is_last = i == last_token_idx;
                batch.add(*token, i as i32, &[0], is_last).map_err(|e| format!("{:?}", e))?;
            }

            ctx.decode(&mut batch).map_err(|e| format!("Poccham AI decode error: {:?}", e))?;

            let mut sampler = LlamaSampler::chain_simple([
                LlamaSampler::temp(req.temperature.unwrap_or(0.7)),
                LlamaSampler::top_p(0.9, 1),
                LlamaSampler::greedy(),
            ]);

            let mut full_output = String::new();
            let mut n_cur = tokens.len() as i32;

            for _ in 0..max_tokens {
                let token = sampler.sample(&ctx, batch.n_tokens() - 1);
                sampler.accept(token);

                if model.is_eog_token(token) {
                    break;
                }

                let piece_bytes = match model.token_to_bytes(token, llama_cpp_2::model::Special::Tokenize) {
                    Ok(b) => b,
                    Err(_) => continue,
                };

                let piece_str = String::from_utf8_lossy(&piece_bytes).to_string();
                full_output.push_str(&piece_str);

                // Stream token to UI
                let _ = app_handle.emit(
                    "poccham-stream-token",
                    TokenStreamPayload {
                        token: piece_str,
                        is_done: false,
                    },
                );

                batch.clear();
                batch.add(token, n_cur, &[0], true).map_err(|e| format!("{:?}", e))?;
                n_cur += 1;

                if let Err(e) = ctx.decode(&mut batch) {
                    return Err(format!("Decode iteration error: {:?}", e));
                }
            }

            // Signal stream completion
            let _ = app_handle.emit(
                "poccham-stream-token",
                TokenStreamPayload {
                    token: String::new(),
                    is_done: true,
                },
            );

            Ok(full_output)
        })
        .await
        .map_err(|e| format!("Thread task execution error: {}", e))?
    }
}
