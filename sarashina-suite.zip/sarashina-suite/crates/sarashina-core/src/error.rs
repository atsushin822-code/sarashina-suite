use serde::{Serialize, Serializer};

pub type Result<T> = std::result::Result<T, CoreError>;

/// アプリ全体で共有するエラー型。
/// Tauri コマンドの戻り値としてそのままフロントへ渡せるよう、文字列にシリアライズする。
#[derive(Debug, thiserror::Error)]
pub enum CoreError {
    #[error("データベースエラー: {0}")]
    Db(#[from] rusqlite::Error),

    #[error("ファイル入出力エラー: {0}")]
    Io(#[from] std::io::Error),

    #[error("ネットワークエラー: {0}")]
    Net(String),

    #[error("モデルエラー: {0}")]
    Model(String),

    #[error("推論エンジンエラー: {0}")]
    Inference(String),

    #[error("見つかりません: {0}")]
    NotFound(String),

    #[error("不正な入力: {0}")]
    Invalid(String),

    #[error("キャンセルされました")]
    Cancelled,

    #[error("{0}")]
    Other(String),
}

impl CoreError {
    pub fn net(e: impl std::fmt::Display) -> Self {
        Self::Net(e.to_string())
    }
    pub fn model(e: impl std::fmt::Display) -> Self {
        Self::Model(e.to_string())
    }
    pub fn inference(e: impl std::fmt::Display) -> Self {
        Self::Inference(e.to_string())
    }
}

impl From<serde_json::Error> for CoreError {
    fn from(e: serde_json::Error) -> Self {
        Self::Other(format!("JSON エラー: {e}"))
    }
}

// フロントエンド (TypeScript) にはプレーンテキストとして渡す
impl Serialize for CoreError {
    fn serialize<S: Serializer>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error> {
        serializer.serialize_str(&self.to_string())
    }
}
