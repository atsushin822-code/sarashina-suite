//! Sarashina GGUF モデルカタログ。
//!
//! SB Intuitions の Sarashina 2.2（日本語中心の軽量 LLM）を GGUF 量子化した
//! `mmnga/sarashina2.2-*-instruct-v0.1-gguf` を配布元としている。
//! SHA-256 は Hugging Face の LFS oid（= ファイルの実ハッシュ）を転記しているため、
//! ダウンロード後の改ざん・破損検証がオフラインで可能。
//!
//! カタログは**アプリに埋め込まれた静的データ**なので、ネットワーク上の
//! マニフェスト取得に失敗しても既定モデルを提示できる。

use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelVariant {
    /// アプリ内で使う一意 ID
    pub id: &'static str,
    pub display_name: &'static str,
    /// 系統（ベースモデル名）
    pub family: &'static str,
    /// パラメータ数表記
    pub params: &'static str,
    /// 量子化方式
    pub quant: &'static str,
    pub file_name: &'static str,
    /// Hugging Face リポジトリ
    pub repo: &'static str,
    pub size_bytes: u64,
    pub sha256: Option<&'static str>,
    /// 目安 RAM (GB)
    pub min_ram_gb: f32,
    pub recommended: bool,
    pub description: &'static str,
}

impl ModelVariant {
    /// 既定のダウンロード URL（`SARASHINA_MIRROR` 設定で自前ミラーへ差し替え可能）
    pub fn download_url(&self, mirror_base: Option<&str>) -> String {
        let path = format!("{}/resolve/main/{}", self.repo, self.file_name);
        match mirror_base {
            Some(base) if !base.is_empty() => format!("{}/{}", base.trim_end_matches('/'), path),
            _ => format!("https://huggingface.co/{path}?download=true"),
        }
    }
}

const HF_1B: &str = "mmnga/sarashina2.2-1b-instruct-v0.1-gguf";
const HF_3B: &str = "mmnga/sarashina2.2-3b-instruct-v0.1-gguf";

/// 出荷時のカタログ。
/// 1B-Q4_K_M を「推奨」にしている理由は、CPU のみのノート PC でも
/// 実用速度（15〜25 tok/s 程度）で日本語生成できる最小構成だから。
pub const CATALOG: &[ModelVariant] = &[
    ModelVariant {
        id: "sarashina-1b-q4_k_m",
        display_name: "Sarashina 2.2 1B Instruct (Q4_K_M)",
        family: "Sarashina 2.2",
        params: "1B",
        quant: "Q4_K_M",
        file_name: "sarashina2.2-1b-instruct-v0.1-Q4_K_M.gguf",
        repo: HF_1B,
        size_bytes: 931_179_392,
        sha256: Some("750b883784931cb65c8cf4ce105e78629a906e10ba6dc6eccc5c96999221d0c2"),
        min_ram_gb: 4.0,
        recommended: true,
        description: "軽量・高速。CPU のみでも快適。校正・要約・箇条書き生成向け。",
    },
    ModelVariant {
        id: "sarashina-1b-q8_0",
        display_name: "Sarashina 2.2 1B Instruct (Q8_0)",
        family: "Sarashina 2.2",
        params: "1B",
        quant: "Q8_0",
        file_name: "sarashina2.2-1b-instruct-v0.1-Q8_0.gguf",
        repo: HF_1B,
        size_bytes: 1_498_333_056,
        sha256: Some("f26ea13b9a7b88aa08479c4abd4f52e94f450c0b6d2143ae5499e5e0e8c89935"),
        min_ram_gb: 6.0,
        recommended: false,
        description: "1B のほぼロスレス版。品質重視だが RAM 消費は増える。",
    },
    ModelVariant {
        id: "sarashina-3b-q4_k_m",
        display_name: "Sarashina 2.2 3B Instruct (Q4_K_M)",
        family: "Sarashina 2.2",
        params: "3B",
        quant: "Q4_K_M",
        file_name: "sarashina2.2-3b-instruct-v0.1-Q4_K_M.gguf",
        repo: HF_3B,
        size_bytes: 2_066_390_112,
        sha256: Some("d96f4d98eb528df26e8bc09ab81a1d165be4fce67616739e65980bed9038f0f2"),
        min_ram_gb: 8.0,
        recommended: false,
        description: "長文の構成や推論が得意。8GB 以上の RAM か GPU 搭載機向け。",
    },
];

pub fn find(id: &str) -> Option<&'static ModelVariant> {
    CATALOG.iter().find(|m| m.id == id)
}

pub fn recommended() -> &'static ModelVariant {
    CATALOG
        .iter()
        .find(|m| m.recommended)
        .unwrap_or(&CATALOG[0])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn catalog_is_consistent() {
        for m in CATALOG {
            assert!(m.file_name.ends_with(".gguf"));
            assert!(m.sha256.map(|s| s.len() == 64).unwrap_or(true));
            assert!(m.size_bytes > 0);
        }
        assert!(find("sarashina-1b-q4_k_m").is_some());
        assert_eq!(recommended().id, "sarashina-1b-q4_k_m");
    }

    #[test]
    fn mirror_url() {
        let m = find("sarashina-1b-q4_k_m").unwrap();
        assert!(m.download_url(None).starts_with("https://huggingface.co/mmnga/"));
        assert_eq!(
            m.download_url(Some("https://mirror.example/ai/")),
            format!("https://mirror.example/ai/{}/resolve/main/{}", m.repo, m.file_name)
        );
    }
}
