//! SQLite によるローカルファースト永続化層。
//!
//! * `journal_mode = WAL` … 読み書き同時実行とクラッシュ耐性
//! * `PRAGMA user_version` によるイミュータブルなマイグレーション
//! * FTS5 `trigram` トークナイザ … 日本語でも辞書なしで部分一致検索が可能
//! * 1 コネクション + Mutex（デスクトップアプリの書き込み量では十分。必要になれば
//!   読み取り専用コネクションを増やすだけでスケールする）

use std::path::Path;
use std::sync::Mutex;

use rusqlite::{params, Connection, OptionalExtension, Row};
use serde::{Deserialize, Serialize};

use crate::error::{CoreError, Result};
use crate::now_ms;

const MIGRATION_001: &str = include_str!("../migrations/001_init.sql");
const SCHEMA_VERSION: i64 = 1;

// ---------------------------------------------------------------------------
// データ転送オブジェクト（camelCase で TS 側にそのまま渡す）
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DocumentSummary {
    pub id: String,
    pub title: String,
    pub kind: String,
    pub preview: String,
    pub pinned: bool,
    pub created_at: i64,
    pub updated_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Document {
    pub id: String,
    pub title: String,
    pub kind: String,
    pub content: String,
    pub plain_text: String,
    pub pinned: bool,
    pub created_at: i64,
    pub updated_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SearchHit {
    pub id: String,
    pub title: String,
    pub snippet: String,
    pub updated_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatMessageRow {
    pub id: String,
    pub session_id: String,
    pub role: String,
    pub content: String,
    pub created_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelRecord {
    pub id: String,
    pub display_name: String,
    pub file_name: String,
    pub path: String,
    pub size_bytes: i64,
    pub sha256: Option<String>,
    pub status: String,
    pub installed_at: i64,
    pub last_used_at: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DbStats {
    pub documents: i64,
    pub characters: i64,
    pub chat_messages: i64,
    pub models: i64,
    pub schema_version: i64,
}

/// ダウンロード中断復帰用の永続状態
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DownloadState {
    pub model_id: String,
    pub url: String,
    pub downloaded: i64,
    pub total: i64,
    pub etag: Option<String>,
    pub updated_at: i64,
}

// ---------------------------------------------------------------------------
// Database
// ---------------------------------------------------------------------------

pub struct Database {
    conn: Mutex<Connection>,
}

impl Database {
    /// ファイルを開き（無ければ作成し）マイグレーションを適用する。
    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref();
        if let Some(dir) = path.parent() {
            std::fs::create_dir_all(dir)?;
        }
        let conn = Connection::open(path)
            .map_err(|e| CoreError::Db(e))?;
        Self::prepare(conn)
    }

    /// テスト用のインメモリ DB
    pub fn open_in_memory() -> Result<Self> {
        Self::prepare(Connection::open_in_memory()?)
    }

    fn prepare(conn: Connection) -> Result<Self> {
        // execute_batch は結果行を無視するので PRAGMA 設定に安全
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = NORMAL;
             PRAGMA foreign_keys = ON;
             PRAGMA busy_timeout = 5000;
             PRAGMA temp_store = MEMORY;",
        )?;
        let db = Self { conn: Mutex::new(conn) };
        db.migrate()?;
        Ok(db)
    }

    fn migrate(&self) -> Result<()> {
        self.with(|conn| {
            let tx = conn.transaction()?;
            let version: i64 = tx.pragma_query_value(None, "user_version", |r| r.get(0))?;
            if version < 1 {
                tx.execute_batch(MIGRATION_001)?;
            }
            if version < SCHEMA_VERSION {
                tx.pragma_update(None, "user_version", SCHEMA_VERSION)?;
            }
            tx.commit()
        })
    }

    /// ロックを取得してクロージャを実行する。同期処理なので、
    /// async 文脈からは `tokio::task::spawn_blocking` 経由で呼ぶこと。
    pub fn with<T>(&self, f: impl FnOnce(&mut Connection) -> rusqlite::Result<T>) -> Result<T> {
        let mut guard = self
            .conn
            .lock()
            .map_err(|_| CoreError::Other("DB ロックが破損しています".into()))?;
        f(&mut guard).map_err(CoreError::Db)
    }

    // -- documents ----------------------------------------------------------

    pub fn list_documents(&self, limit: i64, include_trash: bool) -> Result<Vec<DocumentSummary>> {
        self.with(|conn| {
            let sql = if include_trash {
                "SELECT id, title, kind, substr(plain_text, 1, 140), pinned, created_at, updated_at
                 FROM documents ORDER BY pinned DESC, updated_at DESC LIMIT ?1"
            } else {
                "SELECT id, title, kind, substr(plain_text, 1, 140), pinned, created_at, updated_at
                 FROM documents WHERE deleted_at IS NULL
                 ORDER BY pinned DESC, updated_at DESC LIMIT ?1"
            };
            let mut stmt = conn.prepare(sql)?;
            let rows = stmt.query_map([limit], |r| {
                Ok(DocumentSummary {
                    id: r.get(0)?,
                    title: r.get(1)?,
                    kind: r.get(2)?,
                    preview: r.get::<_, String>(3)?.split_whitespace().collect::<Vec<_>>().join(" "),
                    pinned: r.get::<_, i64>(4)? != 0,
                    created_at: r.get(5)?,
                    updated_at: r.get(6)?,
                })
            })?;
            rows.collect()
        })
    }

    pub fn get_document(&self, id: &str) -> Result<Option<Document>> {
        self.with(|conn| {
            conn.query_row(
                "SELECT id, title, kind, content, plain_text, pinned, created_at, updated_at
                 FROM documents WHERE id = ?1",
                [id],
                map_document,
            )
            .optional()
        })
    }

    pub fn create_document(&self, title: Option<&str>, kind: &str) -> Result<Document> {
        let id = uuid::Uuid::new_v4().to_string();
        let now = now_ms();
        let title = title
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| "無題のドキュメント".to_string());
        let kind = kind.to_string();
        self.with(|conn| {
            conn.execute(
                "INSERT INTO documents (id, title, kind, content, plain_text, created_at, updated_at)
                 VALUES (?1, ?2, ?3, '', '', ?4, ?4)",
                params![id, title, kind, now],
            )?;
            Ok(())
        })?;
        self.get_document(&id)?
            .ok_or_else(|| CoreError::NotFound(id))
    }

    /// 保存（更新）して更新後タイムスタンプを返す。空タイトルは自動補完。
    pub fn save_document(
        &self,
        id: &str,
        title: &str,
        content: &str,
        plain_text: &str,
    ) -> Result<i64> {
        let now = now_ms();
        let title = if title.trim().is_empty() {
            let head: String = plain_text.chars().take(32).collect();
            if head.trim().is_empty() { "無題のドキュメント".to_string() } else { head.trim().to_string() }
        } else {
            title.trim().to_string()
        };
        let affected = self.with(|conn| {
            conn.execute(
                "UPDATE documents
                    SET title = ?2, content = ?3, plain_text = ?4, updated_at = ?5
                  WHERE id = ?1",
                params![id, title, content, plain_text, now],
            )
        })?;
        if affected == 0 {
            return Err(CoreError::NotFound(format!("ドキュメント {id}")));
        }
        Ok(now)
    }

    pub fn set_pinned(&self, id: &str, pinned: bool) -> Result<()> {
        self.with(|conn| {
            conn.execute(
                "UPDATE documents SET pinned = ?2 WHERE id = ?1",
                params![id, i64::from(pinned)],
            )
            .map(|_| ())
        })
    }

    /// ゴミ箱へ移動（ソフトデリート）。`purge = true` で物理削除。
    pub fn delete_document(&self, id: &str, purge: bool) -> Result<()> {
        self.with(|conn| {
            if purge {
                conn.execute("DELETE FROM documents WHERE id = ?1", [id]).map(|_| ())
            } else {
                conn.execute(
                    "UPDATE documents SET deleted_at = ?2 WHERE id = ?1",
                    params![id, now_ms()],
                )
                .map(|_| ())
            }
        })
    }

    pub fn restore_document(&self, id: &str) -> Result<()> {
        self.with(|conn| {
            conn.execute("UPDATE documents SET deleted_at = NULL WHERE id = ?1", [id])
                .map(|_| ())
        })
    }

    /// バージョンスナップショットを保存し、古いものを剪定する。
    pub fn snapshot_document(&self, id: &str, content: &str, keep: i64) -> Result<()> {
        let now = now_ms();
        self.with(|conn| {
            conn.execute(
                "INSERT INTO document_versions (document_id, content, bytes, created_at)
                 VALUES (?1, ?2, ?3, ?4)",
                params![id, content, content.len() as i64, now],
            )?;
            conn.execute(
                "DELETE FROM document_versions
                  WHERE document_id = ?1 AND id NOT IN (
                        SELECT id FROM document_versions
                         WHERE document_id = ?1 ORDER BY created_at DESC LIMIT ?2)",
                params![id, keep.max(1)],
            )
            .map(|_| ())
        })
    }

    /// FTS5 全文検索。trigram なので 3 文字以上のクエリを推奨。
    pub fn search(&self, query: &str, limit: i64) -> Result<Vec<SearchHit>> {
        let q = query.trim();
        if q.is_empty() {
            return Ok(Vec::new());
        }
        // 二重引用符で囲み、内部の " は "" にエスケープして構文エラーを防ぐ
        let fts_query = format!("\"{}\"", q.replace('"', "\"\""));
        self.with(|conn| {
            let mut stmt = conn.prepare(
                "SELECT d.id, d.title,
                        snippet(documents_fts, 1, '<<', '>>', ' … ', 12),
                        d.updated_at
                   FROM documents_fts
                   JOIN documents d ON d.rowid = documents_fts.rowid
                  WHERE documents_fts MATCH ?1 AND d.deleted_at IS NULL
                  ORDER BY rank LIMIT ?2",
            )?;
            let rows = stmt.query_map(params![fts_query, limit], |r| {
                Ok(SearchHit {
                    id: r.get(0)?,
                    title: r.get(1)?,
                    snippet: r.get(2)?,
                    updated_at: r.get(3)?,
                })
            })?;
            rows.collect()
        })
    }

    // -- chat ---------------------------------------------------------------

    pub fn ensure_session(&self, document_id: Option<&str>) -> Result<String> {
        if let Some(doc) = document_id {
            let existing: Option<String> = self.with(|conn| {
                conn.query_row(
                    "SELECT id FROM chat_sessions WHERE document_id = ?1 ORDER BY updated_at DESC LIMIT 1",
                    [doc],
                    |r| r.get(0),
                )
                .optional()
            })?;
            if let Some(id) = existing {
                return Ok(id);
            }
        }
        let id = uuid::Uuid::new_v4().to_string();
        let now = now_ms();
        self.with(|conn| {
            conn.execute(
                "INSERT INTO chat_sessions (id, document_id, title, created_at, updated_at)
                 VALUES (?1, ?2, '新しい会話', ?3, ?3)",
                params![id, document_id, now],
            )
            .map(|_| ())
        })?;
        Ok(id)
    }

    pub fn append_message(&self, session_id: &str, role: &str, content: &str) -> Result<ChatMessageRow> {
        let id = uuid::Uuid::new_v4().to_string();
        let now = now_ms();
        let session_id = session_id.to_string();
        let role = role.to_string();
        let content = content.to_string();
        self.with(|conn| {
            conn.execute(
                "INSERT INTO chat_messages (id, session_id, role, content, tokens, created_at)
                 VALUES (?1, ?2, ?3, ?4, NULL, ?5)",
                params![id, session_id, role, content, now],
            )?;
            conn.execute("UPDATE chat_sessions SET updated_at = ?2 WHERE id = ?1", params![session_id, now])?;
            Ok(())
        })?;
        Ok(ChatMessageRow { id, session_id, role, content, created_at: now })
    }

    pub fn list_messages(&self, session_id: &str, limit: i64) -> Result<Vec<ChatMessageRow>> {
        self.with(|conn| {
            let mut stmt = conn.prepare(
                "SELECT id, session_id, role, content, created_at
                   FROM (SELECT rowid AS rid, id, session_id, role, content, created_at
                           FROM chat_messages WHERE session_id = ?1
                          ORDER BY rid DESC LIMIT ?2)
                  ORDER BY rid ASC",
            )?;
            let rows = stmt.query_map(params![session_id, limit], |r| {
                Ok(ChatMessageRow {
                    id: r.get(0)?,
                    session_id: r.get(1)?,
                    role: r.get(2)?,
                    content: r.get(3)?,
                    created_at: r.get(4)?,
                })
            })?;
            rows.collect()
        })
    }

    // -- models / downloads -------------------------------------------------

    pub fn upsert_model(&self, m: &ModelRecord) -> Result<()> {
        self.with(|conn| {
            conn.execute(
                "INSERT INTO models (id, display_name, file_name, path, size_bytes, sha256,
                                     status, installed_at, last_used_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)
                 ON CONFLICT (id) DO UPDATE SET
                     display_name = excluded.display_name,
                     file_name    = excluded.file_name,
                     path         = excluded.path,
                     size_bytes   = excluded.size_bytes,
                     sha256       = excluded.sha256,
                     status       = excluded.status,
                     installed_at = excluded.installed_at",
                params![
                    m.id, m.display_name, m.file_name, m.path, m.size_bytes,
                    m.sha256, m.status, m.installed_at, m.last_used_at
                ],
            )
            .map(|_| ())
        })
    }

    pub fn list_models(&self) -> Result<Vec<ModelRecord>> {
        self.with(|conn| {
            let mut stmt = conn.prepare(
                "SELECT id, display_name, file_name, path, size_bytes, sha256, status,
                        installed_at, last_used_at
                   FROM models ORDER BY installed_at DESC",
            )?;
            let rows = stmt.query_map([], |r| {
                Ok(ModelRecord {
                    id: r.get(0)?,
                    display_name: r.get(1)?,
                    file_name: r.get(2)?,
                    path: r.get(3)?,
                    size_bytes: r.get(4)?,
                    sha256: r.get(5)?,
                    status: r.get(6)?,
                    installed_at: r.get(7)?,
                    last_used_at: r.get(8)?,
                })
            })?;
            rows.collect()
        })
    }

    pub fn get_model(&self, id: &str) -> Result<Option<ModelRecord>> {
        Ok(self.list_models()?.into_iter().find(|m| m.id == id))
    }

    pub fn delete_model(&self, id: &str) -> Result<()> {
        self.with(|conn| {
            conn.execute("DELETE FROM models WHERE id = ?1", [id])?;
            conn.execute("DELETE FROM downloads WHERE model_id = ?1", [id]).map(|_| ())
        })
    }

    pub fn touch_model(&self, id: &str) -> Result<()> {
        self.with(|conn| {
            conn.execute("UPDATE models SET last_used_at = ?2 WHERE id = ?1", params![id, now_ms()])
                .map(|_| ())
        })
    }

    pub fn upsert_download(&self, d: &DownloadState) -> Result<()> {
        self.with(|conn| {
            conn.execute(
                "INSERT INTO downloads (model_id, url, downloaded, total, etag, updated_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)
                 ON CONFLICT (model_id) DO UPDATE SET
                     url = excluded.url, downloaded = excluded.downloaded,
                     total = excluded.total, etag = excluded.etag, updated_at = excluded.updated_at",
                params![d.model_id, d.url, d.downloaded, d.total, d.etag, d.updated_at],
            )
            .map(|_| ())
        })
    }

    pub fn get_download(&self, model_id: &str) -> Result<Option<DownloadState>> {
        self.with(|conn| {
            conn.query_row(
                "SELECT model_id, url, downloaded, total, etag, updated_at FROM downloads WHERE model_id = ?1",
                [model_id],
                |r| {
                    Ok(DownloadState {
                        model_id: r.get(0)?,
                        url: r.get(1)?,
                        downloaded: r.get(2)?,
                        total: r.get(3)?,
                        etag: r.get(4)?,
                        updated_at: r.get(5)?,
                    })
                },
            )
            .optional()
        })
    }

    pub fn clear_download(&self, model_id: &str) -> Result<()> {
        self.with(|conn| {
            conn.execute("DELETE FROM downloads WHERE model_id = ?1", [model_id]).map(|_| ())
        })
    }

    // -- settings / logs ----------------------------------------------------

    pub fn get_setting(&self, key: &str) -> Result<Option<String>> {
        self.with(|conn| {
            conn.query_row("SELECT value FROM settings WHERE key = ?1", [key], |r| r.get(0))
                .optional()
        })
    }

    pub fn set_setting(&self, key: &str, value: &str) -> Result<()> {
        self.with(|conn| {
            conn.execute(
                "INSERT INTO settings (key, value) VALUES (?1, ?2)
                 ON CONFLICT (key) DO UPDATE SET value = excluded.value",
                params![key, value],
            )
            .map(|_| ())
        })
    }

    pub fn log_generation(
        &self,
        model_id: Option<&str>,
        prompt_tokens: i64,
        completion_tokens: i64,
        elapsed_ms: i64,
        tokens_per_sec: f64,
    ) -> Result<()> {
        let now = now_ms();
        self.with(|conn| {
            conn.execute(
                "INSERT INTO generation_logs (model_id, prompt_tokens, completion_tokens,
                                              elapsed_ms, tokens_per_sec, created_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
                params![model_id, prompt_tokens, completion_tokens, elapsed_ms, tokens_per_sec, now],
            )
            .map(|_| ())
        })
    }

    pub fn stats(&self) -> Result<DbStats> {
        self.with(|conn| {
            let documents =
                conn.query_row("SELECT COUNT(*) FROM documents WHERE deleted_at IS NULL", [], |r| r.get(0))?;
            let characters: i64 = conn.query_row(
                "SELECT COALESCE(SUM(length(plain_text)), 0) FROM documents WHERE deleted_at IS NULL",
                [],
                |r| r.get(0),
            )?;
            let chat_messages: i64 = conn.query_row("SELECT COUNT(*) FROM chat_messages", [], |r| r.get(0))?;
            let models: i64 = conn.query_row("SELECT COUNT(*) FROM models", [], |r| r.get(0))?;
            let schema_version: i64 = conn.pragma_query_value(None, "user_version", |r| r.get(0))?;
            Ok(DbStats { documents, characters, chat_messages, models, schema_version })
        })
    }

    /// WAL を本体へ書き戻す（アプリ終了時・エクスポート前に）
    pub fn checkpoint(&self) -> Result<()> {
        self.with(|conn| conn.execute_batch("PRAGMA wal_checkpoint(TRUNCATE);"))
    }
}

fn map_document(r: &Row<'_>) -> rusqlite::Result<Document> {
    Ok(Document {
        id: r.get(0)?,
        title: r.get(1)?,
        kind: r.get(2)?,
        content: r.get(3)?,
        plain_text: r.get(4)?,
        pinned: r.get::<_, i64>(5)? != 0,
        created_at: r.get(6)?,
        updated_at: r.get(7)?,
    })
}

// ---------------------------------------------------------------------------
#[cfg(test)]
mod tests {
    use super::*;

    fn db() -> Database {
        Database::open_in_memory().expect("open in memory")
    }

    #[test]
    fn migrate_and_crud() {
        let db = db();
        let doc = db.create_document(None, "doc").unwrap();
        assert_eq!(doc.title, "無題のドキュメント");

        let ts = db
            .save_document(&doc.id, "議事録", "<p>本日の打ち合わせ</p>", "本日の打ち合わせ")
            .unwrap();
        assert!(ts > 0);

        let loaded = db.get_document(&doc.id).unwrap().unwrap();
        assert_eq!(loaded.title, "議事録");
        assert_eq!(loaded.content, "<p>本日の打ち合わせ</p>");

        db.delete_document(&doc.id, false).unwrap();
        assert_eq!(db.list_documents(10, false).unwrap().len(), 0);
        assert_eq!(db.list_documents(10, true).unwrap().len(), 1);
        db.restore_document(&doc.id).unwrap();
        assert_eq!(db.list_documents(10, false).unwrap().len(), 1);
    }

    #[test]
    fn fts_trigram_search_japanese() {
        let db = db();
        let a = db.create_document(Some("四半期報告"), "doc").unwrap();
        db.save_document(&a.id, "四半期報告", "売上は前年比120%で着地した", "売上は前年比120%で着地した")
            .unwrap();
        let b = db.create_document(Some("メモ"), "doc").unwrap();
        db.save_document(&b.id, "メモ", "買い物リスト", "買い物リスト").unwrap();

        let hits = db.search("前年比", 10).unwrap();
        assert_eq!(hits.len(), 1);
        assert_eq!(hits[0].id, a.id);
        assert!(hits[0].snippet.contains("前年比"));
        assert_eq!(db.search("リスト", 10).unwrap().len(), 1);
    }

    #[test]
    fn chat_roundtrip_and_versions() {
        let db = db();
        let doc = db.create_document(Some("企画書"), "doc").unwrap();
        let session = db.ensure_session(Some(&doc.id)).unwrap();
        db.append_message(&session, "user", "要約して").unwrap();
        db.append_message(&session, "assistant", "要約です").unwrap();
        let msgs = db.list_messages(&session, 10).unwrap();
        assert_eq!(msgs.len(), 2);
        assert_eq!(msgs[0].role, "user");

        for i in 0..5 {
            db.snapshot_document(&doc.id, &format!("v{i}"), 3).unwrap();
        }
        let kept: i64 = db
            .with(|c| c.query_row("SELECT COUNT(*) FROM document_versions", [], |r| r.get(0)))
            .unwrap();
        assert_eq!(kept, 3);

        let stats = db.stats().unwrap();
        assert_eq!(stats.documents, 1);
        assert_eq!(stats.chat_messages, 2);
    }
}
