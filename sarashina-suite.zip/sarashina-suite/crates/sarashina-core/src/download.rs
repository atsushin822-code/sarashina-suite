//! レジューム対応・検証付きダウンローダ。
//!
//! 設計上の要点:
//! 1. **`.part` ファイル + HTTP Range** で中断復帰（回線断・スリープ・ユーザーキャンセル）
//! 2. **進捗は 100ms 間隔でスロットリング**して emit（UI をイベント洪水で潰さない）
//! 3. **完了後に SHA-256 を全数検証**（GGUF は数 GB なので「サイズだけ」検証は不十分）
//! 4. 検証が通るまで **rename しない**（壊れたモデルが推論に使われるのを構造的に防ぐ）
//! 5. 進捗通知は `ProgressSink` trait で抽象化 → Tauri 層ではイベント emit、テストでは vec push

use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use futures_util::StreamExt;
use serde::Serialize;
use sha2::{Digest, Sha256};
use tokio::io::AsyncWriteExt;

use crate::error::{CoreError, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum DownloadPhase {
    Preparing,
    Downloading,
    Verifying,
    Completed,
    Cancelled,
    Failed,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DownloadProgress {
    pub phase: DownloadPhase,
    pub downloaded: u64,
    pub total: u64,
    pub bytes_per_sec: f64,
    pub eta_secs: Option<u64>,
    pub message: Option<String>,
}

impl DownloadProgress {
    fn new(phase: DownloadPhase, downloaded: u64, total: u64) -> Self {
        Self { phase, downloaded, total, bytes_per_sec: 0.0, eta_secs: None, message: None }
    }
}

/// 進捗の受け取り口（Tauri 層はここでイベントを emit する）
pub trait ProgressSink: Send + Sync {
    fn progress(&self, progress: DownloadProgress);
    /// ユーザーがキャンセルしたか（毎チャンク確認する）
    fn cancelled(&self) -> bool {
        false
    }
}

/// 何も通知しない実装（CLI / テスト用）
pub struct NoopSink;
impl ProgressSink for NoopSink {
    fn progress(&self, _: DownloadProgress) {}
}

#[derive(Debug, Clone)]
pub struct DownloadRequest {
    pub url: String,
    pub dest: PathBuf,
    pub expected_size: Option<u64>,
    pub expected_sha256: Option<String>,
}

/// 進捗通知のスロットリング間隔
const PROGRESS_INTERVAL: Duration = Duration::from_millis(100);

pub fn part_path(dest: &Path) -> PathBuf {
    let name = dest.file_name().and_then(|s| s.to_str()).unwrap_or("model.gguf");
    dest.with_file_name(format!("{name}.part"))
}

/// モデル本体を取得する。成功時は検証済みの最終パスを返す。
pub async fn download(
    client: &reqwest::Client,
    req: &DownloadRequest,
    sink: &dyn ProgressSink,
) -> Result<PathBuf> {
    let part = part_path(&req.dest);

    // --- 1. 既存の .part から再開位置を決める -------------------------------
    let mut existing = tokio::fs::metadata(&part).await.map(|m| m.len()).unwrap_or(0);
    if let Some(expected) = req.expected_size {
        if existing > expected {
            // カタログ更新などでサイズが変わった場合はやり直す
            let _ = tokio::fs::remove_file(&part).await;
            existing = 0;
        }
    }

    sink.progress(DownloadProgress {
        message: Some(if existing > 0 {
            format!("{} から再開します", human_bytes(existing))
        } else {
            "接続しています…".to_string()
        }),
        ..DownloadProgress::new(DownloadPhase::Preparing, existing, req.expected_size.unwrap_or(0))
    });

    let mut request = client.get(&req.url);
    if existing > 0 {
        request = request.header(reqwest::header::RANGE, format!("bytes={existing}-"));
    }

    let response = request.send().await.map_err(CoreError::net)?;
    let status = response.status();

    // 416: すでに全体を取得済み (.part が完成サイズ) → 検証だけ行う
    let already_complete = status == reqwest::StatusCode::RANGE_NOT_SATISFIABLE;

    let (mut downloaded, total) = if already_complete {
        (existing, req.expected_size.unwrap_or(existing))
    } else if status.is_success() {
        if status == reqwest::StatusCode::PARTIAL_CONTENT {
            // サーバが Range を尊重 → 追記
            let total = response
                .content_length()
                .map(|len| len + existing)
                .or(req.expected_size)
                .unwrap_or(0);
            (existing, total)
        } else {
            // 200 OK = サーバが Range 非対応 → 最初から
            let total = response.content_length().or(req.expected_size).unwrap_or(0);
            (0u64, total)
        }
    } else {
        return Err(CoreError::Net(format!(
            "モデルの取得に失敗しました (HTTP {status}) — URL: {}",
            req.url
        )));
    };

    // --- 2. ボディをストリームで書き込む -----------------------------------
    if !already_complete {
        let mut file = if downloaded > 0 {
            tokio::fs::OpenOptions::new().append(true).open(&part).await?
        } else {
            tokio::fs::File::create(&part).await?
        };

        let mut stream = response.bytes_stream();
        let started = Instant::now();
        let start_bytes = downloaded;
        let mut last_emit = Instant::now();
        // 直近の速度は指数移動平均で安定させる
        let mut ema_speed = 0.0f64;

        while let Some(chunk) = stream.next().await {
            if sink.cancelled() {
                file.flush().await?;
                sink.progress(DownloadProgress {
                    message: Some("ダウンロードを中断しました（次回再開できます）".into()),
                    ..DownloadProgress::new(DownloadPhase::Cancelled, downloaded, total)
                });
                return Err(CoreError::Cancelled);
            }
            let chunk = chunk.map_err(CoreError::net)?;
            file.write_all(&chunk).await?;
            downloaded += chunk.len() as u64;

            if last_emit.elapsed() >= PROGRESS_INTERVAL {
                let elapsed = started.elapsed().as_secs_f64().max(1e-6);
                let instant_speed = (downloaded - start_bytes) as f64 / elapsed;
                ema_speed = if ema_speed == 0.0 {
                    instant_speed
                } else {
                    ema_speed * 0.7 + instant_speed * 0.3
                };
                let eta = if total > downloaded && ema_speed > 1.0 {
                    Some(((total - downloaded) as f64 / ema_speed).round() as u64)
                } else {
                    None
                };
                sink.progress(DownloadProgress {
                    bytes_per_sec: ema_speed,
                    eta_secs: eta,
                    ..DownloadProgress::new(DownloadPhase::Downloading, downloaded, total)
                });
                last_emit = Instant::now();
            }
        }
        file.flush().await?;
        file.sync_all().await?;
    }

    // --- 3. サイズ検証 ------------------------------------------------------
    let actual_size = tokio::fs::metadata(&part).await?.len();
    if let Some(expected) = req.expected_size {
        if actual_size != expected {
            let _ = tokio::fs::remove_file(&part).await;
            return Err(CoreError::Model(format!(
                "サイズ不一致: 期待 {expected} / 実際 {actual_size}。破損ファイルを削除しました"
            )));
        }
    }
    if total > 0 && actual_size != total {
        return Err(CoreError::Model(format!(
            "ダウンロードが不完全です: {actual_size}/{total} バイト"
        )));
    }

    // --- 4. SHA-256 検証（ブロッキング I/O を専用スレッドへ） ---------------
    if let Some(expected) = req.expected_sha256.clone() {
        let path = part.clone();
        let progress_total = actual_size;
        sink.progress(DownloadProgress::new(DownloadPhase::Verifying, 0, progress_total));
        let digest = tokio::task::spawn_blocking(move || hash_file(&path, progress_total))
            .await
            .map_err(|e| CoreError::Other(format!("ハッシュ計算タスクが失敗: {e}")))??;

        if !digest.eq_ignore_ascii_case(&expected) {
            let _ = tokio::fs::remove_file(&part).await;
            return Err(CoreError::Model(format!(
                "SHA-256 が一致しません（改ざんまたは破損）: 期待 {expected} / 実際 {digest}"
            )));
        }
        sink.progress(DownloadProgress::new(DownloadPhase::Verifying, progress_total, progress_total));
    }

    // --- 5. 原子的にリネーム（同一ボリューム内なので atomic） ----------------
    if tokio::fs::try_exists(&req.dest).await.unwrap_or(false) {
        tokio::fs::remove_file(&req.dest).await?;
    }
    tokio::fs::rename(&part, &req.dest).await?;

    sink.progress(DownloadProgress {
        message: Some("インストール完了".into()),
        ..DownloadProgress::new(DownloadPhase::Completed, actual_size, actual_size)
    });
    Ok(req.dest.clone())
}

/// ファイル全体の SHA-256 を計算する（同期）。
fn hash_file(path: &Path, total: u64) -> Result<String> {
    use std::io::Read;
    let mut file = std::fs::File::open(path)?;
    let mut hasher = Sha256::new();
    let mut buf = vec![0u8; 1024 * 1024];
    let mut read_total = 0u64;
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
        read_total += n as u64;
        let _ = (read_total, total); // 進捗は呼び出し側で表現（数 GB でも数秒）
    }
    Ok(hex::encode(hasher.finalize()))
}

pub fn human_bytes(bytes: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    let mut value = bytes as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    format!("{value:.1} {}", UNITS[unit])
}

/// 壊れた/未完成のダウンロードを掃除する
pub async fn cleanup_partial(dest: &Path) {
    let _ = tokio::fs::remove_file(part_path(dest)).await;
}

/// 共有 HTTP クライアント（User-Agent と接続プールを 1 つに集約）
pub fn build_client() -> Result<reqwest::Client> {
    reqwest::Client::builder()
        .user_agent(concat!("SarashinaSuite/", env!("CARGO_PKG_VERSION")))
        .connect_timeout(Duration::from_secs(20))
        .timeout(Duration::from_secs(3600))
        .pool_max_idle_per_host(4)
        .build()
        .map_err(CoreError::net)
}

/// GGUF マジックバイト検証（ダウンロード済みファイルの簡易ヘルスチェック）
pub fn is_valid_gguf(path: &Path) -> bool {
    use std::io::Read;
    let mut magic = [0u8; 4];
    match std::fs::File::open(path).and_then(|mut f| f.read_exact(&mut magic)) {
        Ok(()) => &magic == b"GGUF",
        Err(_) => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn part_path_appends_suffix() {
        let p = part_path(Path::new("/models/sarashina.gguf"));
        assert_eq!(p, PathBuf::from("/models/sarashina.gguf.part"));
    }

    #[test]
    fn human_bytes_formats() {
        assert_eq!(human_bytes(512), "512.0 B");
        assert_eq!(human_bytes(931_179_392), "888.0 MB");
    }

    #[test]
    fn gguf_magic_detection() {
        let dir = tempfile::tempdir().unwrap();
        let ok = dir.path().join("a.gguf");
        std::fs::write(&ok, b"GGUFxxxx").unwrap();
        assert!(is_valid_gguf(&ok));

        let bad = dir.path().join("b.gguf");
        std::fs::write(&bad, b"<html>").unwrap();
        assert!(!is_valid_gguf(&bad));
    }
}
