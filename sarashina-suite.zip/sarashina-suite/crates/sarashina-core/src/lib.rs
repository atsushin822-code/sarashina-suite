//! # sarashina-core
//!
//! Sarashina Suite のドメインロジック。**Tauri / OS / UI に一切依存しない**ため、
//! `cargo test -p sarashina-core` で DB・ダウンロード・プロンプト構築を高速に検証できる。
//!
//! * [`db`]        … SQLite (WAL, FTS5 trigram) によるローカルファースト永続化
//! * [`catalog`]   … 配布する Sarashina GGUF モデルのカタログ（サイズ / SHA-256 付き）
//! * [`download`]  … レジューム対応・ハッシュ検証付きダウンローダ
//! * [`inference`] … 専用スレッドで動く llama.cpp 推論ワーカー（feature = "llama"）
//! * [`export`]    … Markdown / HTML / プレーンテキスト書き出し
//!
//! アプリは完全オフラインで動作する。ネットワークを使うのは「モデル取得」のみ。

/// HTTP クライアント型を上位層から使えるように再エクスポート
/// （バージョン不整合を避けるため、reqwest の宣言は core のみに置く）
pub use reqwest;

pub mod catalog;
pub mod db;
pub mod download;
pub mod error;
pub mod export;
pub mod inference;

pub use error::{CoreError, Result};

/// 現在時刻 (Unix epoch milliseconds)
pub fn now_ms() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}
