//! 書き出し（Markdown / HTML / プレーンテキスト / JSON）。
//!
//! エディタの内部表現は「サニタイズ済み HTML」1 種類だけにして、
//! 書き出しは全てここで変換する（保存形式を増やさない = バグとマイグレーションを減らす）。

use std::path::{Path, PathBuf};

use serde::Serialize;

use crate::db::Database;
use crate::error::{CoreError, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum ExportFormat {
    Markdown,
    Html,
    Text,
    Json,
}

impl ExportFormat {
    pub fn extension(&self) -> &'static str {
        match self {
            ExportFormat::Markdown => "md",
            ExportFormat::Html => "html",
            ExportFormat::Text => "txt",
            ExportFormat::Json => "json",
        }
    }

    pub fn parse(s: &str) -> Result<Self> {
        match s.to_ascii_lowercase().as_str() {
            "md" | "markdown" => Ok(Self::Markdown),
            "html" | "htm" => Ok(Self::Html),
            "txt" | "text" => Ok(Self::Text),
            "json" => Ok(Self::Json),
            other => Err(CoreError::Invalid(format!("未対応の形式です: {other}"))),
        }
    }
}

/// ドキュメントを指定形式で `dest` に書き出す。
pub fn export_document(
    db: &Database,
    document_id: &str,
    format: ExportFormat,
    dest: &Path,
) -> Result<PathBuf> {
    let doc = db
        .get_document(document_id)?
        .ok_or_else(|| CoreError::NotFound(format!("ドキュメント {document_id}")))?;

    let body = match format {
        ExportFormat::Markdown => {
            let md = html_to_markdown(&doc.content);
            if md.trim().is_empty() { html_to_markdown(&escape_html(&doc.plain_text)) } else { md }
        }
        ExportFormat::Html => format!(
            "<!doctype html>\n<html lang=\"ja\">\n<head>\n<meta charset=\"utf-8\">\n\
             <title>{}</title>\n<style>body{{font-family:system-ui,-apple-system,'Hiragino Sans',sans-serif;\
             max-width:52rem;margin:3rem auto;padding:0 1.25rem;line-height:1.85;color:#1d1d1f}}\
             code{{background:#f4f4f6;padding:.15em .35em;border-radius:4px}}\
             blockquote{{border-left:3px solid #d2d2d7;margin-left:0;padding-left:1rem;color:#555}}</style>\n\
             </head>\n<body>\n<h1>{}</h1>\n{}\n</body>\n</html>\n",
            escape_html(&doc.title),
            escape_html(&doc.title),
            doc.content
        ),
        ExportFormat::Text => {
            if doc.plain_text.trim().is_empty() {
                html_to_text(&doc.content)
            } else {
                format!("{}\n\n{}", doc.title, doc.plain_text)
            }
        }
        ExportFormat::Json => serde_json::to_string_pretty(&doc)?,
    };

    if let Some(dir) = dest.parent() {
        std::fs::create_dir_all(dir)?;
    }
    std::fs::write(dest, body)?;
    Ok(dest.to_path_buf())
}

/// 書き出し先の既定パスを作る（`<dir>/<タイトル>.<ext>`）
pub fn suggest_path(dir: &Path, title: &str, format: ExportFormat) -> PathBuf {
    let safe: String = title
        .chars()
        .map(|c| match c {
            '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|' => '_',
            c if c.is_control() => '_',
            c => c,
        })
        .collect();
    let stem = if safe.trim().is_empty() { "document" } else { safe.trim() };
    let stem: String = stem.chars().take(80).collect();
    dir.join(format!("{stem}.{}", format.extension()))
}

pub fn escape_html(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn decode_entities(s: &str) -> String {
    s.replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
}

/// 簡易 HTML → プレーンテキスト（タグ除去 + 改行の再現）
pub fn html_to_text(html: &str) -> String {
    let mut out = String::with_capacity(html.len());
    let mut in_tag = false;
    let mut in_script = false;
    let mut tag = String::new();

    for ch in html.chars() {
        if in_tag {
            if ch == '>' {
                in_tag = false;
                let name = tag.trim_start_matches('/').split_whitespace().next().unwrap_or("").to_ascii_lowercase();
                let closing = tag.starts_with('/');
                if name == "script" || name == "style" {
                    in_script = !closing;
                }
                match name.as_str() {
                    "br" => out.push('\n'),
                    "p" | "div" | "section" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "li" | "tr" => {
                        out.push('\n')
                    }
                    _ => {}
                }
                tag.clear();
            } else {
                tag.push(ch);
            }
            continue;
        }
        match ch {
            '<' => in_tag = true,
            _ if in_script => {}
            _ => out.push(ch),
        }
    }

    let text = decode_entities(&out);
    // 連続改行を最大 2 つに畳み、行末空白を除去
    let mut lines: Vec<String> = Vec::new();
    for line in text.lines() {
        let trimmed = line.trim_end().to_string();
        if trimmed.trim().is_empty() && lines.last().map(|l: &String| l.trim().is_empty()).unwrap_or(true) {
            continue;
        }
        lines.push(trimmed);
    }
    lines.join("\n").trim().to_string()
}

/// 簡易 HTML → Markdown（エディタの主要ブロックのみ対応。十分実用的な範囲に絞る）
pub fn html_to_markdown(html: &str) -> String {
    let mut out = String::with_capacity(html.len());
    let mut tag = String::new();
    let mut in_tag = false;
    let mut list_stack: Vec<bool> = Vec::new(); // true = ol, false = ul
    let mut ordered_counter: Vec<usize> = Vec::new();
    let mut pending_link: Option<String> = None;

    for ch in html.chars() {
        if in_tag {
            if ch == '>' {
                in_tag = false;
                let raw = tag.trim().to_string();
                let closing = raw.starts_with('/');
                let name = raw
                    .trim_start_matches('/')
                    .split_whitespace()
                    .next()
                    .unwrap_or("")
                    .to_ascii_lowercase();
                let attrs = raw.clone();

                match name.as_str() {
                    "h1" if !closing => out.push_str("\n# "),
                    "h2" if !closing => out.push_str("\n## "),
                    "h3" if !closing => out.push_str("\n### "),
                    "h4" if !closing => out.push_str("\n#### "),
                    "h1" | "h2" | "h3" | "h4" | "h5" | "h6" => out.push_str("\n\n"),
                    "p" | "div" => out.push_str(if closing { "\n\n" } else { "\n" }),
                    "br" => out.push_str("  \n"),
                    "strong" | "b" => out.push_str("**"),
                    "em" | "i" => out.push('*'),
                    "code" => out.push('`'),
                    "pre" => out.push_str("\n```\n"),
                    "blockquote" => out.push_str(if closing { "\n" } else { "\n> " }),
                    "hr" => out.push_str("\n---\n"),
                    "ul" => {
                        if closing {
                            list_stack.pop();
                            ordered_counter.pop();
                            out.push('\n');
                        } else {
                            list_stack.push(false);
                            ordered_counter.push(0);
                        }
                    }
                    "ol" => {
                        if closing {
                            list_stack.pop();
                            ordered_counter.pop();
                            out.push('\n');
                        } else {
                            list_stack.push(true);
                            ordered_counter.push(0);
                        }
                    }
                    "li" if !closing => {
                        let depth = list_stack.len().saturating_sub(1);
                        let indent = "  ".repeat(depth);
                        if let Some(is_ordered) = list_stack.last().copied() {
                            if is_ordered {
                                if let Some(counter) = ordered_counter.last_mut() {
                                    *counter += 1;
                                    out.push_str(&format!("\n{indent}{}. ", *counter));
                                }
                            } else {
                                out.push_str(&format!("\n{indent}- "));
                            }
                        } else {
                            out.push_str("\n- ");
                        }
                    }
                    "a" if !closing => {
                        if let Some(href) = extract_attr(&attrs, "href") {
                            out.push('[');
                            pending_link = Some(href);
                        }
                    }
                    "a" => {
                        if let Some(href) = pending_link.take() {
                            out.push_str(&format!("]({href})"));
                        }
                    }
                    _ => {}
                }
                tag.clear();
            } else {
                tag.push(ch);
            }
            continue;
        }
        match ch {
            '<' => in_tag = true,
            _ => out.push(ch),
        }
    }

    // 連続する空行を 2 つまでに正規化
    let mut lines: Vec<String> = Vec::new();
    for line in out.lines() {
        let l = line.trim_end().to_string();
        if l.trim().is_empty() && lines.last().map(|x: &String| x.trim().is_empty()).unwrap_or(true) {
            continue;
        }
        lines.push(l);
    }
    lines.join("\n").trim().to_string()
}

fn extract_attr(attrs: &str, name: &str) -> Option<String> {
    let needle = format!("{name}=");
    let idx = attrs.find(&needle)?;
    let rest = &attrs[idx + needle.len()..];
    let quote = rest.chars().next()?;
    if quote == '"' || quote == '\'' {
        let rest = &rest[1..];
        let end = rest.find(quote)?;
        Some(rest[..end].to_string())
    } else {
        let end = rest.find(|c: char| c.is_whitespace() || c == '>').unwrap_or(rest.len());
        Some(rest[..end].to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn html_to_text_basics() {
        let html = "<h1>見出し</h1><p>本文&amp;テスト</p><ul><li>項目1</li><li>項目2</li></ul>";
        let text = html_to_text(html);
        assert!(text.contains("見出し"));
        assert!(text.contains("本文&テスト"));
        assert!(text.contains("項目2"));
    }

    #[test]
    fn html_to_markdown_basics() {
        let html = "<h2>章</h2><p><strong>重要</strong>な点</p><ul><li>a</li><li>b</li></ul>";
        let md = html_to_markdown(html);
        assert!(md.contains("## 章"));
        assert!(md.contains("**重要**"));
        assert!(md.contains("- a"));
    }

    #[test]
    fn export_writes_file() {
        let dir = tempfile::tempdir().unwrap();
        let db = Database::open_in_memory().unwrap();
        let doc = db.create_document(Some("週次レポート"), "doc").unwrap();
        db.save_document(&doc.id, "週次レポート", "<h1>週次</h1><p>順調</p>", "週次 順調").unwrap();

        let dest = dir.path().join("out.md");
        export_document(&db, &doc.id, ExportFormat::Markdown, &dest).unwrap();
        let body = std::fs::read_to_string(&dest).unwrap();
        assert!(body.contains("# 週次"));
    }

    #[test]
    fn suggested_path_sanitizes() {
        let p = suggest_path(Path::new("/tmp"), "a/b:c*d", ExportFormat::Html);
        assert_eq!(p.file_name().unwrap().to_str().unwrap(), "a_b_c_d.html");
    }
}
