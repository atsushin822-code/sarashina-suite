//! プロンプト構築ユーティリティ。
//!
//! Sarashina 2.2 のチャットテンプレート（tokenizer_config.json より）:
//! ```text
//! <s><|system|>{system}</s><|user|>{user}</s><|assistant|>{assistant}</s><|user|>…<|assistant|>
//! ```
//! GGUF にテンプレートが埋め込まれている場合は `apply_chat_template`（llama.cpp）を
//! 優先し、テンプレート欠落時のみここのフォールバックを使う。

use super::engine::ChatTurn;

pub const EOS: &str = "</s>";

/// フォールバック（ChatML 風ではなく Sarashina 2.2 ネイティブ形式）
pub fn fallback_prompt(messages: &[ChatTurn]) -> String {
    let mut out = String::new();
    for m in messages {
        let tag = match m.role.as_str() {
            "system" => "<|system|>",
            "assistant" => "<|assistant|>",
            _ => "<|user|>",
        };
        out.push_str(tag);
        out.push_str(m.content.trim());
        out.push_str(EOS);
    }
    out.push_str("<|assistant|>");
    out
}

/// コンテキスト長に収まるように履歴を削る。
///
/// * `system` は常に残す
/// * 直近のメッセージを優先し、古いものから落とす
/// * 1 メッセージのみで超過する場合は末尾を切り詰める
pub fn trim_to_budget(messages: &[ChatTurn], budget_chars: usize) -> Vec<ChatTurn> {
    let system: Vec<ChatTurn> = messages.iter().filter(|m| m.role == "system").cloned().collect();
    let mut rest: Vec<ChatTurn> = messages.iter().filter(|m| m.role != "system").cloned().collect();

    let system_len: usize = system.iter().map(|m| m.content.chars().count()).sum();
    let mut budget = budget_chars.saturating_sub(system_len);

    let mut kept_rev: Vec<ChatTurn> = Vec::new();
    while let Some(msg) = rest.pop() {
        let len = msg.content.chars().count();
        if len > budget {
            if kept_rev.is_empty() {
                // 単体で溢れる → 末尾だけ残す
                let tail: String = msg
                    .content
                    .chars()
                    .rev()
                    .take(budget)
                    .collect::<Vec<_>>()
                    .into_iter()
                    .rev()
                    .collect();
                kept_rev.push(ChatTurn { role: msg.role, content: format!("…{tail}") });
            }
            break;
        }
        budget -= len;
        kept_rev.push(msg);
    }

    let mut out = system;
    out.extend(kept_rev.into_iter().rev());
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn t(role: &str, content: &str) -> ChatTurn {
        ChatTurn { role: role.into(), content: content.into() }
    }

    #[test]
    fn prompt_matches_sarashina_format() {
        let p = fallback_prompt(&[t("system", "丁寧に"), t("user", "こんにちは")]);
        assert_eq!(p, "<|system|>丁寧に</s><|user|>こんにちは</s><|assistant|>");
    }

    #[test]
    fn trims_oldest_first_keeping_system() {
        let msgs = vec![
            t("system", "S"),
            t("user", "ああああ"),
            t("assistant", "いいいい"),
            t("user", "うううう"),
        ];
        let trimmed = trim_to_budget(&msgs, 9);
        assert_eq!(trimmed[0].role, "system");
        assert_eq!(trimmed.last().unwrap().content, "うううう");
        assert!(trimmed.len() < msgs.len());
    }
}
