//! 推論ワーカー（専用 OS スレッド）+ 非同期ハンドル。
//!
//! Tauri コマンドはこのハンドルに `Job` を投げるだけで、重い推論は
//! ワーカースレッド側で完結する。UI スレッド（async ランタイム）は一切ブロックしない。

use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Sender};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use serde::{Deserialize, Serialize};

use crate::error::{CoreError, Result};

#[cfg(feature = "llama")]
use crate::inference::llama::LlamaBackendImpl as PlatformBackend;
#[cfg(not(feature = "llama"))]
use crate::inference::stub::StubBackend as PlatformBackend;

/// ビルドされた推論バックエンド名（UI のステータス表示に使う）
pub const BACKEND_NAME: &str =
    if cfg!(feature = "llama") { "llama.cpp" } else { "stub (llama feature 無効)" };

// ---------------------------------------------------------------------------
// DTO
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatTurn {
    pub role: String,
    pub content: String,
}

/// 生成パラメータ。TS 側から部分指定できるよう `#[serde(default)]` を付与。
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct GenOptions {
    pub max_tokens: usize,
    pub temperature: f32,
    pub top_p: f32,
    pub top_k: i32,
    pub repeat_penalty: f32,
    pub seed: u32,
    /// 0 の場合はモデル設定 (n_ctx) に従う
    pub n_ctx: u32,
}

impl Default for GenOptions {
    fn default() -> Self {
        Self {
            max_tokens: 512,
            temperature: 0.7,
            top_p: 0.95,
            top_k: 40,
            repeat_penalty: 1.1,
            seed: 0,
            n_ctx: 0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct GenStats {
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub elapsed_ms: u64,
    pub tokens_per_sec: f32,
    pub cancelled: bool,
    pub finish_reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EngineStatus {
    /// unloaded | loading | ready | generating | error
    pub state: String,
    pub backend: String,
    pub model_id: Option<String>,
    pub model_path: Option<String>,
    pub n_ctx: u32,
    pub message: Option<String>,
}

impl Default for EngineStatus {
    fn default() -> Self {
        Self {
            state: "unloaded".into(),
            backend: BACKEND_NAME.into(),
            model_id: None,
            model_path: None,
            n_ctx: 0,
            message: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct EngineConfig {
    pub n_ctx: u32,
    pub n_threads: i32,
    /// GPU にオフロードするレイヤー数（0 = CPU のみ, 999 = 全層）
    pub n_gpu_layers: u32,
}

impl Default for EngineConfig {
    fn default() -> Self {
        let threads = std::thread::available_parallelism()
            .map(|n| n.get() as i32)
            .unwrap_or(4)
            .saturating_sub(1)
            .max(1);
        Self { n_ctx: 4096, n_threads: threads, n_gpu_layers: 0 }
    }
}

/// 生成されたテキストの受け取り口（Tauri 層で `llm://token` を emit）
pub trait TokenSink: Send {
    fn on_token(&mut self, delta: &str);
}

/// 何もしない sink（テスト用）
pub struct NullSink;
impl TokenSink for NullSink {
    fn on_token(&mut self, _: &str) {}
}

// ---------------------------------------------------------------------------
// Backend trait（llama.rs / stub.rs が実装）
// ---------------------------------------------------------------------------

pub trait Backend: Send {
    fn name(&self) -> &'static str;
    fn load(&mut self, path: &Path, config: &EngineConfig) -> Result<()>;
    fn is_loaded(&self) -> bool;
    fn generate(
        &mut self,
        messages: &[ChatTurn],
        options: &GenOptions,
        config: &EngineConfig,
        cancel: &AtomicBool,
        sink: &mut dyn TokenSink,
    ) -> Result<GenStats>;
}

// ---------------------------------------------------------------------------
// Job / Handle
// ---------------------------------------------------------------------------

pub enum Job {
    Load { model_id: String, path: PathBuf, config: EngineConfig },
    Generate {
        messages: Vec<ChatTurn>,
        options: GenOptions,
        config: EngineConfig,
        cancel: Arc<AtomicBool>,
        sink: Box<dyn TokenSink>,
        reply: tokio::sync::oneshot::Sender<Result<GenStats>>,
    },
    Shutdown,
}

pub type StatusCallback = Arc<dyn Fn(&EngineStatus) + Send + Sync>;

/// ワーカースレッドへの非同期ハンドル。`Clone` してアプリ状態に保持できる。
#[derive(Clone)]
pub struct EngineHandle {
    tx: Sender<Job>,
    status: Arc<Mutex<EngineStatus>>,
    config: Arc<Mutex<EngineConfig>>,
}

impl EngineHandle {
    /// ワーカースレッドを起動する。モデルが既にインストール済みなら即ロードする。
    pub fn spawn(
        initial_model: Option<(String, PathBuf)>,
        config: EngineConfig,
        on_status: Option<StatusCallback>,
    ) -> Result<Self> {
        let (tx, rx) = mpsc::channel::<Job>();
        let status = Arc::new(Mutex::new(EngineStatus::default()));
        let config = Arc::new(Mutex::new(config));

        // ステータス更新ヘルパ（ワーカー内で使う）
        let worker_status = Arc::clone(&status);
        let worker_cb = on_status.clone();

        std::thread::Builder::new()
            .name("sarashina-inference".into())
            .spawn(move || {
                let mut backend = PlatformBackend::new();
                let mut current_config = EngineConfig::default();

                let update = |state: &str, model: Option<(&str, &Path)>, n_ctx: u32, message: Option<String>| {
                    let mut s = worker_status.lock().expect("status poisoned");
                    s.state = state.to_string();
                    s.n_ctx = n_ctx;
                    if let Some((id, path)) = model {
                        s.model_id = Some(id.to_string());
                        s.model_path = Some(path.display().to_string());
                    }
                    s.message = message;
                    if let Some(cb) = &worker_cb {
                        cb(&s);
                    }
                };
                update("unloaded", None, 0, Some("モデル未ロード".into()));

                if let Some((id, path)) = initial_model {
                    update("loading", Some((&id, &path)), current_config.n_ctx, Some("読み込み中…".into()));
                    match backend.load(&path, &current_config) {
                        Ok(()) => update("ready", Some((&id, &path)), current_config.n_ctx, None),
                        Err(e) => update("error", Some((&id, &path)), 0, Some(e.to_string())),
                    }
                }

                while let Ok(job) = rx.recv() {
                    match job {
                        Job::Load { model_id, path, config: cfg } => {
                            current_config = cfg;
                            update("loading", Some((&model_id, &path)), current_config.n_ctx, Some("モデルを読み込み中…".into()));
                            match backend.load(&path, &current_config) {
                                Ok(()) => update("ready", Some((&model_id, &path)), current_config.n_ctx, None),
                                Err(e) => update("error", Some((&model_id, &path)), 0, Some(e.to_string())),
                            }
                        }
                        Job::Generate { messages, options, config: cfg, cancel, mut sink, reply } => {
                            let model_hint = worker_status
                                .lock()
                                .map(|s| (s.model_id.clone(), s.model_path.clone()))
                                .unwrap_or((None, None));
                            update(
                                "generating",
                                model_hint
                                    .0
                                    .as_deref()
                                    .zip(model_hint.1.as_deref().map(Path::new)),
                                cfg.n_ctx,
                                None,
                            );
                            let result = backend.generate(&messages, &options, &cfg, &cancel, sink.as_mut());
                            update(
                                "ready",
                                model_hint
                                    .0
                                    .as_deref()
                                    .zip(model_hint.1.as_deref().map(Path::new)),
                                cfg.n_ctx,
                                None,
                            );
                            let _ = reply.send(result);
                        }
                        Job::Shutdown => break,
                    }
                }
                tracing::info!("inference worker を停止しました");
            })
            .map_err(|e| CoreError::inference(format!("ワーカースレッドを起動できません: {e}")))?;

        Ok(Self { tx, status, config })
    }

    pub fn status(&self) -> EngineStatus {
        self.status.lock().map(|s| s.clone()).unwrap_or_default()
    }

    pub fn config(&self) -> EngineConfig {
        self.config.lock().map(|c| c.clone()).unwrap_or_default()
    }

    pub fn set_config(&self, config: EngineConfig) {
        if let Ok(mut c) = self.config.lock() {
            *c = config;
        }
    }

    /// モデルを差し替える（別モデルを選んだ時 / ダウンロード完了時）
    pub fn load(&self, model_id: impl Into<String>, path: PathBuf, config: Option<EngineConfig>) {
        let cfg = config.unwrap_or_else(|| self.config());
        self.set_config(cfg.clone());
        let _ = self.tx.send(Job::Load { model_id: model_id.into(), path, config: cfg });
    }

    /// 生成を開始し、完了を受け取るためのレシーバを返す。
    /// 進捗（トークン）は `sink` 経由でストリーミングされる。
    pub fn generate(
        &self,
        messages: Vec<ChatTurn>,
        options: GenOptions,
        cancel: Arc<AtomicBool>,
        sink: Box<dyn TokenSink>,
    ) -> Result<tokio::sync::oneshot::Receiver<Result<GenStats>>> {
        if !self.status().state.eq("ready") && !self.status().state.eq("generating") {
            // ready でなくてもワーカーに投げてエラーを返させる（状態の一貫性を保つ）
            tracing::warn!("engine が ready ではありません: {:?}", self.status());
        }
        let (reply, rx) = tokio::sync::oneshot::channel();
        let cfg = self.config();
        self.tx
            .send(Job::Generate { messages, options, config: cfg, cancel, sink, reply })
            .map_err(|_| CoreError::inference("推論ワーカーが停止しています"))?;
        Ok(rx)
    }

    pub fn shutdown(&self) {
        let _ = self.tx.send(Job::Shutdown);
    }
}

impl Drop for EngineHandle {
    fn drop(&mut self) {
        // 最後のハンドルが落ちる時にワーカーを終了させる
        if Arc::strong_count(&self.status) == 1 {
            let _ = self.tx.send(Job::Shutdown);
        }
    }
}

/// 生成時間を計測する小さなヘルパ
pub(crate) fn make_stats(
    prompt_tokens: usize,
    completion_tokens: usize,
    started: Instant,
    cancelled: bool,
    finish_reason: &str,
) -> GenStats {
    let elapsed_ms = started.elapsed().as_millis() as u64;
    let secs = (elapsed_ms as f32 / 1000.0).max(1e-3);
    GenStats {
        prompt_tokens,
        completion_tokens,
        elapsed_ms,
        tokens_per_sec: completion_tokens as f32 / secs,
        cancelled,
        finish_reason: finish_reason.to_string(),
    }
}

/// 部分 UTF-8 を正しく処理しながらトークン片を sink に流す。
/// 日本語（マルチバイト）はトークン境界が文字境界と一致しないことがあるため必須。
#[allow(dead_code)] // stub バックエンドでは未使用
pub(crate) fn flush_utf8(carry: &mut Vec<u8>, sink: &mut dyn TokenSink) -> bool {
    match std::str::from_utf8(carry) {
        Ok(text) => {
            if !text.is_empty() {
                sink.on_token(text);
            }
            carry.clear();
            true
        }
        Err(err) => {
            let valid = err.valid_up_to();
            if valid > 0 {
                // valid_up_to は必ず文字境界
                if let Ok(text) = std::str::from_utf8(&carry[..valid]) {
                    sink.on_token(text);
                }
                carry.drain(..valid);
            }
            false
        }
    }
}

/// キャンセルフラグの生成（Tauri 層から `Arc<AtomicBool>` を共有する）
pub fn new_cancel_flag() -> Arc<AtomicBool> {
    Arc::new(AtomicBool::new(false))
}

pub fn request_cancel(flag: &AtomicBool) {
    flag.store(true, Ordering::SeqCst);
}
