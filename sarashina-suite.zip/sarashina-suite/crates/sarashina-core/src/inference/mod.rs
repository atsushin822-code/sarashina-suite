//! ローカル推論レイヤー。
//!
//! ## アーキテクチャ
//! ```text
//!  ┌──────────────┐  invoke   ┌────────────────┐  Job(mpsc)  ┌────────────────────┐
//!  │  Svelte UI   │ ────────► │ Tauri command  │ ──────────► │ Inference Worker   │
//!  │ (chat panel) │ ◄──────── │  (async)       │             │ 専用 OS スレッド     │
//!  └──────────────┘  event    └────────────────┘             │ ├ LlamaBackend      │
//!                                                             │ ├ LlamaModel (mmap) │
//!                                                             │ └ LlamaContext/req  │
//!                                                             └────────────────────┘
//! ```
//! * `LlamaModel` / `LlamaContext` は `Send` ではない & ライフタイムを持つため、
//!   **ワーカースレッドが所有権を持ち続ける**設計にして unsafe を一切使わない。
//! * 生成トークンは `TokenSink` 経由でストリーミング（Tauri 層でイベント emit）。
//! * `feature = "llama"` を無効化するとスタブ実装に切り替わり、C++ ビルドなしで UI 開発できる。

pub mod engine;
pub mod prompt;

#[cfg(feature = "llama")]
mod llama;
#[cfg(not(feature = "llama"))]
mod stub;

pub use engine::{
    new_cancel_flag, request_cancel, Backend, ChatTurn, EngineConfig, EngineHandle, EngineStatus,
    GenOptions, GenStats, Job, StatusCallback, TokenSink, BACKEND_NAME,
};
