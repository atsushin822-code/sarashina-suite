//! アプリ状態（DB / 推論エンジン / HTTP クライアント / キャンセルフラグ）。

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};

use serde::Serialize;
use tauri::{AppHandle, Emitter, Manager};

use sarashina_core::catalog;
use sarashina_core::db::Database;
use sarashina_core::download;
use sarashina_core::error::{CoreError, Result};
use sarashina_core::inference::{EngineConfig, EngineHandle, EngineStatus, StatusCallback};

use crate::events;

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AppPaths {
    pub data_dir: String,
    pub db_path: String,
    pub models_dir: String,
    pub cache_dir: String,
}

pub struct AppState {
    pub db: Arc<Database>,
    pub engine: EngineHandle,
    pub client: sarashina_core::reqwest::Client,
    pub paths: Arc<AppPaths>,
    /// モデル ID → ダウンロードキャンセルフラグ
    pub downloads: Arc<Mutex<HashMap<String, Arc<AtomicBool>>>>,
    /// リクエスト ID → 生成キャンセルフラグ
    pub cancels: Arc<Mutex<HashMap<String, Arc<AtomicBool>>>>,
}

impl AppState {
    pub fn new(app: &AppHandle) -> Result<Self> {
        let data_dir = app
            .path()
            .app_local_data_dir()
            .map_err(|e| CoreError::Other(format!("データディレクトリを解決できません: {e}")))?;
        let cache_dir = app
            .path()
            .app_cache_dir()
            .unwrap_or_else(|_| data_dir.join("cache"));

        std::fs::create_dir_all(&data_dir)?;
        std::fs::create_dir_all(&cache_dir)?;
        let models_dir = data_dir.join("models");
        std::fs::create_dir_all(&models_dir)?;

        let db_path = data_dir.join("sarashina.db");
        let db = Arc::new(Database::open(&db_path)?);

        let paths = Arc::new(AppPaths {
            data_dir: data_dir.display().to_string(),
            db_path: db_path.display().to_string(),
            models_dir: models_dir.display().to_string(),
            cache_dir: cache_dir.display().to_string(),
        });

        // 起動時: アクティブモデルが設定されていれば即ロード開始
        let active = db.get_setting("active_model_id")?;
        let initial_model = active.as_deref().and_then(|id| {
            db.get_model(id).ok().flatten().and_then(|record| {
                let path = PathBuf::from(&record.path);
                if path.exists() { Some((record.id, path)) } else { None }
            })
        });

        let config = EngineConfig {
            n_ctx: db
                .get_setting("n_ctx")?
                .and_then(|v| v.parse().ok())
                .unwrap_or(4096),
            n_threads: db
                .get_setting("n_threads")?
                .and_then(|v| v.parse().ok())
                .unwrap_or_else(|| EngineConfig::default().n_threads),
            n_gpu_layers: db
                .get_setting("n_gpu_layers")?
                .and_then(|v| v.parse().ok())
                .unwrap_or(0),
        };

        // エンジンの状態変化をフロントへ流す
        let emit_handle = app.clone();
        let on_status: StatusCallback = Arc::new(move |status: &EngineStatus| {
            let _ = emit_handle.emit(events::ENGINE_STATUS, status.clone());
        });

        let engine = EngineHandle::spawn(initial_model, config, Some(on_status))?;
        let client = download::build_client()?;

        // ダウンロード途中のファイルがあれば再開情報をログに出す（実際の再開はユーザー操作）
        for variant in catalog::CATALOG {
            let part = download::part_path(&models_dir.join(variant.file_name));
            if part.exists() {
                tracing::info!("未完了のダウンロードを検出: {}", part.display());
            }
        }

        Ok(Self {
            db,
            engine,
            client,
            paths,
            downloads: Arc::new(Mutex::new(HashMap::new())),
            cancels: Arc::new(Mutex::new(HashMap::new())),
        })
    }
}
