use std::path::PathBuf;

use serde::Serialize;
use tauri::{AppHandle, Manager, State};

use sarashina_core::db::{Document, DocumentSummary, SearchHit};
use sarashina_core::error::{CoreError, Result};
use sarashina_core::export::{self, ExportFormat};

use super::blocking;
use crate::state::AppState;

#[tauri::command]
pub async fn list_documents(
    state: State<'_, AppState>,
    limit: Option<i64>,
    include_trash: Option<bool>,
) -> Result<Vec<DocumentSummary>> {
    let db = state.db.clone();
    let limit = limit.unwrap_or(500).clamp(1, 5000);
    let include_trash = include_trash.unwrap_or(false);
    blocking(move || db.list_documents(limit, include_trash)).await
}

#[tauri::command]
pub async fn get_document(state: State<'_, AppState>, id: String) -> Result<Option<Document>> {
    let db = state.db.clone();
    blocking(move || db.get_document(&id)).await
}

#[tauri::command]
pub async fn create_document(
    state: State<'_, AppState>,
    title: Option<String>,
    kind: Option<String>,
) -> Result<Document> {
    let db = state.db.clone();
    let kind = kind.unwrap_or_else(|| "doc".to_string());
    if !["doc", "sheet", "slide"].contains(&kind.as_str()) {
        return Err(CoreError::Invalid(format!("未知のドキュメント種別: {kind}")));
    }
    blocking(move || db.create_document(title.as_deref(), &kind)).await
}

/// 保存。自動保存から高頻度で呼ばれるため、
/// 「書き込み 1 回 + 上限 20 件のスナップショット」だけを行う軽量パスにしている。
#[tauri::command]
pub async fn save_document(
    state: State<'_, AppState>,
    id: String,
    title: String,
    content: String,
    plain_text: String,
) -> Result<i64> {
    let db = state.db.clone();
    blocking(move || {
        let ts = db.save_document(&id, &title, &content, &plain_text)?;
        db.snapshot_document(&id, &content, 20)?;
        Ok(ts)
    })
    .await
}

#[tauri::command]
pub async fn delete_document(
    state: State<'_, AppState>,
    id: String,
    purge: Option<bool>,
) -> Result<()> {
    let db = state.db.clone();
    blocking(move || db.delete_document(&id, purge.unwrap_or(false))).await
}

#[tauri::command]
pub async fn pin_document(state: State<'_, AppState>, id: String, pinned: bool) -> Result<()> {
    let db = state.db.clone();
    blocking(move || db.set_pinned(&id, pinned)).await
}

#[tauri::command]
pub async fn search_documents(
    state: State<'_, AppState>,
    query: String,
    limit: Option<i64>,
) -> Result<Vec<SearchHit>> {
    let db = state.db.clone();
    let limit = limit.unwrap_or(50).clamp(1, 200);
    blocking(move || db.search(&query, limit)).await
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ExportResult {
    pub path: String,
    pub format: String,
}

#[tauri::command]
pub async fn export_document(
    app: AppHandle,
    state: State<'_, AppState>,
    id: String,
    format: String,
    dest: Option<String>,
) -> Result<ExportResult> {
    let fmt = ExportFormat::parse(&format)?;
    let db = state.db.clone();
    let title = {
        let db = db.clone();
        let id2 = id.clone();
        blocking(move || db.get_document(&id2))
            .await?
            .map(|d| d.title)
            .unwrap_or_else(|| "document".to_string())
    };

    let target: PathBuf = match dest {
        Some(p) if !p.trim().is_empty() => PathBuf::from(p),
        _ => {
            // ダイアログ未指定時はダウンロードフォルダへ
            let dir = app
                .path()
                .download_dir()
                .unwrap_or_else(|_| PathBuf::from(&state.paths.data_dir));
            export::suggest_path(&dir, &title, fmt)
        }
    };

    let path = blocking(move || export::export_document(&db, &id, fmt, &target)).await?;
    Ok(ExportResult { path: path.display().to_string(), format: format!("{fmt:?}").to_lowercase() })
}
