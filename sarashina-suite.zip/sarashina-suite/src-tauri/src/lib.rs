//! Tauri デスクトップ層。
//!
//! ここは「OS と WebView の橋渡し」だけを担当し、ロジックは `sarashina-core` に置く。
//! コマンドは薄いアダプタ（DTO 変換・イベント emit）に保つこと。

mod commands;
mod events;
mod state;

use tauri::Manager;

use state::AppState;

pub fn run() {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,sarashina_core=debug".into()),
        )
        .init();

    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_dialog::init())
        .setup(|app| {
            let handle = app.handle();
            let state = AppState::new(handle).map_err(|e| {
                Box::new(std::io::Error::other(format!("初期化に失敗: {e}"))) as Box<dyn std::error::Error>
            })?;
            app.manage(state);
            Ok(())
        })
        .on_window_event(|window, event| {
            // 終了時に WAL をチェックポイント（次回起動を速く・安全に）
            if let tauri::WindowEvent::CloseRequested { .. } = event {
                if let Some(state) = window.app_handle().try_state::<AppState>() {
                    let _ = state.db.checkpoint();
                    state.engine.shutdown();
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            // app / settings
            commands::app_info,
            commands::db_stats,
            commands::setting_get,
            commands::setting_set,
            // documents
            commands::list_documents,
            commands::get_document,
            commands::create_document,
            commands::save_document,
            commands::delete_document,
            commands::pin_document,
            commands::search_documents,
            commands::export_document,
            // models
            commands::list_models,
            commands::download_model,
            commands::cancel_download,
            commands::delete_model,
            commands::activate_model,
            commands::engine_status,
            commands::engine_configure,
            // chat
            commands::ensure_session,
            commands::list_messages,
            commands::append_message,
            commands::chat_generate,
            commands::chat_cancel,
        ])
        .run(tauri::generate_context!())
        .expect("Tauri アプリケーションの起動に失敗しました");
}
