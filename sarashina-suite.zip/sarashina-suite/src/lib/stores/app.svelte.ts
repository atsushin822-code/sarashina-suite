// アプリ全体で共有する状態（Svelte 5 runes をモジュール内で使う）
import { api, isTauri, subscribe } from "../api";
import type { AppInfo, EngineStatus, ModelView } from "../types";

class AppStore {
  info = $state<AppInfo | null>(null);
  models = $state<ModelView[]>([]);
  engine = $state<EngineStatus | null>(null);
  booting = $state(true);
  demo = $state(!isTauri);

  /** モデルが 1 つでもインストール済みか（= AI が使える状態か） */
  get hasModel(): boolean {
    return this.models.some((m) => m.installed);
  }

  get activeModel(): ModelView | null {
    const id = this.engine?.modelId ?? this.info?.activeModelId;
    return this.models.find((m) => m.id === id) ?? null;
  }

  get engineLabel(): string {
    if (this.demo) return "デモモード";
    switch (this.engine?.state) {
      case "ready":
        return "ローカル AI 準備完了";
      case "loading":
        return "モデルを読み込み中…";
      case "generating":
        return "生成中…";
      case "error":
        return "エンジンエラー";
      default:
        return "モデル未ロード";
    }
  }

  async boot(): Promise<void> {
    try {
      const [info, models, engine] = await Promise.all([
        api.appInfo(),
        api.listModels(),
        api.engineStatus(),
      ]);
      this.info = info;
      this.models = models;
      this.engine = engine;

      await subscribe<EngineStatus>("engine://status", (status) => {
        this.engine = status;
      });
    } finally {
      this.booting = false;
    }
  }

  async refreshModels(): Promise<void> {
    this.models = await api.listModels();
    this.engine = await api.engineStatus();
  }
}

export const store = new AppStore();
