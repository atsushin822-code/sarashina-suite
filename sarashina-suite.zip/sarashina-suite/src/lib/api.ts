// Tauri コマンド呼び出しの唯一の窓口。
// コンポーネントから直接 `invoke()` を呼ばないことで、
// ① 型の一元管理 ② ブラウザ実行時のデモ fallback ③ 将来のテスト容易性 を確保する。

import { invoke } from "@tauri-apps/api/core";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { DemoBackend } from "./demo";
import type {
  AppInfo, ChatMessageRow, ChatTurn, DbStats, Doc, DocumentSummary, DownloadEvent,
  EngineStatus, GenOptions, GenStats, ModelView, SearchHit,
} from "./types";

export const isTauri = typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;

// --- イベントバス（ブラウザ実行時のみ使用） ---------------------------------
type Listener = (payload: unknown) => void;
const demoListeners = new Map<string, Set<Listener>>();

function demoEmit(event: string, payload: unknown) {
  demoListeners.get(event)?.forEach((fn) => fn(payload));
}

const demo = new DemoBackend(demoEmit);

export async function subscribe<T>(event: string, handler: (payload: T) => void): Promise<UnlistenFn> {
  if (isTauri) {
    return listen<T>(event, (e) => handler(e.payload));
  }
  const set = demoListeners.get(event) ?? new Set<Listener>();
  const fn: Listener = (payload) => handler(payload as T);
  set.add(fn);
  demoListeners.set(event, set);
  return () => {
    set.delete(fn);
  };
}

const call = <T,>(cmd: string, args?: Record<string, unknown>, fallback?: () => T | Promise<T>): Promise<T> => {
  if (isTauri) return invoke<T>(cmd, args);
  if (!fallback) throw new Error(`デモモードでは ${cmd} をサポートしていません`);
  return Promise.resolve(fallback());
};

export const api = {
  // --- app -----------------------------------------------------------------
  appInfo: () => call<AppInfo>("app_info", undefined, () => demo.appInfo()),
  dbStats: () => call<DbStats>("db_stats", undefined, () => demo.dbStats()),
  settingGet: (key: string) => call<string | null>("setting_get", { key }, () => demo.settingGet()),
  settingSet: (key: string, value: string) =>
    call<void>("setting_set", { key, value }, () => demo.settingSet()),

  // --- documents -----------------------------------------------------------
  listDocuments: (limit = 500) =>
    call<DocumentSummary[]>("list_documents", { limit }, () => demo.listDocuments()),
  getDocument: (id: string) => call<Doc | null>("get_document", { id }, () => demo.getDocument(id)),
  createDocument: (title?: string) =>
    call<Doc>("create_document", { title, kind: "doc" }, () => demo.createDocument(title)),
  saveDocument: (id: string, title: string, content: string, plainText: string) =>
    call<number>("save_document", { id, title, content, plainText }, () =>
      demo.saveDocument(id, title, content, plainText),
    ),
  deleteDocument: (id: string, purge = false) =>
    call<void>("delete_document", { id, purge }, () => demo.deleteDocument(id)),
  pinDocument: (id: string, pinned: boolean) =>
    call<void>("pin_document", { id, pinned }, () => demo.pinDocument(id, pinned)),
  searchDocuments: (query: string) =>
    call<SearchHit[]>("search_documents", { query }, () => demo.searchDocuments(query)),
  exportDocument: (id: string, format: string, dest?: string) =>
    call<{ path: string; format: string }>("export_document", { id, format, dest }, () =>
      demo.exportDocument(id, format),
    ),

  // --- models --------------------------------------------------------------
  listModels: () => call<ModelView[]>("list_models", undefined, () => demo.listModels()),
  downloadModel: (modelId: string) =>
    call<void>("download_model", { modelId }, () => demo.downloadModel(modelId)),
  cancelDownload: (modelId: string) =>
    call<void>("cancel_download", { modelId }, () => demo.cancelDownload(modelId)),
  deleteModel: (modelId: string) => call<void>("delete_model", { modelId }, () => demo.deleteModel(modelId)),
  activateModel: (modelId: string) =>
    call<void>("activate_model", { modelId }, () => demo.activateModel(modelId)),
  engineStatus: () => call<EngineStatus>("engine_status", undefined, () => demo.engineStatus()),
  engineConfigure: (nCtx: number, nThreads: number, nGpuLayers: number) =>
    call<EngineStatus>("engine_configure", { nCtx, nThreads, nGpuLayers }, () =>
      demo.engineConfigure(nCtx),
    ),

  // --- chat ----------------------------------------------------------------
  ensureSession: (documentId: string | null) =>
    call<string>("ensure_session", { documentId }, () => demo.ensureSession(documentId)),
  listMessages: (sessionId: string, limit = 100) =>
    call<ChatMessageRow[]>("list_messages", { sessionId, limit }, () => demo.listMessages(sessionId)),
  appendMessage: (sessionId: string, role: ChatMessageRow["role"], content: string) =>
    call<ChatMessageRow>("append_message", { sessionId, role, content }, () =>
      demo.appendMessage(sessionId, role, content),
    ),
  chatGenerate: (requestId: string, messages: ChatTurn[], options?: GenOptions) =>
    call<GenStats>("chat_generate", { requestId, messages, options }, () =>
      demo.chatGenerate(requestId, messages, options),
    ),
  chatCancel: (requestId: string) =>
    call<void>("chat_cancel", { requestId }, () => demo.chatCancel(requestId)),
};

export type { DownloadEvent };
