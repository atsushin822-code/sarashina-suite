<script lang="ts">
  import { onMount } from "svelte";
  import ModelCard from "../components/ModelCard.svelte";
  import { api, subscribe } from "../api";
  import { store } from "../stores/app.svelte";
  import { formatBytes } from "../format";
  import type { DbStats, DownloadEvent } from "../types";

  let { onback }: { onback: () => void } = $props();

  let stats = $state<DbStats | null>(null);
  let progress = $state<Record<string, DownloadEvent>>({});
  let nCtx = $state(4096);
  let nThreads = $state(4);
  let nGpuLayers = $state(0);
  let mirror = $state("");
  let savedNote = $state("");
  let unsub: (() => void) | undefined;

  onMount(() => {
    void init();
    return () => unsub?.();
  });

  async function init() {
    await store.refreshModels();
    stats = await api.dbStats();
    const [ctx, threads, gpu, mirrorSetting] = await Promise.all([
      api.settingGet("n_ctx"),
      api.settingGet("n_threads"),
      api.settingGet("n_gpu_layers"),
      api.settingGet("model_mirror"),
    ]);
    if (ctx) nCtx = Number(ctx);
    if (threads) nThreads = Number(threads);
    if (gpu) nGpuLayers = Number(gpu);
    mirror = mirrorSetting ?? "";

    unsub = await subscribe<DownloadEvent>("download://progress", (event) => {
      progress = { ...progress, [event.modelId]: event };
      if (event.phase === "completed" || event.phase === "failed") void store.refreshModels();
    });
  }

  async function applyEngine() {
    await api.engineConfigure(nCtx, nThreads, nGpuLayers);
    await api.settingSet("model_mirror", mirror);
    await store.refreshModels();
    savedNote = "保存しました（モデルを再読み込みしています）";
    setTimeout(() => (savedNote = ""), 2600);
  }

  async function download(id: string) {
    await api.downloadModel(id).catch((e) => console.error(e));
  }
  async function cancel(id: string) {
    await api.cancelDownload(id).catch(() => {});
  }
  async function remove(id: string) {
    await api.deleteModel(id);
    await store.refreshModels();
    stats = await api.dbStats();
  }
  async function activate(id: string) {
    await api.activateModel(id);
    await store.refreshModels();
  }
</script>

<div class="settings scroll">
  <div class="inner">
    <header class="row">
      <button class="ghost sm" onclick={onback}>← 戻る</button>
      <h1>設定</h1>
      <div class="spacer"></div>
      <span class="tag mono">v{store.info?.version ?? "0.1.0"}</span>
    </header>

    <section class="card">
      <h2>推論エンジン</h2>
      <p class="note">
        変更はモデルの再読み込み後に反映されます。CPU スレッド数は「物理コア数 - 1」が目安です。
        GPU オフロードは Metal / CUDA / Vulkan ビルドでのみ有効になります。
      </p>
      <div class="grid">
        <label>
          <span>コンテキスト長 (n_ctx)</span>
          <input type="number" min="512" max="32768" step="512" bind:value={nCtx} />
        </label>
        <label>
          <span>スレッド数</span>
          <input type="number" min="1" max="64" bind:value={nThreads} />
        </label>
        <label>
          <span>GPU レイヤー数 (0 = CPU のみ)</span>
          <input type="number" min="0" max="999" bind:value={nGpuLayers} />
        </label>
        <label>
          <span>モデル取得ミラー (任意)</span>
          <input type="text" placeholder="https://mirror.example/ai" bind:value={mirror} />
        </label>
      </div>
      <div class="row">
        <button class="primary sm" onclick={applyEngine}>適用</button>
        {#if savedNote}<span class="ok-note">{savedNote}</span>{/if}
        <div class="spacer"></div>
        <span class="tag mono">{store.engine?.backend ?? "—"} / {store.engine?.state ?? "—"}</span>
      </div>
    </section>

    <section>
      <h2 class="plain">モデル管理</h2>
      <div class="cards">
        {#each store.models as model (model.id)}
          <ModelCard
            {model}
            progress={progress[model.id] ?? null}
            active={store.engine?.modelId === model.id}
            ondownload={download}
            oncancel={cancel}
            ondelete={remove}
            onactivate={activate}
          />
        {/each}
      </div>
    </section>

    <section class="card">
      <h2>データとストレージ</h2>
      <div class="kv mono">
        <div><span>データベース</span><span>{store.info?.dbPath}</span></div>
        <div><span>モデル</span><span>{store.info?.modelsDir}</span></div>
        <div><span>キャッシュ</span><span>{store.info?.cacheDir}</span></div>
      </div>
      {#if stats}
        <div class="stats">
          <div><span class="n">{stats.documents}</span><span class="l">ドキュメント</span></div>
          <div><span class="n">{stats.characters.toLocaleString("ja-JP")}</span><span class="l">文字</span></div>
          <div><span class="n">{stats.chatMessages}</span><span class="l">会話メッセージ</span></div>
          <div><span class="n">{stats.models}</span><span class="l">モデル</span></div>
          <div><span class="n">v{stats.schemaVersion}</span><span class="l">スキーマ</span></div>
        </div>
      {/if}
      <p class="note">
        {#if store.models.some((m) => m.installed)}
          使用中のディスク: {formatBytes(store.models.filter((m) => m.installed).reduce((n, m) => n + m.sizeBytes, 0))}（モデルのみ）
        {/if}
        すべてのデータはこの端末内にのみ保存されます。クラウド同期・テレメトリ送信は行いません。
      </p>
    </section>
  </div>
</div>

<style>
  .settings { height: 100vh; overflow-y: auto; background: var(--bg); }
  .inner { max-width: 880px; margin: 0 auto; padding: 26px 32px 80px; display: flex; flex-direction: column; gap: 22px; }
  header h1 { font-size: 19px; margin: 0 0 0 6px; }
  h2 { font-size: 14px; margin: 0 0 10px; }
  h2.plain { margin-left: 2px; }
  .card { padding: 18px; }
  .note { font-size: 12px; color: var(--text-soft); line-height: 1.75; margin: 0 0 14px; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 12px; margin-bottom: 14px; }
  label { display: flex; flex-direction: column; gap: 5px; font-size: 12px; color: var(--text-soft); }
  label input { width: 100%; }
  .ok-note { font-size: 12px; color: var(--ok); }
  .cards { display: flex; flex-direction: column; gap: 12px; }
  .kv { font-size: 11.5px; display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
  .kv div { display: flex; gap: 12px; }
  .kv span:first-child { color: var(--text-faint); width: 92px; flex: none; }
  .kv span:last-child { color: var(--text-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .stats { display: flex; gap: 22px; flex-wrap: wrap; margin-bottom: 12px; }
  .stats div { display: flex; flex-direction: column; }
  .n { font-size: 17px; font-weight: 650; font-variant-numeric: tabular-nums; }
  .l { font-size: 10.5px; color: var(--text-faint); }
</style>
