<script lang="ts">
  import { onMount } from "svelte";
  import ModelCard from "../components/ModelCard.svelte";
  import { api, subscribe } from "../api";
  import { store } from "../stores/app.svelte";
  import type { DownloadEvent } from "../types";

  let { ondone }: { ondone: () => void } = $props();

  let progress = $state<Record<string, DownloadEvent>>({});
  let error = $state<string | null>(null);
  let unsub: (() => void) | undefined;

  onMount(() => {
    void init();
    return () => unsub?.();
  });

  async function init() {
    await store.refreshModels();
    unsub = await subscribe<DownloadEvent>("download://progress", (event) => {
      progress = { ...progress, [event.modelId]: event };
      if (event.phase === "failed") {
        error = event.message ?? "ダウンロードに失敗しました";
      }
      if (event.phase === "completed") {
        error = null;
        void store.refreshModels().then(() => {
          // 自動で先へ進む（ユーザーが待たされない）
          setTimeout(ondone, 900);
        });
      }
      if (event.phase === "cancelled") {
        progress = { ...progress, [event.modelId]: event };
        void store.refreshModels();
      }
    });
  }

  async function download(id: string) {
    error = null;
    try {
      await api.downloadModel(id);
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
  }

  async function cancel(id: string) {
    await api.cancelDownload(id).catch(() => {});
  }

  async function remove(id: string) {
    await api.deleteModel(id);
    await store.refreshModels();
  }

  async function activate(id: string) {
    await api.activateModel(id);
    await store.refreshModels();
  }
</script>

<div class="onboarding scroll">
  <div class="inner">
    <header>
      <div class="badge">オフライン完結</div>
      <h1>Sarashina Suite へようこそ</h1>
      <p class="lead">
        文書作成と AI 支援のすべてを、端末の中だけで完結させます。
        まずは日本語に強い軽量モデル <b>Sarashina 2.2</b> を 1 つ選んでダウンロードしてください。
        取得したモデルはこの端末のローカルフォルダに保存され、以降はネットワークなしで動作します。
      </p>
      <div class="facts">
        <div><span class="k">推論</span><span class="v">llama.cpp（CPU / Metal / CUDA / Vulkan）</span></div>
        <div><span class="k">保存先</span><span class="v mono">{store.info?.modelsDir ?? "—"}</span></div>
        <div><span class="k">エンジン</span><span class="v mono">{store.info?.backend ?? "—"}</span></div>
      </div>
    </header>

    {#if error}
      <div class="error">{error}</div>
    {/if}

    <div class="cards">
      {#each store.models as model (model.id)}
        <ModelCard
          {model}
          progress={progress[model.id] ?? null}
          busy={false}
          active={store.info?.activeModelId === model.id}
          ondownload={download}
          oncancel={cancel}
          ondelete={remove}
          onactivate={activate}
        />
      {/each}
    </div>

    <footer>
      <p class="faint small">
        ダウンロードは途中で中断しても再開できます（HTTP Range + SHA-256 検証付き）。
        モデルはアプリのバイナリには含まれないため、インストーラは軽量なままです。
      </p>
      <button class="ghost" onclick={ondone}>あとで設定する（AI なしで書き始める）</button>
    </footer>
  </div>
</div>

<style>
  .onboarding { height: 100vh; overflow-y: auto; background: var(--bg); }
  .inner { max-width: 880px; margin: 0 auto; padding: 56px 32px 80px; }
  header { margin-bottom: 28px; }
  .badge {
    display: inline-block; font-size: 11px; letter-spacing: 0.06em;
    padding: 3px 10px; border-radius: 999px; margin-bottom: 14px;
    background: var(--accent-soft); color: var(--accent-text); font-weight: 600;
  }
  h1 { font-size: 28px; margin: 0 0 12px; letter-spacing: -0.015em; }
  .lead { font-size: 14px; color: var(--text-soft); margin: 0 0 18px; line-height: 1.85; max-width: 62ch; }
  .facts {
    display: grid; gap: 6px; font-size: 12.5px;
    border: 1px solid var(--border); border-radius: var(--radius);
    padding: 12px 14px; background: var(--bg-elev);
  }
  .facts div { display: flex; gap: 12px; }
  .k { color: var(--text-faint); width: 62px; flex: none; }
  .v { color: var(--text-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .cards { display: flex; flex-direction: column; gap: 12px; }
  .error {
    margin-bottom: 14px; padding: 11px 13px; border-radius: 10px; font-size: 13px;
    color: var(--danger); background: rgba(220, 38, 38, 0.07);
    border: 1px solid rgba(220, 38, 38, 0.2); white-space: pre-wrap;
  }
  footer { margin-top: 26px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
  .small { font-size: 11.5px; line-height: 1.7; max-width: 52ch; margin: 0; }
</style>
