<script lang="ts">
  import { onMount } from "svelte";
  import Sidebar from "../components/Sidebar.svelte";
  import Editor from "../components/Editor.svelte";
  import AIPanel from "../components/AIPanel.svelte";
  import { api } from "../api";
  import { store } from "../stores/app.svelte";
  import type { Doc, DocumentSummary } from "../types";

  let {
    onsettings,
    oninstall,
  }: { onsettings: () => void; oninstall: () => void } = $props();

  let documents = $state<DocumentSummary[]>([]);
  let activeId = $state<string | null>(null);
  let activeDoc = $state<Doc | null>(null);
  let aiOpen = $state(true);

  async function refresh(selectId?: string) {
    documents = await api.listDocuments();
    const id = selectId ?? activeId ?? documents[0]?.id ?? null;
    if (id) await open(id);
  }

  async function open(id: string) {
    if (activeDoc && activeDoc.id !== id) {
      // 切替前に保存（Editor 側の onblur と二重でも安全 = 冪等）
      await api
        .saveDocument(activeDoc.id, activeDoc.title, activeDoc.content, activeDoc.plainText)
        .catch(() => {});
    }
    activeId = id;
    activeDoc = await api.getDocument(id);
  }

  async function create() {
    const doc = await api.createDocument();
    await refresh(doc.id);
  }

  async function remove(id: string) {
    await api.deleteDocument(id, false);
    if (activeId === id) activeDoc = null;
    await refresh();
    if (documents.length === 0) create();
  }

  async function pin(id: string, pinned: boolean) {
    await api.pinDocument(id, pinned);
    await refresh();
  }

  function onSaved(updatedAt: number, title: string) {
    if (activeDoc) {
      activeDoc = { ...activeDoc, title, updatedAt };
    }
    const entry = documents.find((d) => d.id === activeDoc?.id);
    if (entry) {
      entry.title = title;
      entry.updatedAt = updatedAt;
      documents = [...documents].sort(
        (a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt,
      );
    }
  }

  onMount(async () => {
    await refresh();
    if (documents.length === 0) await create();
  });
</script>

<div class="layout" class:ai-closed={!aiOpen}>
  <Sidebar
    {documents}
    activeId={activeId}
    engineLabel={store.engineLabel}
    demo={store.demo}
    onselect={open}
    oncreate={create}
    ondelete={remove}
    onpin={pin}
    {onsettings}
    {oninstall}
  />

  <main>
    <div class="topbar">
      <span class="crumb">
        {store.demo ? "デモ" : "ローカル"}
        <span class="faint">/</span>
        {activeDoc?.title ?? "ドキュメント"}
      </span>
      <div class="spacer"></div>
      <button class="ghost sm" onclick={() => (aiOpen = !aiOpen)}>
        {aiOpen ? "AI パネルを隠す" : "AI パネルを表示"}
      </button>
    </div>
    <div class="editor-area">
      <Editor doc={activeDoc} {onSaved} />
    </div>
  </main>

  {#if aiOpen}
    <div class="ai">
      <AIPanel
        doc={activeDoc}
        engineReady={store.engine?.state === "ready"}
        engineLabel={store.engineLabel}
        onRequestInstall={oninstall}
      />
    </div>
  {/if}
</div>

<style>
  .layout {
    display: grid;
    grid-template-columns: 272px minmax(0, 1fr) 348px;
    height: 100vh;
    background: var(--bg);
  }
  .layout.ai-closed { grid-template-columns: 272px minmax(0, 1fr); }
  main { display: flex; flex-direction: column; min-width: 0; }
  .topbar {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 14px; border-bottom: 1px solid var(--border);
    background: var(--bg-elev); min-height: 41px;
  }
  .crumb { font-size: 12.5px; color: var(--text-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .editor-area { flex: 1; min-height: 0; }
  .ai { min-width: 0; }
  @media (max-width: 1180px) {
    .layout { grid-template-columns: 232px minmax(0, 1fr); }
    .ai { display: none; }
  }
</style>
