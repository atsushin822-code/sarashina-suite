<script lang="ts">
  import ProgressBar from "./ProgressBar.svelte";
  import { formatBytes, formatEta, formatSpeed } from "../format";
  import type { DownloadEvent, ModelView } from "../types";

  let {
    model,
    progress = null,
    busy = false,
    ondownload,
    oncancel,
    ondelete,
    onactivate,
    active = false,
  }: {
    model: ModelView;
    progress?: DownloadEvent | null;
    busy?: boolean;
    ondownload: (id: string) => void;
    oncancel: (id: string) => void;
    ondelete: (id: string) => void;
    onactivate: (id: string) => void;
    active?: boolean;
  } = $props();

  const downloading = $derived(model.status === "downloading" && progress != null);
  const ratio = $derived(
    progress && progress.total > 0 ? Math.min(1, progress.downloaded / progress.total) : 0,
  );
  const phaseLabel = $derived(
    progress?.phase === "verifying"
      ? "SHA-256 を検証中"
      : progress?.phase === "preparing"
        ? "準備中"
        : "ダウンロード中",
  );
</script>

<article class:recommended={model.recommended} class:active>
  <div class="head">
    <div>
      <h3>
        {model.displayName}
        {#if model.recommended}<span class="tag accent">推奨</span>{/if}
        {#if active}<span class="tag ok">使用中</span>{/if}
      </h3>
      <p class="desc">{model.description}</p>
    </div>
    <div class="specs mono">
      <div>{formatBytes(model.sizeBytes)}</div>
      <div class="faint">RAM {model.minRamGb}GB+</div>
    </div>
  </div>

  <div class="meta">
    <span class="tag">{model.params}</span>
    <span class="tag">{model.quant}</span>
    <span class="tag">日本語</span>
    <span class="tag">MIT</span>
    {#if model.installed}<span class="tag ok">インストール済み</span>{/if}
    {#if model.status === "partial"}<span class="tag warn">中断あり（再開可能）</span>{/if}
  </div>

  {#if progress && model.status === "downloading"}
    <div class="progress">
      <ProgressBar
        value={ratio}
        label={phaseLabel}
        detail={`${formatBytes(progress.downloaded)} / ${formatBytes(progress.total)} ・ ${formatSpeed(progress.bytesPerSec)} ・ ${formatEta(progress.etaSecs)}`}
        indeterminate={progress.phase === "preparing"}
      />
    </div>
  {/if}

  <div class="actions">
    {#if model.installed}
      {#if !active}
        <button class="sm" onclick={() => onactivate(model.id)}>このモデルを使う</button>
      {/if}
      <button class="sm danger" onclick={() => ondelete(model.id)}>削除</button>
    {:else if downloading}
      <button class="sm danger" onclick={() => oncancel(model.id)}>キャンセル</button>
    {:else}
      <button class="primary sm" disabled={busy} onclick={() => ondownload(model.id)}>
        {model.status === "partial" ? "ダウンロードを再開" : "ダウンロード"}
      </button>
    {/if}
    <span class="file mono faint">{model.fileName}</span>
  </div>
</article>

<style>
  article {
    border: 1px solid var(--border); border-radius: var(--radius-lg);
    background: var(--bg-elev); padding: 16px 18px; box-shadow: var(--shadow-sm);
    display: flex; flex-direction: column; gap: 11px;
  }
  article.recommended { border-color: color-mix(in srgb, var(--accent) 32%, var(--border)); }
  article.active {
    box-shadow: 0 0 0 1px color-mix(in srgb, var(--ok) 40%, transparent), var(--shadow-sm);
  }
  .head { display: flex; justify-content: space-between; gap: 14px; align-items: flex-start; }
  h3 {
    margin: 0 0 4px; font-size: 14.5px; font-weight: 650;
    display: flex; align-items: center; gap: 7px; flex-wrap: wrap;
  }
  .desc { margin: 0; font-size: 12.5px; color: var(--text-soft); line-height: 1.6; }
  .specs { text-align: right; font-size: 12px; flex: none; }
  .meta { display: flex; gap: 5px; flex-wrap: wrap; }
  .progress { padding: 2px 0; }
  .actions { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .file { font-size: 10.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
