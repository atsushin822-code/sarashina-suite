<script lang="ts">
  import { api } from "../api";
  import { formatRelative } from "../format";
  import type { DocumentSummary, SearchHit } from "../types";

  let {
    documents = [],
    activeId = null,
    engineLabel = "",
    demo = false,
    onselect,
    oncreate,
    ondelete,
    onpin,
    onsettings,
    oninstall,
  }: {
    documents: DocumentSummary[];
    activeId?: string | null;
    engineLabel?: string;
    demo?: boolean;
    onselect: (id: string) => void;
    oncreate: () => void;
    ondelete: (id: string) => void;
    onpin: (id: string, pinned: boolean) => void;
    onsettings: () => void;
    oninstall: () => void;
  } = $props();

  let query = $state("");
  let hits = $state<SearchHit[]>([]);
  let searching = $state(false);

  // FTS5(trigram) 全文検索。2 文字以上で発火し、入力は 250ms デバウンス。
  let timer: ReturnType<typeof setTimeout> | undefined;
  function onSearchInput() {
    clearTimeout(timer);
    const q = query.trim();
    if (q.length < 2) {
      hits = [];
      searching = false;
      return;
    }
    searching = true;
    timer = setTimeout(async () => {
      try {
        hits = await api.searchDocuments(q);
      } catch {
        hits = [];
      } finally {
        searching = false;
      }
    }, 250);
  }
</script>

<aside>
  <div class="brand">
    <div class="logo">S</div>
    <div>
      <div class="name">Sarashina Suite</div>
      <div class="sub">{demo ? "デモモード" : "ローカル・オフライン"}</div>
    </div>
  </div>

  <div class="actions">
    <button class="primary new" onclick={oncreate}>
      <span class="plus">＋</span> 新規ドキュメント
    </button>
  </div>

  <div class="search">
    <input
      type="search"
      placeholder="全文検索 (2 文字以上)"
      bind:value={query}
      oninput={onSearchInput}
      aria-label="全文検索"
    />
  </div>

  <div class="list scroll">
    {#if query.trim().length >= 2}
      <div class="section-title">
        検索結果 <span class="faint">{searching ? "…" : `${hits.length} 件`}</span>
      </div>
      {#each hits as hit (hit.id)}
        <button class="item" class:active={hit.id === activeId} onclick={() => onselect(hit.id)}>
          <div class="item-title">{hit.title}</div>
          <div class="item-preview">{@html hit.snippet.replaceAll("<<", "<mark>").replaceAll(">>", "</mark>")}</div>
        </button>
      {:else}
        <div class="empty">該当なし</div>
      {/each}
    {:else}
      <div class="section-title">ドキュメント <span class="faint">{documents.length}</span></div>
      {#each documents as doc (doc.id)}
        <div class="item-wrap">
          <button class="item" class:active={doc.id === activeId} onclick={() => onselect(doc.id)}>
            <div class="item-title">
              {#if doc.pinned}<span class="pin">●</span>{/if}
              {doc.title}
            </div>
            <div class="item-preview">{doc.preview || "（空のドキュメント）"}</div>
            <div class="item-meta">{formatRelative(doc.updatedAt)}</div>
          </button>
          <div class="item-tools">
            <button
              class="ghost sm"
              title={doc.pinned ? "ピン留めを解除" : "ピン留め"}
              onclick={() => onpin(doc.id, !doc.pinned)}>★</button>
            <button class="ghost sm" title="削除" onclick={() => ondelete(doc.id)}>🗑</button>
          </div>
        </div>
      {:else}
        <div class="empty">ドキュメントがありません</div>
      {/each}
    {/if}
  </div>

  <div class="footer">
    <button class="engine" onclick={oninstall}>
      <span class="dot" class:on={engineLabel.includes("準備完了")}></span>
      <span class="engine-label">{engineLabel}</span>
    </button>
    <button class="ghost sm" title="設定" onclick={onsettings}>⚙ 設定</button>
  </div>
</aside>

<style>
  aside {
    display: flex;
    flex-direction: column;
    height: 100%;
    background: var(--sidebar);
    border-right: 1px solid var(--border);
    min-width: 0;
  }
  .brand { display: flex; gap: 10px; align-items: center; padding: 16px 16px 10px; }
  .logo {
    width: 30px; height: 30px; border-radius: 9px;
    background: linear-gradient(135deg, var(--accent), #22d3ee);
    color: #fff; font-weight: 700; display: grid; place-items: center;
    box-shadow: var(--shadow-sm);
  }
  .name { font-weight: 650; font-size: 13.5px; letter-spacing: 0.01em; }
  .sub { font-size: 11px; color: var(--text-faint); }
  .actions { padding: 4px 12px 10px; }
  .new { width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; }
  .plus { font-weight: 700; }
  .search { padding: 0 12px 10px; }
  .search input { width: 100%; padding: 7px 10px; font-size: 13px; }
  .list { flex: 1; padding: 0 8px 8px; min-height: 0; }
  .section-title {
    font-size: 11px; text-transform: uppercase; letter-spacing: 0.07em;
    color: var(--text-faint); padding: 8px 8px 6px;
  }
  .item-wrap { position: relative; }
  .item {
    display: block; width: 100%; text-align: left;
    background: transparent; border: 1px solid transparent; border-radius: 9px;
    padding: 8px 10px; margin-bottom: 2px;
  }
  .item:hover { background: var(--bg-sunken); }
  .item.active { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 25%, transparent); }
  .item-title {
    font-size: 13px; font-weight: 600; color: var(--text);
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .pin { color: var(--accent); font-size: 9px; margin-right: 3px; }
  .item-preview {
    font-size: 11.5px; color: var(--text-faint); line-height: 1.45;
    display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;
    overflow: hidden; margin-top: 1px;
  }
  .item-preview :global(mark) { background: color-mix(in srgb, var(--accent) 22%, transparent); color: inherit; border-radius: 3px; }
  .item-meta { font-size: 10.5px; color: var(--text-faint); margin-top: 3px; }
  .item-tools {
    position: absolute; right: 6px; top: 6px; display: none; gap: 2px;
    background: var(--bg-elev); border-radius: 8px; box-shadow: var(--shadow-sm); padding: 1px;
  }
  .item-wrap:hover .item-tools { display: flex; }
  .empty { padding: 22px 10px; text-align: center; color: var(--text-faint); font-size: 12.5px; }
  .footer {
    border-top: 1px solid var(--border); padding: 10px 12px;
    display: flex; align-items: center; gap: 8px;
  }
  .engine {
    flex: 1; display: flex; align-items: center; gap: 7px; justify-content: flex-start;
    font-size: 11.5px; color: var(--text-soft); background: transparent; border-color: transparent;
    overflow: hidden;
  }
  .engine:hover { background: var(--bg-sunken); }
  .engine-label { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: var(--text-faint); flex: none; }
  .dot.on { background: var(--ok); box-shadow: 0 0 0 3px color-mix(in srgb, var(--ok) 18%, transparent); }
</style>
