<script lang="ts">
  let {
    value = 0,
    label = "",
    detail = "",
    indeterminate = false,
  }: { value?: number; label?: string; detail?: string; indeterminate?: boolean } = $props();

  const pct = $derived(Math.max(0, Math.min(100, Math.round(value * 100))));
</script>

<div class="wrap">
  {#if label || detail}
    <div class="head">
      <span class="label">{label}</span>
      <span class="mono pct">{indeterminate ? "…" : `${pct}%`}</span>
    </div>
  {/if}
  <div class="track" role="progressbar" aria-valuenow={pct} aria-valuemin="0" aria-valuemax="100">
    <div class="fill" class:indeterminate style={indeterminate ? undefined : `width:${pct}%`}></div>
  </div>
  {#if detail}
    <div class="detail mono">{detail}</div>
  {/if}
</div>

<style>
  .wrap { display: flex; flex-direction: column; gap: 6px; }
  .head { display: flex; justify-content: space-between; font-size: 12.5px; }
  .label { color: var(--text-soft); }
  .pct { color: var(--text-faint); }
  .track {
    height: 7px;
    background: var(--bg-sunken);
    border-radius: 999px;
    overflow: hidden;
    border: 1px solid var(--border);
  }
  .fill {
    height: 100%;
    background: linear-gradient(90deg, var(--accent), color-mix(in srgb, var(--accent) 55%, #22d3ee));
    transition: width 0.18s ease-out;
    border-radius: 999px;
  }
  .fill.indeterminate {
    width: 40%;
    animation: slide 1.15s ease-in-out infinite;
  }
  @keyframes slide {
    0% { margin-left: -40%; }
    100% { margin-left: 100%; }
  }
  .detail { font-size: 11.5px; color: var(--text-faint); }
</style>
