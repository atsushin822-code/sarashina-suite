<script lang="ts">
  import { api, subscribe } from "../api";
  import { DEFAULT_GEN_OPTIONS, type ChatTurn, type Doc, type GenStats } from "../types";

  let {
    doc = null,
    engineReady = false,
    engineLabel = "",
    onRequestInstall,
  }: {
    doc?: Doc | null;
    engineReady?: boolean;
    engineLabel?: string;
    onRequestInstall: () => void;
  } = $props();

  type Bubble = { role: "user" | "assistant"; content: string };

  let bubbles = $state<Bubble[]>([]);
  let draft = $state("");
  let streaming = $state(false);
  let error = $state<string | null>(null);
  let sessionId = $state<string | null>(null);
  let stats = $state<GenStats | null>(null);
  let requestId = $state<string | null>(null);
  let scrollEl = $state<HTMLDivElement>();
  let loadedFor = $state<string | null>(null);

  const SYSTEM_PROMPT =
    "あなたは日本語のビジネス文書作成を支援するアシスタントです。出力は簡潔で、根拠のない断定を避け、" +
    "依頼された作業だけを行ってください。マークダウンは使わず、プレーンテキストで整形します。";

  const PRESETS: Array<{ label: string; instruction: string }> = [
    { label: "校正", instruction: "本文の誤字脱字・表記ゆれ・冗長な表現を修正し、修正点を箇条書きで示してください。" },
    { label: "要約", instruction: "本文を 3 行以内で要約してください。" },
    { label: "箇条書き化", instruction: "本文を読みやすい箇条書きに整理してください。" },
    { label: "続きを書く", instruction: "本文の流れを保ったまま、続きの段落を 1 つ書いてください。" },
    { label: "敬語チェック", instruction: "本文の敬語の使い方を点検し、不自然な箇所を修正してください。" },
  ];

  // ドキュメントを切り替えたら会話履歴を読み直す
  $effect(() => {
    const id = doc?.id ?? null;
    if (id === loadedFor) return;
    loadedFor = id;
    bubbles = [];
    stats = null;
    error = null;
    void loadHistory(id);
  });

  async function loadHistory(documentId: string | null) {
    try {
      sessionId = await api.ensureSession(documentId);
      const rows = await api.listMessages(sessionId, 40);
      bubbles = rows.map((r) => ({ role: r.role === "user" ? "user" : "assistant", content: r.content }));
    } catch (e) {
      console.error(e);
    }
  }

  $effect(() => {
    // 新着・ストリーミングで最下部へ
    void bubbles.length;
    void streaming;
    if (scrollEl) scrollEl.scrollTop = scrollEl.scrollHeight;
  });

  function buildMessages(instruction: string): ChatTurn[] {
    const body = (doc?.plainText ?? "").slice(0, 6000);
    const user = body
      ? `# 本文\n${body}\n\n# 依頼\n${instruction}`
      : `# 依頼\n${instruction}`;
    return [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: user },
    ];
  }

  async function run(instruction: string, display = instruction) {
    if (!engineReady) {
      error = "モデルがまだ準備できていません。先にモデルをインストールしてください。";
      return;
    }
    if (streaming || !sessionId) return;

    error = null;
    bubbles = [...bubbles, { role: "user", content: display }, { role: "assistant", content: "" }];
    streaming = true;
    const rid = crypto.randomUUID();
    requestId = rid;

    const unsubToken = await subscribe<{ requestId: string; delta: string }>("llm://token", (p) => {
      if (p.requestId !== rid) return;
      const last = bubbles[bubbles.length - 1];
      if (last) last.content += p.delta;
    });

    try {
      void api.appendMessage(sessionId, "user", display);
      const result = await api.chatGenerate(rid, buildMessages(instruction), DEFAULT_GEN_OPTIONS);
      stats = result;
      const answer = bubbles[bubbles.length - 1]?.content ?? "";
      if (answer) void api.appendMessage(sessionId, "assistant", answer);
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
      // 応答が空のバブルは取り除く
      if (!bubbles[bubbles.length - 1]?.content) bubbles = bubbles.slice(0, -1);
    } finally {
      unsubToken();
      streaming = false;
      requestId = null;
    }
  }

  async function stop() {
    if (requestId) await api.chatCancel(requestId).catch(() => {});
  }

  function copy(text: string) {
    void navigator.clipboard?.writeText(text);
  }
</script>

<section>
  <header>
    <div class="row">
      <span class="title">AI アシスタント</span>
      <span class="tag" class:ok={engineReady} class:accent={!engineReady}>{engineLabel}</span>
    </div>
    {#if stats && stats.completionTokens > 0}
      <div class="stats mono">
        {stats.completionTokens} tok / {stats.tokensPerSec.toFixed(1)} tok/s / {stats.elapsedMs} ms
      </div>
    {/if}
  </header>

  {#if !engineReady}
    <div class="notice">
      <p>ローカルモデルが未インストールです。AI 機能を使うには Sarashina モデルをダウンロードしてください（初回のみ・完全ローカル保存）。</p>
      <button class="primary sm" onclick={onRequestInstall}>モデルをインストール</button>
    </div>
  {/if}

  <div class="messages scroll" bind:this={scrollEl}>
    {#if bubbles.length === 0}
      <div class="hint">
        <p class="faint">本文を書いてから、下のボタンで AI に依頼できます。</p>
      </div>
    {/if}
    {#each bubbles as bubble, i (i)}
      <div class="bubble {bubble.role}">
        <div class="role">{bubble.role === "user" ? "あなた" : "Sarashina"}</div>
        <div class="body" class:streaming={streaming && i === bubbles.length - 1}>{bubble.content || "…"}</div>
        {#if bubble.role === "assistant" && bubble.content && !(streaming && i === bubbles.length - 1)}
          <button class="ghost sm copy" onclick={() => copy(bubble.content)}>コピー</button>
        {/if}
      </div>
    {/each}
    {#if error}
      <div class="error">{error}</div>
    {/if}
  </div>

  <div class="composer">
    <div class="presets">
      {#each PRESETS as preset (preset.label)}
        <button class="sm" disabled={streaming || !engineReady} onclick={() => run(preset.instruction)}>
          {preset.label}
        </button>
      {/each}
    </div>
    <div class="input-row">
      <textarea
        bind:value={draft}
        placeholder="指示を入力（例: この段落を200字で要約して）"
        rows="2"
        onkeydown={(e) => {
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
            e.preventDefault();
            if (draft.trim()) {
              void run(draft.trim());
              draft = "";
            }
          }
        }}
      ></textarea>
      {#if streaming}
        <button class="danger sm" onclick={stop}>停止</button>
      {:else}
        <button
          class="primary sm"
          disabled={!engineReady || !draft.trim()}
          onclick={() => {
            const text = draft.trim();
            if (!text) return;
            draft = "";
            void run(text);
          }}>送信</button>
      {/if}
    </div>
    <div class="hint-line faint">⌘/Ctrl + Enter で送信 ・ 推論はすべて端末内で実行されます</div>
  </div>
</section>

<style>
  section {
    display: flex; flex-direction: column; height: 100%; min-width: 0;
    background: var(--bg-elev); border-left: 1px solid var(--border);
  }
  header { padding: 12px 14px 8px; border-bottom: 1px solid var(--border); }
  .title { font-weight: 650; font-size: 13px; }
  .stats { font-size: 10.5px; color: var(--text-faint); margin-top: 3px; }
  .notice {
    margin: 12px; padding: 12px; border-radius: 10px;
    background: var(--accent-soft); border: 1px solid color-mix(in srgb, var(--accent) 22%, transparent);
    font-size: 12.5px; color: var(--text);
  }
  .notice p { margin: 0 0 9px; line-height: 1.6; }
  .messages { flex: 1; padding: 12px; display: flex; flex-direction: column; gap: 12px; min-height: 0; }
  .hint { padding: 20px 4px; text-align: center; }
  .bubble { display: flex; flex-direction: column; gap: 3px; }
  .bubble.user .body {
    background: var(--accent-soft);
    border: 1px solid color-mix(in srgb, var(--accent) 16%, transparent);
  }
  .bubble.assistant .body { background: var(--bg-sunken); border: 1px solid var(--border); }
  .role { font-size: 10.5px; color: var(--text-faint); letter-spacing: 0.04em; }
  .body {
    padding: 9px 11px; border-radius: 10px; font-size: 13px; line-height: 1.75;
    white-space: pre-wrap; word-break: break-word;
  }
  .body.streaming::after {
    content: "▌"; color: var(--accent); animation: pulse 1s infinite; margin-left: 1px;
  }
  .copy { align-self: flex-start; margin-top: 1px; font-size: 11px; }
  .error {
    font-size: 12.5px; color: var(--danger);
    background: rgba(220, 38, 38, 0.07); border: 1px solid rgba(220, 38, 38, 0.2);
    padding: 9px 11px; border-radius: 9px; white-space: pre-wrap;
  }
  .composer { border-top: 1px solid var(--border); padding: 10px 12px 12px; }
  .presets { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 8px; }
  .presets button { font-size: 11.5px; padding: 4px 9px; }
  .input-row { display: flex; gap: 6px; align-items: flex-end; }
  .input-row textarea {
    flex: 1; resize: none; font-size: 13px; line-height: 1.6; min-height: 40px;
  }
  .hint-line { font-size: 10.5px; margin-top: 6px; text-align: center; }
</style>
