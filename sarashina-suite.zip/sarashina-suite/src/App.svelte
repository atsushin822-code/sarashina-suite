<script lang="ts">
  import { onMount } from "svelte";
  import Onboarding from "./lib/views/Onboarding.svelte";
  import Workspace from "./lib/views/Workspace.svelte";
  import Settings from "./lib/views/Settings.svelte";
  import { store } from "./lib/stores/app.svelte";

  type View = "loading" | "onboarding" | "workspace" | "settings";

  let view = $state<View>("loading");

  onMount(async () => {
    await store.boot();
    // モデルが 1 つも入っていなければ初回セットアップへ
    view = store.hasModel ? "workspace" : "onboarding";
  });
</script>

{#if view === "loading" || store.booting}
  <div class="boot center">
    <div class="mark">S</div>
    <p class="muted">起動しています…</p>
  </div>
{:else if view === "onboarding"}
  <Onboarding ondone={() => (view = "workspace")} />
{:else if view === "settings"}
  <Settings onback={() => (view = "workspace")} />
{:else}
  <Workspace
    onsettings={() => (view = "settings")}
    oninstall={() => (view = "onboarding")}
  />
{/if}

<style>
  .boot { height: 100vh; flex-direction: column; gap: 14px; background: var(--bg); }
  .mark {
    width: 46px; height: 46px; border-radius: 14px;
    background: linear-gradient(135deg, var(--accent), #22d3ee);
    color: #fff; font-size: 22px; font-weight: 700;
    display: grid; place-items: center;
    animation: pulse 1.6s ease-in-out infinite;
  }
</style>
