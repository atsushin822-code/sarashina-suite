# Sarashina Suite

**オフラインで完結する超軽量・高速な統合 Office。** 文書編集と AI 支援のすべてを端末内で実行し、
ネットワークに一切依存しません（例外は初回のモデル取得のみ）。

| | |
|---|---|
| コア | Tauri 2（Rust + 各 OS ネイティブ WebView） |
| フロント | Svelte 5（runes）+ TypeScript + Vite |
| ストレージ | SQLite（WAL + FTS5/trigram）をバイナリ同梱 |
| AI | Sarashina 2.2 GGUF + llama.cpp（`llama-cpp-2`）|
| 配布 | Windows **ポータブル `.exe`（インストール不要）** / `.exe`(NSIS) / `.msi`, macOS `.dmg`, Linux `.AppImage`/`.deb`/`.rpm` |

フロントエンドのビルド成果物は **JS 82KB (gzip 31KB) + CSS 17KB**。GPU なしのノート PC でも
1B モデルで 15〜25 tok/s 程度の日本語生成が動作する構成を既定にしています。

---

## 1. クイックスタート

### 前提ツール

| OS | 必要なもの |
|---|---|
| 共通 | Rust 1.80+, Node.js 20+, `cmake`, `clang`（llama.cpp のビルドに必要）|
| Windows | Visual Studio Build Tools（C++ ワークロード）、WebView2（Win11 は標準）|
| macOS | Xcode Command Line Tools（`xcode-select --install`）|
| Linux | `libwebkit2gtk-4.1-dev libgtk-3-dev librsvg2-dev libayatana-appindicator3-dev patchelf` |

### 開発

```bash
npm install
npm run icons       # src-tauri/icons/source.png から各 OS 用アイコンを生成（初回のみ）

# ① まずは UI だけ動かす（llama.cpp をビルドしない = 数十秒で起動）
npm run app:dev:stub

# ② ローカル推論込みで動かす（初回は llama.cpp の C++ ビルドで 3〜8 分）
npm run app:dev

# ③ テスト / 型チェック
npm run core:test   # sarashina-core のユニットテスト（14 件）
npm run check       # svelte-check（型 + アクセシビリティ）
```

> ブラウザだけで UI を確認したい場合は `npm run dev` を実行して `http://localhost:1420` を開きます。
> Tauri API が無い環境では自動的に**デモバックエンド**（`src/lib/demo.ts`）へフォールバックし、
> ダウンロード進捗やストリーミング表示まで含めて操作感を確認できます。

### 配布ビルド

```bash
npm run app:build                    # 現在の OS 向けバンドルを生成
npm run app:build -- --bundles appimage,deb    # Linux で対象を限定
npm run app:build -- --target aarch64-apple-darwin --features metal
```

成果物は `target/release/bundle/` 以下（`dmg/`, `msi/`, `nsis/`, `appimage/`, `deb/`, `rpm/`）。
ルートに Cargo ワークスペースがあるため `src-tauri/target/` ではなく **プロジェクト直下の `target/`** に出ます。

### Windows ポータブル版（インストール不要）

CI は `SarashinaSuite-<version>-portable-x64.exe` と同名の `.zip` も生成します。これは
`target/release/sarashina-suite.exe`（生の実行ファイル）そのもので、**ダブルクリックで起動**できます。

* インストーラ・管理者権限・レジストリ書き込みは不要（設定と文書は `%APPDATA%\jp.sarashina.suite` に保存）
* 必要なのは **WebView2 ランタイム**のみ（Windows 11 は標準搭載、Windows 10 も Edge があれば導入済み。
  無い場合は NSIS インストーラを使うか、Microsoft の Evergreen ランタイムを入れてください）
* USB メモリに入れて持ち運べます（`.zip` を展開して `SarashinaSuite.exe` を実行）

タグを push するだけで 4 プラットフォーム分が自動ビルドされます（`.github/workflows/build.yml`）。
Git を使わず **zip + yml だけ**で回す手順は次のセクションを参照してください。

```bash
git tag v0.1.0 && git push origin v0.1.0
```

---

### zip + yml だけで GitHub Actions を回す（ローカル git 不要）

リポジトリに必要なのは **`sarashina-suite.zip`（この配布物）と `build.yml` の 2 つだけ**です。
ワークフローが zip を自動展開してプロジェクトの場所を解決するため、ソースを展開して push する必要はありません。

1. GitHub で空のリポジトリを作成する
2. **Add file → Upload files** で `sarashina-suite.zip` をリポジトリ直下にアップロードしてコミット
3. **Add file → Create new file** → ファイル名に `.github/workflows/build.yml` と入力し、
   ワークスペース直下の `build.yml` の内容を貼り付けてコミット
4. **Actions** タブ → `Build installers` → **Run workflow**
   - `build`: `all` / `linux` / `windows` / `macos` から選択
   - `skip_tests`: 検証ジョブを省略して時間を短縮
5. 実行完了後、ジョブページ下部の **Artifacts** から `sarashina-suite-linux` / `-windows` / `-macos-arm64` / `-macos-x64` をダウンロード

* タグを push（`v0.1.0`）すると同じワークフローが **Release に dmg / msi / exe / AppImage / deb / rpm を自動添付**します。
* 展開済みの通常リポジトリでも動きます（`src-tauri/` が直下にあれば zip は不要）。
* ビルド時間の目安: 初回 15〜25 分（llama.cpp の C++ ビルドを含む）／キャッシュ後 6〜10 分。
* `Cargo.lock` と `package-lock.json` を同梱しているため、リリース間で依存がぶれません。
* macOS Intel のランナーは **`macos-15-intel`**。ARM は **`macos-15`**（`macos-14` 系は 2026-11-02 に廃止済み）。
* ビルド対象の切り替えは「`plan` ジョブが matrix の JSON を出力 → `build` ジョブが `fromJSON` で受け取る」方式です
  （`matrix` コンテキストはジョブレベルの `if:` では使えず、`github` / `inputs` / `needs` / `vars` しか参照できません）。
* ワークフローの静的検証は `actionlint`（+ shellcheck）で 0 エラーを確認済みです。
* **成果物の出力先**: ルートに `[workspace]` があるため `target/` は**プロジェクト直下**に出ます
  （`src-tauri/target/` ではありません）。収集ステップは両方を探します。
* **ランナーは変数で差し替え可能**: `LINUX_RUNNER` / `WINDOWS_RUNNER` / `MACOS_ARM_RUNNER` / `MACOS_X64_RUNNER`
  （未設定時は `ubuntu-22.04` / `windows-latest` / `macos-15` / `macos-15-intel`）。
  GitHub がイメージを廃止しても、YAML を書き換えず変数だけで追従できます。
* **Windows はポータブル `.exe` も同梱**: 収集ステップが生の exe を `SarashinaSuite-<ver>-portable-x64.exe`
  として複製し、隣接 DLL があれば zip にまとめます（無ければ exe 単体で動きます）。
* **Windows は NSIS も主成果物**: `wix.language` を `ja-JP` に限定しているため MSI も作れますが、
  MSI(WiX) が失敗した場合は NSIS のみで再試行して必ず `.exe` を残します。
* **署名は任意**: リポジトリ変数 `APPLE_SIGNING` で制御します（未設定 = `auto`）。
  `auto` は証明書が無効でも警告を出して**署名なしで続行**、`true` は署名必須、`false` は常に署名なし。
* 成果物の収集は `find` → `$RUNNER_TEMP/artifacts` に平積み → ディレクトリごとアップロード（グロブ非依存）。
  0 件なら `target/` の構成を出力してジョブを失敗させるので、原因がログから即断できます。
* **macOS は 2 段ビルド**: ① Metal 有効 → ② 失敗したら Metal 無効（`GGML_METAL=OFF`）+ `LTO=thin` で再試行。
  ①が失敗しても `.dmg` が必ず生成されるため、CI が赤くなりません（ログに `::warning::` が出ます）。

## 2. ディレクトリ構造

```
sarashina-suite/
├── Cargo.toml                    # ワークスペース + リリースプロファイル(LTO/strip)
├── package.json / vite.config.ts / svelte.config.js / tsconfig.json
├── index.html
├── README.md / ARCHITECTURE.md
│
├── crates/sarashina-core/        # ★ UI/OS 非依存のドメインロジック（テスト対象）
│   ├── Cargo.toml
│   ├── migrations/001_init.sql   # SQLite スキーマ（user_version で管理）
│   └── src/
│       ├── lib.rs
│       ├── error.rs              # CoreError（Serialize して TS へ渡す）
│       ├── db.rs                 # 接続 / マイグレーション / CRUD / FTS5
│       ├── catalog.rs            # Sarashina GGUF カタログ（サイズ・SHA-256）
│       ├── download.rs           # Range レジューム + 進捗 + SHA-256 検証
│       ├── export.rs             # Markdown / HTML / TXT 書き出し
│       └── inference/
│           ├── mod.rs
│           ├── engine.rs         # ワーカースレッド / Job / ハンドル
│           ├── llama.rs          # llama.cpp バックエンド（feature = "llama"）
│           ├── stub.rs           # ダミーバックエンド（feature 無効時）
│           └── prompt.rs         # Sarashina 2.2 チャットテンプレート / 予算調整
│
├── src-tauri/                    # ★ デスクトップ層（薄いアダプタ）
│   ├── Cargo.toml
│   ├── build.rs
│   ├── tauri.conf.json           # バンドル設定（最重要）
│   ├── entitlements.plist        # macOS 署名用
│   ├── capabilities/default.json # 許可する権限（最小限）
│   ├── icons/                    # source.png から tauri icon で生成
│   └── src/
│       ├── main.rs
│       ├── lib.rs                # Builder / invoke_handler 登録
│       ├── state.rs              # AppState（DB, engine, client, cancel flags）
│       ├── events.rs             # イベント名 + ProgressSink/TokenSink 実装
│       └── commands/
│           ├── mod.rs            # ブロッキングヘルパ
│           ├── app.rs            # app_info / settings / stats
│           ├── documents.rs      # CRUD / 検索 / エクスポート
│           ├── models.rs         # ダウンロード / 削除 / 切替 / エンジン設定
│           └── chat.rs           # セッション / ストリーミング生成
│
├── src/                          # ★ フロントエンド（Svelte 5 + TS）
│   ├── main.ts / app.css
│   ├── App.svelte                # view 切り替え（onboarding/workspace/settings）
│   └── lib/
│       ├── api.ts                # Tauri invoke の唯一の窓口 + デモ fallback
│       ├── demo.ts               # ブラウザ実行用モックバックエンド
│       ├── types.ts              # Rust DTO と 1:1 の型
│       ├── format.ts             # バイト/相対時刻/HTML サニタイズ
│       ├── stores/app.svelte.ts  # runes ベースの共有状態
│       ├── components/           # Sidebar / Editor / AIPanel / ModelCard / ProgressBar
│       └── views/                # Onboarding / Workspace / Settings
│
└── .github/workflows/
    └── build.yml                 # ★ これ 1 本で完結（zip 自動展開 + 4OS ビルド + Release 添付）
```

**設計の要**: `sarashina-core`（純粋ロジック）と `src-tauri`（OS 連携）を分離しているため、
DB・ダウンローダ・プロンプト構築は GUI なしで `cargo test` できます。
詳細は [ARCHITECTURE.md](./ARCHITECTURE.md) を参照してください。

---

## 3. 検証済みの内容（このリポジトリの状態）

| 項目 | 結果 |
|---|---|
| `cargo test -p sarashina-core` | **14 テスト全パス**（DB/CRUD/FTS5 / SQLite スキーマ / プロンプト / エクスポート / パス処理）|
| `npm run check`（svelte-check） | **0 errors / 0 warnings** |
| `npm run build`（Vite） | 成功（JS 82KB / CSS 17KB）|
| `actionlint -shellcheck`（`build.yml`） | **0 issues**（式・コンテキスト・runner ラベル・シェルまで静的検証）|
| `cargo check -p sarashina-core --features llama` | **成功**（llama.cpp 0.1.161 を実ビルドして検証。warning 0）|
| `cargo check -p sarashina-suite`（llama) / `--no-default-features`（stub） | **両方成功（warning 0）** — WebKitGTK 4.1 環境で Tauri 層まで型検証済み |

---

## 4. よくある詰まりどころ

| 症状 | 対処 |
|---|---|
| `llama-cpp-sys-2` のビルドが失敗する | `cmake` と `clang`（+ Linux は `libclang-dev`）を入れる。Windows は VS Build Tools の C++ 必須 |
| `cargo check` が遅い / C++ をビルドしたくない | `--no-default-features`（スタブ推論）を使う。CI もこのモードで回している |
| Linux で `webkit2gtk-4.0` が見つからない | Tauri 2 は **4.1** 系が必要。`libwebkit2gtk-4.1-dev` を入れる |
| macOS で「開発元を確認できません」 | 未署名ビルドのため。配布時は `APPLE_*` シークレットを設定して署名 + 公証する |
| macOS で `xcrun: error: unable to find utility "metal"` | **Xcode 26 以降は Metal ツールチェーンが同梱されていない**。`xcodebuild -downloadComponent MetalToolchain` で導入する（ワークフローは自動導入し、失敗時は CPU 版へ自動フォールバックする）|
| CI で `No files were found with the provided path: .../src-tauri/target/**` | ルートが Cargo ワークスペースなので成果物は**プロジェクト直下の `target/`**。本ワークフローは `find` で両方を探してステージングする |
| `The configuration 'macos-14-arm64-us-xl' is not supported` | **`macos-14` 系ランナーは 2026-11-02 に廃止**されました（[公式チェンジログ](https://github.blog/changelog/2026-10-01-github-actions-macos-14-runner-image-retirement/)）。arm64 は `macos-15`（または `macos-latest`）を使ってください。本ワークフローは `macos-15` に更新済みで、リポジトリ変数 `MACOS_ARM_RUNNER` / `MACOS_X64_RUNNER` で差し替えも可能です |
| Windows で `error LGHT0311 : A string was provided with characters that are not available in the specified database code page '1252'` | WiX(MSI) の en-US データベースはコードページ 1252 のため、`shortDescription` 等の日本語を受け付けません。`bundle.windows.wix.language` を `"ja-JP"` のみにする（本リポジトリは対応済み）。CI は MSI 失敗時に NSIS へ自動フォールバックします |
| `SecKeychainItemImport: Unable to decode the provided data` | `APPLE_CERTIFICATE` が「`.p12` を base64 化した文字列」になっていない（PEM や改行混入）か、`APPLE_CERTIFICATE_PASSWORD` の不一致。署名をやめるなら Secrets を削除するか `APPLE_SIGNING=false` を設定（本ワークフローは失敗時に自動で署名なしへフォールバック）|
| macOS で `ld: out of memory` / SIGKILL | fat LTO と大規模 C++ 静的ライブラリのリンクでメモリ不足。CI のフォールバックは `CARGO_PROFILE_RELEASE_LTO=thin` で再試行する |
| モデルのダウンロードが遅い / 途中で止まる | 設定画面の「モデル取得ミラー」に自前ミラー URL を設定。`.part` から自動再開する |
| AI パネルが「モデルがまだ読み込まれていません」 | ダウンロード完了後、エンジンのロードに数秒かかる。設定画面のエンジン状態が `ready` になってから送信する |

---

## 5. ライセンス

* アプリコード: MIT OR Apache-2.0
* Sarashina 2.2（モデル重み）: MIT（SB Intuitions が公開）。GGUF 量子化は mmnga 氏による配布物を参照。
  モデルはアプリに同梱せず、初回起動時にユーザー端末へダウンロードして利用します。
